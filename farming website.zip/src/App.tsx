import { useState, useEffect } from 'react';
import { Header, PageId } from './components/Header';
import { HomePage } from './pages/HomePage';
import { AboutPage } from './pages/AboutPage';
import { MarketPage } from './pages/MarketPage';
import { ToursPage } from './pages/ToursPage';
import { SeasonPage, SeasonType } from './pages/SeasonPage';
import { AcresPage } from './pages/AcresPage';
import { VarietiesPage } from './pages/VarietiesPage';
import { SyntheticsPage } from './pages/SyntheticsPage';
import { FreshnessPage } from './pages/FreshnessPage';
import { VegetablesPage } from './pages/VegetablesPage';
import { FruitsPage } from './pages/FruitsPage';
import { LoginPage, UserProfile } from './pages/LoginPage';
import { CartDrawer } from './components/CartDrawer';
import { Footer } from './components/Footer';
import { CartItem, ProduceItem } from './types/farm';
import { PRODUCE_ITEMS } from './data/farmData';

export default function App() {
  // Parse initial page from hash or default to 'home'
  const getInitialPage = (): PageId => {
    const rawHash = window.location.hash.replace('#/', '').replace('#', '').toLowerCase();
    // Normalize potential aliases
    let hash = rawHash;
    if (hash === '180-acres' || hash === '180acres' || hash === 'land') hash = 'acres';
    if (hash === '42-varieties' || hash === '42varieties' || hash === 'crops') hash = 'varieties';
    if (hash === '0-synthetics' || hash === 'zero-synthetics' || hash === 'purity') hash = 'synthetics';
    if (hash === '24-hours' || hash === '24hours' || hash === 'dawn-to-door') hash = 'freshness';
    if (hash === 'veggies' || hash === 'vegetable') hash = 'vegetables';
    if (hash === 'fruit' || hash === 'orchard') hash = 'fruits';
    if (hash === 'signin' || hash === 'account' || hash === 'member') hash = 'login';

    const validPages: PageId[] = [
      'home',
      'about',
      'market',
      'tours',
      'spring',
      'summer',
      'autumn',
      'winter',
      'acres',
      'varieties',
      'synthetics',
      'freshness',
      'vegetables',
      'fruits',
      'login',
    ];
    if (validPages.includes(hash as PageId)) {
      return hash as PageId;
    }
    return 'home';
  };

  const [activePage, setActivePage] = useState<PageId>(getInitialPage());

  // User authentication session state
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    try {
      const saved = localStorage.getItem('verdant_roots_user_session');
      if (saved) return JSON.parse(saved);
    } catch {
      // Ignore
    }
    return null;
  });

  // Initialize with the flagship Hearth Harvest Box in cart
  const [cartItems, setCartItems] = useState<CartItem[]>([
    {
      product: PRODUCE_ITEMS[0],
      quantity: 1,
    },
  ]);
  const [isCartOpen, setIsCartOpen] = useState(false);

  // Sync hash change listener for back/forward browser button support
  useEffect(() => {
    const handleHashChange = () => {
      const page = getInitialPage();
      setActivePage(page);
    };

    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  // Update document title dynamically based on active page
  useEffect(() => {
    const titles: Record<PageId, string> = {
      home: 'Verdant Roots Organic Farm — Regenerative Living Soil Produce',
      about: 'About Our Living Soil & Regenerative Biology — Verdant Roots Organic',
      market: 'Seasonal Harvest Market & Weekly CSA Boxes — Verdant Roots Organic',
      tours: 'Visit the Farmstead: Field Walks, Apiary & Workshops — Verdant Roots Organic',
      spring: 'Spring Harvest & Tender Greens Guide — Verdant Roots Organic',
      summer: 'Summer Solar Abundance & Heirloom Nightshades — Verdant Roots Organic',
      autumn: 'Autumn Golden Harvest, Cured Squash & Orchard Bounty — Verdant Roots Organic',
      winter: 'Winter Root Cellars & Cold-Hardy Living Soil — Verdant Roots Organic',
      acres: '180+ Acres of Regenerative Living Soil & Land Stewardship — Verdant Roots Organic',
      varieties: '42 Heirloom Cultivars & Open-Pollinated Heritage Seed Bank — Verdant Roots Organic',
      synthetics: '0% Synthetics: 100% Biological Purity & Biodynamic Guarantee — Verdant Roots Organic',
      freshness: '< 24 Hours: The Dawn-to-Door Harvest Standard — Verdant Roots Organic',
      vegetables: 'Heirloom Vegetables & Soil Nutrition Guide — Verdant Roots Organic',
      fruits: 'Orchard Fruits & Tree-Ripened Brix Science — Verdant Roots Organic',
      login: 'Member Portal & CSA Account — Verdant Roots Organic',
    };
    document.title = titles[activePage] || titles.home;
  }, [activePage]);

  const handleNavigate = (page: PageId | string) => {
    const targetPage = page.toLowerCase() as PageId;
    setActivePage(targetPage);
    window.location.hash = `#/${targetPage}`;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const totalCartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  const handleAddToCart = (product: ProduceItem) => {
    setCartItems((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
  };

  const handleUpdateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveItem(productId);
      return;
    }
    setCartItems((prev) =>
      prev.map((item) => (item.product.id === productId ? { ...item, quantity } : item))
    );
  };

  const handleRemoveItem = (productId: string) => {
    setCartItems((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  const isSeasonPage = ['spring', 'summer', 'autumn', 'winter'].includes(activePage);

  return (
    <div className="min-h-screen bg-earth-50 text-earth-900 font-sans antialiased selection:bg-farm-green-800 selection:text-white flex flex-col justify-between">
      <div>
        {/* Top Header with 3-Zone Contract & Dynamic Navigation Across Pages */}
        <Header
          activePage={activePage}
          onNavigate={handleNavigate}
          cartCount={totalCartCount}
          onOpenCart={() => setIsCartOpen(true)}
          userName={currentUser?.name}
        />

        {/* Multi-Page Route Render */}
        <main id="main-content" className="animate-in fade-in duration-200">
          {activePage === 'home' && (
            <HomePage onNavigate={handleNavigate} onAddToCart={handleAddToCart} />
          )}

          {activePage === 'about' && (
            <AboutPage onNavigate={handleNavigate} />
          )}

          {activePage === 'market' && (
            <MarketPage onAddToCart={handleAddToCart} onNavigate={handleNavigate} />
          )}

          {activePage === 'tours' && (
            <ToursPage />
          )}

          {activePage === 'acres' && (
            <AcresPage onNavigate={handleNavigate} />
          )}

          {activePage === 'varieties' && (
            <VarietiesPage onNavigate={handleNavigate} onAddToCart={handleAddToCart} />
          )}

          {activePage === 'synthetics' && (
            <SyntheticsPage onNavigate={handleNavigate} />
          )}

          {activePage === 'freshness' && (
            <FreshnessPage onNavigate={handleNavigate} />
          )}

          {activePage === 'vegetables' && (
            <VegetablesPage onNavigate={handleNavigate} onAddToCart={handleAddToCart} />
          )}

          {activePage === 'fruits' && (
            <FruitsPage onNavigate={handleNavigate} onAddToCart={handleAddToCart} />
          )}

          {activePage === 'login' && (
            <LoginPage
              onNavigate={handleNavigate}
              currentUser={currentUser}
              onLogin={(user) => setCurrentUser(user)}
              onLogout={() => setCurrentUser(null)}
            />
          )}

          {isSeasonPage && (
            <SeasonPage
              season={activePage as SeasonType}
              onNavigate={handleNavigate}
              onAddToCart={handleAddToCart}
            />
          )}
        </main>
      </div>

      {/* Slide-over Cart & Checkout Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
      />

      {/* Semantic Footer with Page Navigation, Address & Newsletter */}
      <Footer onNavigate={handleNavigate} />
    </div>
  );
}
