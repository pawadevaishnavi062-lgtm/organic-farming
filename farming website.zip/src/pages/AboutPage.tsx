import React from 'react';
import { LivingSoil } from '../components/LivingSoil';
import { ImpactCalculator } from '../components/ImpactCalculator';
import { CustomerTestimonials } from '../components/CustomerTestimonials';
import { OrganicVisitingWebsites } from '../components/OrganicVisitingWebsites';
import { FARM_IMAGES } from '../data/farmData';
import { ArrowRight, ShieldCheck, Sprout, Sparkles, CheckCircle2 } from 'lucide-react';
import { PageId } from '../components/Header';

interface AboutPageProps {
  onNavigate: (page: PageId) => void;
}

export const AboutPage: React.FC<AboutPageProps> = ({ onNavigate }) => {
  return (
    <div className="space-y-0">
      {/* ABOUT PAGE DEDICATED PROFESSIONAL HERO */}
      <section className="relative bg-earth-900 border-b border-earth-800 overflow-hidden">
        <div className="relative min-h-[460px] lg:min-h-[520px] flex items-center">
          <div className="absolute inset-0 z-0">
            <img
              src={FARM_IMAGES.soilHands}
              alt="Hands holding rich dark living compost with green sprouts"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-earth-950/95 via-earth-900/85 to-farm-green-950/60" />
          </div>

          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-20 text-white">
            <div className="max-w-3xl space-y-5">
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-farm-green-200">
                <span>Our Heritage & Philosophy</span>
                <span aria-hidden="true" className="text-earth-400">·</span>
                <span className="text-terracotta-300">Established 2012</span>
              </div>

              <h1 className="font-serif text-4xl sm:text-5xl font-bold tracking-tight text-white leading-tight">
                Living Soil Science & Ecological Stewardship.
              </h1>

              <p className="text-base sm:text-lg text-earth-100/90 leading-relaxed font-normal">
                Food can only be as nutritious as the soil it grows in. At Verdant Roots, we reject
                the industrial monoculture mindset. We cultivate life underground first, ensuring every
                leaf, root, and fruit is charged with living vitamins, minerals, and antioxidants.
              </p>

              <div className="pt-2 flex flex-wrap items-center gap-4">
                <button
                  type="button"
                  onClick={() => onNavigate('market')}
                  className="inline-flex items-center gap-2 px-5 py-3 text-xs font-semibold text-white bg-farm-green-700 hover:bg-farm-green-600 rounded-lg transition-colors cursor-pointer"
                >
                  <span>Taste the Harvest</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => onNavigate('tours')}
                  className="inline-flex items-center gap-2 px-5 py-3 text-xs font-semibold text-earth-200 hover:text-white transition-colors cursor-pointer"
                >
                  Visit Our Fields &rarr;
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* THREE GENERATIONS OF STEWARDSHIP STORY */}
      <section className="py-20 lg:py-24 bg-white border-b border-earth-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            <div className="lg:col-span-6 space-y-5">
              <div className="flex items-center gap-2 text-xs font-semibold text-terracotta-700 uppercase tracking-wider">
                <Sparkles className="w-4 h-4 text-farm-green-700" />
                <span>The Regenerative Transition</span>
              </div>
              <h2 className="font-serif text-3xl sm:text-4xl font-bold text-earth-900">
                From Monoculture Dirt to Living Earth
              </h2>
              <p className="text-sm sm:text-base text-earth-700 leading-relaxed font-normal">
                Fourteen years ago, this valley parcel was conventionally farmed with commercial chemical
                inputs. The soil was compacted, gray, and devoid of earthworms. In 2012, our family stopped
                rototilling and abandoned all synthetic sprays.
              </p>
              <p className="text-sm sm:text-base text-earth-700 leading-relaxed font-normal">
                Through intensive cover cropping, inoculating with indigenous micro-organisms (IMO), and
                layering compost mulches, we restored the soil carbon from a depleted 1.2% to an astounding
                6.8%. Today, over 40 species of native birds and millions of wild pollinators inhabit our
                protective hedge borders.
              </p>

              <div className="pt-3 grid grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-earth-50 border border-earth-200">
                  <p className="font-serif text-2xl font-bold text-farm-green-800 tabular-nums">0%</p>
                  <p className="text-xs text-earth-600 mt-0.5">Synthetic Chemicals Used</p>
                </div>
                <div className="p-4 rounded-xl bg-earth-50 border border-earth-200">
                  <p className="font-serif text-2xl font-bold text-terracotta-700 tabular-nums">100%</p>
                  <p className="text-xs text-earth-600 mt-0.5">Non-GMO Heirloom Seed</p>
                </div>
              </div>
            </div>

            <div className="lg:col-span-6 space-y-4">
              <div className="p-6 rounded-2xl bg-earth-50 border border-earth-200 space-y-4">
                <h3 className="font-serif text-xl font-bold text-earth-900">
                  Our Five Environmental Pledges
                </h3>
                <ul className="space-y-3 text-xs text-earth-700 leading-relaxed">
                  <li className="flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-farm-green-700 shrink-0 mt-0.5" />
                    <span><strong>Living Soil First:</strong> We prioritize mycorrhizal fungal vitality and soil carbon above short-term yield spikes.</span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-farm-green-700 shrink-0 mt-0.5" />
                    <span><strong>Seed Sovereignty:</strong> Preserving 42 open-pollinated heirloom cultivars threatened by commercial seed patents.</span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-farm-green-700 shrink-0 mt-0.5" />
                    <span><strong>Closed-Loop Nutrients:</strong> 100% of organic crop residue and spent local artisan grain is thermally composted on-site.</span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-farm-green-700 shrink-0 mt-0.5" />
                    <span><strong>Pollinator Corridors:</strong> Dedicating 35% of total land acreage exclusively to unsprayed native perennial sanctuaries.</span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-farm-green-700 shrink-0 mt-0.5" />
                    <span><strong>Direct Accountability:</strong> Transparent farmgate policies where our community can walk the fields at any time.</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* HEIRLOOM SEED BANK & GENETIC PRESERVATION */}
      <section className="py-20 lg:py-24 bg-earth-50 border-b border-earth-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            <div className="lg:col-span-6 relative rounded-2xl overflow-hidden border border-earth-200 shadow-xs h-80 sm:h-96 bg-white">
              <img
                src={FARM_IMAGES.seeds}
                alt="Heirloom bean seeds, sunflower seeds, and pumpkin seeds in clay terracotta dishes on antique wood potting bench"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-earth-950/85 via-transparent to-transparent flex items-end p-6">
                <p className="text-xs text-white font-serif">
                  The Verdant Roots Seed Bank: Jacob’s Cattle speckled beans and open-pollinated landrace cultivars.
                </p>
              </div>
            </div>

            <div className="lg:col-span-6 space-y-5">
              <div className="flex items-center gap-2 text-xs font-semibold text-terracotta-700 uppercase tracking-wider">
                <Sparkles className="w-4 h-4 text-farm-green-700" />
                <span>Living Heritage Conservation</span>
              </div>
              <h2 className="font-serif text-3xl sm:text-4xl font-bold text-earth-900">
                True Seed Sovereignty & Open Pollination
              </h2>
              <p className="text-sm sm:text-base text-earth-700 leading-relaxed font-normal">
                Over 90% of vegetable varieties have disappeared from global agriculture in the last
                century due to chemical monocultures and patented F1 hybrid seeds. At Verdant Roots, we
                maintain a working seed vault of 42 open-pollinated varieties.
              </p>
              <p className="text-sm sm:text-base text-earth-700 leading-relaxed font-normal">
                Because our seeds adapt generation after generation to our biological living soil, they
                develop natural epigenetic resistance against blight and drought without chemical genetic
                modifications. Every autumn, we screen and save thousands of heritage bean, squash, and
                botanical seeds to share with our community.
              </p>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => onNavigate('market')}
                  className="inline-flex items-center gap-2 px-5 py-3 text-xs font-semibold text-white bg-farm-green-800 hover:bg-farm-green-900 rounded-lg transition-colors cursor-pointer"
                >
                  <span>Explore Heirloom Seed Vault in Market</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FULL LIVING SOIL PRACTICES & COMPARISON MODULE */}
      <LivingSoil />

      {/* HOUSEHOLD IMPACT SIMULATOR */}
      <ImpactCalculator />

      {/* CSA SUBSCRIBER TESTIMONIALS CAROUSEL */}
      <CustomerTestimonials
        title="What Our Farm Share Community Says"
        subtitle="Voices from long-time CSA members and regional chefs who rely on our living soil agronomy week after week."
      />

      {/* NATIONAL & GLOBAL ORGANIC VISITING WEBSITES & AUTHORITIES */}
      <OrganicVisitingWebsites
        title="Official Organic Authorities & Visiting Portals"
        subtitle="We ground our agronomy and biodiversity standards in research from official national institutions including the National Centre for Organic and Natural Farming (NCONF) and the Organic Farming Association of India (OFAI)."
      />

      {/* BOTTOM CTA STRIP */}
      <section className="py-16 bg-white text-center border-b border-earth-200">
        <div className="max-w-2xl mx-auto px-4 space-y-5">
          <Sprout className="w-8 h-8 text-farm-green-700 mx-auto" />
          <h2 className="font-serif text-2xl sm:text-3xl font-bold text-earth-900">
            Taste the Difference of Living Soil
          </h2>
          <p className="text-xs sm:text-sm text-earth-600 font-normal">
            Join hundreds of local families receiving weekly dawn-harvested produce boxes delivered straight to their doorstep.
          </p>
          <div className="pt-2">
            <button
              type="button"
              onClick={() => onNavigate('market')}
              className="px-6 py-3 text-xs font-semibold text-white bg-farm-green-800 hover:bg-farm-green-900 rounded-lg transition-colors cursor-pointer"
            >
              Order Weekly Harvest Share
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
