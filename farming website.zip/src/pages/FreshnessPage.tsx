import React, { useState } from 'react';
import { PageId } from '../components/Header';
import { FARM_IMAGES } from '../data/farmData';
import { Clock3, Sun, Truck, PackageCheck, Droplets, Sparkles, ArrowRight, ShieldCheck, Check } from 'lucide-react';

interface FreshnessPageProps {
  onNavigate: (page: PageId) => void;
}

export const FreshnessPage: React.FC<FreshnessPageProps> = ({ onNavigate }) => {
  const [selectedHour, setSelectedHour] = useState<number>(0);

  const timelineSteps = [
    {
      time: '05:00 AM — 07:00 AM',
      title: 'First-Light Dawn Dew Harvest',
      description: 'Crops are hand-harvested when ambient humidity is high and photosynthesis sugars have accumulated overnight. Cells are fully turgid and bursting with hydration.',
      keyMetric: 'Peak cellular turgor & natural sugar concentration',
      icon: Sun,
    },
    {
      time: '07:30 AM — 09:30 AM',
      title: 'Spring Well-Water Hydro-Cooling',
      description: 'Greens, radishes, and berries are gently washed in 48°F natural artesian well water. Removes field heat without chemicals, locking in cellular crispness.',
      keyMetric: 'Zero chemical dips or chlorine washes',
      icon: Droplets,
    },
    {
      time: '10:00 AM — 11:30 AM',
      title: 'Biodegradable Packing & Curing',
      description: 'Custom harvest boxes are packed using breathable unbleached kraft liners. Heirloom tomatoes, squashes, and onions cure in natural cedarwood rooms.',
      keyMetric: '100% plastic-free, compostable packaging',
      icon: PackageCheck,
    },
    {
      time: '12:00 PM — 02:30 PM',
      title: 'Direct Regional Eco-Transit',
      description: 'Chilled distribution couriers travel directly from our farm lanes to regional doorstep routes. Zero intermediate warehouse holding or broker delays.',
      keyMetric: 'Zero intermediate warehouse holding',
      icon: Truck,
    },
    {
      time: '03:00 PM — 06:00 PM',
      title: 'Kitchen Doorstep Arrival',
      description: 'Your harvest arrives on your kitchen counter less than 24 hours after living in our soil. Experience greens that stay crisp for weeks in your refrigerator.',
      keyMetric: '< 24 Hours from Living Soil to Table',
      icon: Clock3,
    },
  ];

  return (
    <div className="w-full space-y-0">
      {/* < 24 HOURS DEDICATED PROFESSIONAL HERO */}
      <section className="relative bg-earth-900 border-b border-earth-800 overflow-hidden">
        <div className="relative min-h-[480px] lg:min-h-[540px] flex items-center">
          <div className="absolute inset-0 z-0">
            <img
              src={FARM_IMAGES.harvestBasket}
              alt="Freshly harvested wooden crate of organic vegetables and greens"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-earth-950/95 via-earth-900/85 to-farm-green-950/60" />
          </div>

          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24 text-white">
            <div className="max-w-3xl space-y-5">
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-farm-green-300">
                <Clock3 className="w-4 h-4 text-farm-green-400" />
                <span>The Dawn-to-Door Freshness Protocol</span>
                <span aria-hidden="true" className="text-earth-400">·</span>
                <span className="text-terracotta-300">Harvest-to-Table in &lt; 24h</span>
              </div>

              <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-white leading-tight">
                &lt; 24 Hours: From Living Soil to Table.
              </h1>

              <p className="text-base sm:text-lg text-earth-100/95 leading-relaxed font-normal max-w-2xl">
                Average supermarket produce spends 14 to 21 days traveling through broker distribution centers, 
                refrigerated railcars, and distribution racks. Our produce is harvested at dawn and 
                delivered to your home on the very same day.
              </p>

              <div className="pt-2 flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={() => onNavigate('market')}
                  className="inline-flex items-center gap-2 px-6 py-3.5 text-xs font-semibold text-white bg-farm-green-700 hover:bg-farm-green-600 rounded-xl transition-all shadow-sm cursor-pointer"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Reserve Tomorrow's Harvest Box</span>
                </button>
                <button
                  type="button"
                  onClick={() => onNavigate('spring')}
                  className="inline-flex items-center gap-2 px-6 py-3.5 text-xs font-semibold text-white bg-earth-800/80 hover:bg-earth-700 border border-earth-600 rounded-xl transition-all cursor-pointer"
                >
                  <span>See Current Harvest Schedule</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* QUICK COMPARISON METRICS */}
      <section className="bg-earth-100 border-b border-earth-200 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center md:text-left">
            <div>
              <p className="text-2xl font-serif font-bold text-farm-green-800">&lt; 24 Hours</p>
              <p className="text-xs text-earth-600">Verdant Roots average harvest transit</p>
            </div>
            <div>
              <p className="text-2xl font-serif font-bold text-red-700">14–21 Days</p>
              <p className="text-xs text-earth-600">Supermarket produce transit delay</p>
            </div>
            <div>
              <p className="text-2xl font-serif font-bold text-earth-900">100% Turgor</p>
              <p className="text-xs text-earth-600">Peak cellular crispness upon arrival</p>
            </div>
            <div>
              <p className="text-2xl font-serif font-bold text-terracotta-700">2–3 Weeks</p>
              <p className="text-xs text-earth-600">Extended home refrigerator longevity</p>
            </div>
          </div>
        </div>
      </section>

      {/* THE 24-HOUR INTERACTIVE HARVEST TIMELINE */}
      <section className="py-16 lg:py-24 bg-white border-b border-earth-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          <div className="max-w-3xl space-y-3">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-farm-green-800">
              <Clock3 className="w-4 h-4" />
              <span>Hour-by-Hour Logistical Journey</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl font-bold text-earth-900">
              A Day in the Life of Your Produce
            </h2>
            <p className="text-sm text-earth-600 leading-relaxed">
              Step through our daily harvest rhythm to see how we bypass commercial distributor holding cycles.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Timeline Steps Selector */}
            <div className="lg:col-span-5 space-y-3">
              {timelineSteps.map((step, idx) => {
                const IconComponent = step.icon;
                const isSelected = selectedHour === idx;
                return (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setSelectedHour(idx)}
                    className={`w-full text-left p-5 rounded-2xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-earth-900 text-white border-earth-900 shadow-md'
                        : 'bg-earth-50 text-earth-900 border-earth-200 hover:bg-earth-100/80'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <span className={`text-xs font-bold uppercase tracking-wider ${isSelected ? 'text-farm-green-300' : 'text-farm-green-800'}`}>
                        {step.time}
                      </span>
                      <IconComponent className={`w-4 h-4 ${isSelected ? 'text-earth-300' : 'text-earth-500'}`} />
                    </div>
                    <h3 className="font-serif text-base font-bold">{step.title}</h3>
                  </button>
                );
              })}
            </div>

            {/* Selected Timeline Detail Card */}
            <div className="lg:col-span-7 bg-earth-50 border border-earth-200 rounded-3xl p-7 lg:p-9 space-y-6">
              <div className="border-b border-earth-200 pb-5">
                <span className="text-xs font-semibold uppercase tracking-wider text-farm-green-800">
                  {timelineSteps[selectedHour].time}
                </span>
                <h3 className="font-serif text-2xl sm:text-3xl font-bold text-earth-900 mt-1">
                  {timelineSteps[selectedHour].title}
                </h3>
              </div>

              <p className="text-base text-earth-800 leading-relaxed">
                {timelineSteps[selectedHour].description}
              </p>

              <div className="p-4 bg-white border border-earth-200 rounded-2xl flex items-start gap-3">
                <Check className="w-5 h-5 text-farm-green-700 shrink-0 mt-0.5" />
                <div>
                  <p className="text-xs font-bold uppercase tracking-wider text-earth-900">Critical Quality Standard</p>
                  <p className="text-xs text-earth-600 mt-0.5">
                    {timelineSteps[selectedHour].keyMetric}
                  </p>
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => onNavigate('market')}
                  className="inline-flex items-center gap-1.5 text-xs font-bold text-farm-green-800 hover:text-farm-green-950 cursor-pointer"
                >
                  <span>Experience same-day harvest delivery this week</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* NUTRITIONAL DEGRADATION STUDY */}
      <section className="py-16 bg-earth-100 border-b border-earth-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <h2 className="font-serif text-3xl font-bold text-earth-900">
              Why 24 Hours Changes Everything
            </h2>
            <p className="text-xs sm:text-sm text-earth-600">
              Produce is living tissue. The moment it is severed from the root, cellular respiration depletes sugars and vitamins.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 bg-white rounded-2xl border border-earth-200 shadow-2xs space-y-3">
              <span className="text-xs font-bold uppercase tracking-wider text-farm-green-800">Vitamin C Retention</span>
              <p className="text-3xl font-serif font-bold text-earth-900">98% vs 40%</p>
              <p className="text-xs text-earth-600 leading-relaxed">
                Spinach loses up to 60% of its Vitamin C content after 7 days in supermarket cold storage. At &lt;24h, nutrient retention is virtually 100%.
              </p>
            </div>

            <div className="p-6 bg-white rounded-2xl border border-earth-200 shadow-2xs space-y-3">
              <span className="text-xs font-bold uppercase tracking-wider text-farm-green-800">Volatile Terpenes & Aromatics</span>
              <p className="text-3xl font-serif font-bold text-earth-900">Peak Fragrance</p>
              <p className="text-xs text-earth-600 leading-relaxed">
                Herbs and tomatoes rely on delicate volatile oils for flavor. Eating within 24 hours delivers an unforgettable aromatic intensity.
              </p>
            </div>

            <div className="p-6 bg-white rounded-2xl border border-earth-200 shadow-2xs space-y-3">
              <span className="text-xs font-bold uppercase tracking-wider text-farm-green-800">Crisp Shelf-Life at Home</span>
              <p className="text-3xl font-serif font-bold text-earth-900">14–21 Days</p>
              <p className="text-xs text-earth-600 leading-relaxed">
                Because your produce hasn't spent weeks in transit, our greens and root crops remain fresh in your home crisper drawer for up to 3 weeks.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* BOTTOM ACTION BAR */}
      <section className="py-14 bg-earth-900 text-white text-center">
        <div className="max-w-2xl mx-auto px-4 space-y-5">
          <h2 className="font-serif text-2xl sm:text-3xl font-bold">
            Switch to the 24-Hour Freshness Standard
          </h2>
          <p className="text-xs sm:text-sm text-earth-200">
            Enjoy weekly CSA boxes or customized farmstand orders picked that very morning.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
            <button
              type="button"
              onClick={() => onNavigate('market')}
              className="px-6 py-3 text-xs font-semibold text-earth-900 bg-white hover:bg-earth-100 rounded-xl transition-all cursor-pointer"
            >
              Order Tomorrow's Fresh Basket
            </button>
            <button
              type="button"
              onClick={() => onNavigate('home')}
              className="px-6 py-3 text-xs font-semibold text-white bg-farm-green-700 hover:bg-farm-green-600 rounded-xl transition-all cursor-pointer"
            >
              Back to Home
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
