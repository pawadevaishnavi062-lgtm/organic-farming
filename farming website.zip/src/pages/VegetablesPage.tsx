import React, { useState } from 'react';
import { PageId } from '../components/Header';
import { FARM_IMAGES } from '../data/farmData';
import { ProduceItem } from '../types/farm';
import { ALL_42_VARIETIES, HeirloomVariety } from './VarietiesPage';
import { 
  Sprout, 
  Sparkles, 
  ShieldCheck, 
  Dna, 
  ShoppingBag, 
  ArrowRight, 
  Heart, 
  Check, 
  Leaf, 
  Flame, 
  Scale, 
  BookOpen, 
  Apple, 
  Sun, 
  Thermometer, 
  Info,
  Calendar
} from 'lucide-react';

interface VegetablesPageProps {
  onNavigate: (page: PageId) => void;
  onAddToCart?: (item: ProduceItem) => void;
}

export const VegetablesPage: React.FC<VegetablesPageProps> = ({ onNavigate, onAddToCart }) => {
  const [selectedFamily, setSelectedFamily] = useState<string>('all');
  const [addedItem, setAddedItem] = useState<string | null>(null);

  // Filter only the 16 heirloom vegetable varieties from the catalog
  const vegetableVarieties = ALL_42_VARIETIES.filter((v) => v.category === 'vegetables');

  const families = [
    { key: 'all', label: 'All 16 Vegetables' },
    { key: 'Solanaceae', label: 'Solanaceae (Nightshades)' },
    { key: 'Brassicaceae', label: 'Brassicaceae (Crucifers)' },
    { key: 'Apiaceae', label: 'Apiaceae (Carrots & Umbels)' },
    { key: 'Amaranthaceae', label: 'Amaranthaceae (Beets & Chards)' },
    { key: 'Cucurbitaceae', label: 'Cucurbitaceae (Squash & Zucchini)' },
    { key: 'Fabaceae', label: 'Fabaceae (Peas & Legumes)' },
    { key: 'Amaryllidaceae', label: 'Amaryllidaceae (Alliums)' },
  ];

  const filteredVegetables = selectedFamily === 'all'
    ? vegetableVarieties
    : vegetableVarieties.filter(v => v.family === selectedFamily);

  const handleAdd = (v: HeirloomVariety) => {
    if (onAddToCart) {
      const item: ProduceItem = {
        id: v.id,
        name: v.name,
        category: 'vegetables',
        price: parseFloat(v.price.replace(/[^0-9.]/g, '')) || 4.5,
        unit: v.price.split('/')[1]?.trim() || 'bunch',
        heirloomVariety: v.cultivar,
        description: `${v.flavor}. Ancestral origin: ${v.origin}.`,
        harvestWindow: `${v.season} Harvest`,
        organicCert: 'Demeter Certified Biodynamic',
        inStock: true,
        image: v.image,
      };
      onAddToCart(item);
      setAddedItem(v.id);
      setTimeout(() => setAddedItem(null), 2000);
    }
  };

  return (
    <div className="w-full space-y-0">
      {/* HERO SECTION */}
      <section className="relative bg-earth-900 border-b border-earth-800 overflow-hidden">
        <div className="relative min-h-[500px] lg:min-h-[560px] flex items-center">
          <div className="absolute inset-0 z-0">
            <img
              src={FARM_IMAGES.vegetables}
              alt="Harvest of heirloom rainbow carrots, chioggia candy beets, and purple sprouting broccoli"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-earth-950/95 via-earth-900/90 to-farm-green-950/70" />
          </div>

          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24 text-white">
            <div className="max-w-3xl space-y-5">
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-farm-green-300">
                <Leaf className="w-4 h-4 text-farm-green-400" />
                <span>Heirloom Vegetable Botanical Science</span>
                <span aria-hidden="true" className="text-earth-400">·</span>
                <span className="text-terracotta-300">Living Loam Soil</span>
              </div>

              <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-white leading-tight">
                Living-Soil Vegetables: 3x Polyphenols, Zero Synthetic Inputs.
              </h1>

              <p className="text-base sm:text-lg text-earth-100/95 leading-relaxed font-normal max-w-2xl">
                True nutritional density starts beneath the ground. When taproots connect with 
                undisturbed mycorrhizal fungal webs and billions of beneficial microbes, vegetables 
                synthesize complex polyphenols, flavonoids, and natural sugars impossible in chemically fertilized dirt.
              </p>

              <div className="pt-2 flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={() => {
                    const el = document.getElementById('veg-directory');
                    el?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="inline-flex items-center gap-2 px-6 py-3.5 text-xs font-semibold text-white bg-farm-green-700 hover:bg-farm-green-600 rounded-xl transition-all shadow-sm cursor-pointer"
                >
                  <BookOpen className="w-4 h-4" />
                  <span>Browse 16 Heirloom Vegetables</span>
                </button>
                <button
                  type="button"
                  onClick={() => onNavigate('fruits')}
                  className="inline-flex items-center gap-2 px-6 py-3.5 text-xs font-semibold text-white bg-earth-800 hover:bg-earth-700 border border-earth-600 rounded-xl transition-all cursor-pointer"
                >
                  <Apple className="w-4 h-4 text-terracotta-300" />
                  <span>Explore Orchard Fruits Guide</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* THREE PILLARS OF LIVING-SOIL VEGETABLES */}
      <section className="bg-earth-100 border-b border-earth-200 py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 rounded-2xl bg-white border border-earth-200 shadow-2xs space-y-2.5">
              <div className="w-10 h-10 rounded-xl bg-farm-green-100 text-farm-green-800 flex items-center justify-center">
                <Dna className="w-5 h-5" />
              </div>
              <h3 className="font-serif text-lg font-bold text-earth-900">
                100% Open-Pollinated Heirlooms
              </h3>
              <p className="text-xs text-earth-600 leading-relaxed">
                We reject F1 hybrids and patented laboratory seeds. Every carrot, beet, and brassica has 
                adapted over generations for deep flavor rather than mechanical shelf endurance.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-white border border-earth-200 shadow-2xs space-y-2.5">
              <div className="w-10 h-10 rounded-xl bg-terracotta-100 text-terracotta-700 flex items-center justify-center">
                <Sparkles className="w-5 h-5" />
              </div>
              <h3 className="font-serif text-lg font-bold text-earth-900">
                Natural Brix & Polyphenol Density
              </h3>
              <p className="text-xs text-earth-600 leading-relaxed">
                By allowing cold frosts to kiss our kale, carrots, and collards, plant starches naturally 
                convert into bio-available sugars and deep purple anthocyanin antioxidants.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-white border border-earth-200 shadow-2xs space-y-2.5">
              <div className="w-10 h-10 rounded-xl bg-earth-200 text-earth-800 flex items-center justify-center">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <h3 className="font-serif text-lg font-bold text-earth-900">
                Zero Chemical Washing or Waxes
              </h3>
              <p className="text-xs text-earth-600 leading-relaxed">
                Supermarket produce is chlorine-washed and coated in petroleum wax. Our roots and greens 
                are rinsed purely in natural mountain spring water to keep delicate rinds alive.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* DEEP BOTANICAL DIVE & 16 HEIRLOOM VEGETABLES DIRECTORY */}
      <section id="veg-directory" className="py-16 lg:py-24 bg-white border-b border-earth-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div className="max-w-2xl space-y-2">
              <span className="text-xs font-bold uppercase tracking-wider text-farm-green-800">
                7 Botanical Plant Families
              </span>
              <h2 className="font-serif text-3xl sm:text-4xl font-bold text-earth-900">
                The 16 Living-Soil Heirloom Vegetables
              </h2>
              <p className="text-xs sm:text-sm text-earth-600">
                Each cultivar has its own individual photograph, ancestral origin story, flavor notes, and biological season.
              </p>
            </div>

            <button
              type="button"
              onClick={() => onNavigate('varieties')}
              className="inline-flex items-center gap-1.5 text-xs font-bold text-farm-green-800 hover:text-farm-green-900 underline cursor-pointer"
            >
              <span>View full 42 varieties directory &rarr;</span>
            </button>
          </div>

          {/* Plant Family Filter Tabs */}
          <div className="flex flex-wrap gap-2 border-b border-earth-200 pb-4">
            {families.map((f) => (
              <button
                key={f.key}
                type="button"
                onClick={() => setSelectedFamily(f.key)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  selectedFamily === f.key
                    ? 'bg-earth-900 text-white shadow-2xs'
                    : 'bg-earth-100 text-earth-700 hover:bg-earth-200'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          {/* Vegetable Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {filteredVegetables.map((v) => (
              <div
                key={v.id}
                className="bg-earth-50 rounded-2xl border border-earth-200 overflow-hidden flex flex-col justify-between hover:border-farm-green-600 transition-all shadow-2xs group"
              >
                <div className="relative aspect-4/3 overflow-hidden bg-earth-200">
                  <img
                    src={v.image}
                    alt={v.name}
                    loading="lazy"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                  <div className="absolute top-2.5 left-2.5">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-earth-900/80 text-white backdrop-blur-xs">
                      {v.season} Harvest
                    </span>
                  </div>
                  <div className="absolute bottom-2.5 left-2.5">
                    <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-farm-green-900/80 text-farm-green-200 backdrop-blur-xs">
                      {v.family}
                    </span>
                  </div>
                </div>

                <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                  <div>
                    <h3 className="font-serif text-base font-bold text-earth-900 group-hover:text-farm-green-800 transition-colors">
                      {v.name}
                    </h3>
                    <p className="text-[10px] font-mono text-earth-500 italic mt-0.5">
                      {v.cultivar}
                    </p>
                    <p className="text-xs text-earth-700 mt-2 line-clamp-2">
                      {v.description}
                    </p>
                  </div>

                  <div className="pt-3 border-t border-earth-200 flex items-center justify-between">
                    <div>
                      <span className="text-xs font-bold text-earth-900">{v.price}</span>
                      <p className="text-[10px] text-earth-500">{v.baseLikes} Community Likes</p>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleAdd(v)}
                      className="px-3 py-1.5 rounded-lg text-xs font-bold bg-farm-green-800 hover:bg-farm-green-900 text-white transition-all cursor-pointer flex items-center gap-1"
                    >
                      {addedItem === v.id ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-farm-green-300" />
                          <span>Added</span>
                        </>
                      ) : (
                        <>
                          <ShoppingBag className="w-3.5 h-3.5" />
                          <span>Add</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SCIENCE & NUTRITION COMPARISON TABLE */}
      <section className="py-16 bg-earth-50 border-b border-earth-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          <div className="max-w-2xl space-y-2">
            <span className="text-xs font-bold uppercase tracking-wider text-farm-green-800">
              Laboratory Nutritional Testing
            </span>
            <h2 className="font-serif text-3xl font-bold text-earth-900">
              Living Soil Heirlooms vs Commercial Supermarket Produce
            </h2>
            <p className="text-xs sm:text-sm text-earth-600">
              Independent spectroscopy analysis of our dawn-harvested produce compared against standard retail averages.
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse bg-white rounded-2xl border border-earth-200 overflow-hidden text-xs">
              <thead>
                <tr className="bg-earth-900 text-white font-serif">
                  <th className="p-4 sm:p-5 font-bold">Nutritional Parameter</th>
                  <th className="p-4 sm:p-5 font-bold text-farm-green-300">Verdant Roots Living Soil</th>
                  <th className="p-4 sm:p-5 font-bold text-earth-400">Standard Supermarket Produce</th>
                  <th className="p-4 sm:p-5 font-bold">The Biological Rationale</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-earth-200 text-earth-800">
                <tr>
                  <td className="p-4 font-bold text-earth-900">Polyphenol Antioxidant Index</td>
                  <td className="p-4 font-bold text-farm-green-800 bg-farm-green-50/50">+310% Higher</td>
                  <td className="p-4 text-earth-500">Low baseline (Depleted)</td>
                  <td className="p-4 text-earth-600">Plants synthesize defense polyphenols when naturally interacting with living soil biology rather than chemical sprays.</td>
                </tr>
                <tr>
                  <td className="p-4 font-bold text-earth-900">Beta-Carotene (Carrots & Greens)</td>
                  <td className="p-4 font-bold text-farm-green-800 bg-farm-green-50/50">+280% Higher</td>
                  <td className="p-4 text-earth-500">Standardized hybrid level</td>
                  <td className="p-4 text-earth-600">Ancestral purple and solar cultivars carry native carotenoid genetics eliminated in machine-harvest commercial varieties.</td>
                </tr>
                <tr>
                  <td className="p-4 font-bold text-earth-900">Nitrogen Synthetic Residue</td>
                  <td className="p-4 font-bold text-farm-green-800 bg-farm-green-50/50">0.00 PPM (Undetectable)</td>
                  <td className="p-4 text-earth-500">Elevated nitrate levels</td>
                  <td className="p-4 text-earth-600">We use only compost and nitrogen-fixing legumes. Zero petrochemical ammonium nitrates are ever applied.</td>
                </tr>
                <tr>
                  <td className="p-4 font-bold text-earth-900">Post-Harvest Shelf Life</td>
                  <td className="p-4 font-bold text-farm-green-800 bg-farm-green-50/50">14–21 Days crispness</td>
                  <td className="p-4 text-earth-500">5–7 Days before wilting</td>
                  <td className="p-4 text-earth-600">Harvested at dawn and dispatched within 24 hours with root cell water pressure at full natural turgor.</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* FARM-TO-KITCHEN COOKING & CELLARING GUIDE */}
      <section className="py-16 bg-white border-b border-earth-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <span className="text-xs font-bold uppercase tracking-wider text-farm-green-800">
              Chef’s Culinary Handbook
            </span>
            <h2 className="font-serif text-3xl font-bold text-earth-900">
              Kitchen Preparation & Cellar Preservation
            </h2>
            <p className="text-xs sm:text-sm text-earth-600">
              How to get maximum flavor and nutrition from living-soil vegetables.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 rounded-2xl bg-earth-50 border border-earth-200 space-y-3">
              <span className="font-serif text-2xl font-bold text-terracotta-700">01</span>
              <h3 className="font-serif text-base font-bold text-earth-900">Never Peel Living Roots</h3>
              <p className="text-xs text-earth-600 leading-relaxed">
                Because our carrots and beets are grown in living compost without pesticides or waxes, 
                their skins are packed with beneficial micronutrients. A light brush in cold water is all that is required.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-earth-50 border border-earth-200 space-y-3">
              <span className="font-serif text-2xl font-bold text-terracotta-700">02</span>
              <h3 className="font-serif text-base font-bold text-earth-900">High-Heat Caramelization (400°F)</h3>
              <p className="text-xs text-earth-600 leading-relaxed">
                Heirloom winter squash and roots have high natural brix sugars. Roast in cast iron at 400°F (205°C) 
                with cold-pressed olive oil, coarse sea salt, and fresh rosemary to achieve golden caramelization.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-earth-50 border border-earth-200 space-y-3">
              <span className="font-serif text-2xl font-bold text-terracotta-700">03</span>
              <h3 className="font-serif text-base font-bold text-earth-900">Plastic-Free Cold Storage</h3>
              <p className="text-xs text-earth-600 leading-relaxed">
                Plastic bags cause vegetables to sweat and rot. Wrap root vegetables in a damp linen kitchen towel 
                and store in the crisper drawer to maintain cellar-level 95% humidity and peak crunch.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CROSS-LINK TO ORCHARD FRUITS */}
      <section className="py-14 bg-earth-900 text-white text-center">
        <div className="max-w-2xl mx-auto px-4 space-y-5">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-terracotta-900/80 text-terracotta-300 text-xs font-semibold border border-terracotta-700/50">
            <Apple className="w-3.5 h-3.5" />
            <span>Next Guide: Orchard Trees & Berries</span>
          </div>
          <h2 className="font-serif text-3xl font-bold">
            Explore the 45-Acre Heritage Orchard
          </h2>
          <p className="text-xs sm:text-sm text-earth-200">
            Discover our centennial Honeycrisp apples, Franciscan Black Mission Figs, Italian prune plums, 
            and natural tree-ripened brix sweetness.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
            <button
              type="button"
              onClick={() => onNavigate('fruits')}
              className="px-6 py-3.5 text-xs font-bold text-earth-900 bg-white hover:bg-earth-100 rounded-xl transition-all cursor-pointer shadow-sm"
            >
              Read Orchard Fruits Guide &rarr;
            </button>
            <button
              type="button"
              onClick={() => onNavigate('market')}
              className="px-6 py-3.5 text-xs font-bold text-white bg-farm-green-700 hover:bg-farm-green-600 rounded-xl transition-all cursor-pointer shadow-sm"
            >
              Order Produce in Market
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
