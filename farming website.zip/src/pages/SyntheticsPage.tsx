import React, { useState } from 'react';
import { PageId } from '../components/Header';
import { FARM_IMAGES } from '../data/farmData';
import { OrganicVisitingWebsites } from '../components/OrganicVisitingWebsites';
import { ShieldCheck, Bug, Droplet, Sprout, CheckCircle2, XCircle, ArrowRight, Sparkles, FileText, HeartHandshake } from 'lucide-react';

interface SyntheticsPageProps {
  onNavigate: (page: PageId) => void;
}

export const SyntheticsPage: React.FC<SyntheticsPageProps> = ({ onNavigate }) => {
  const [activeTab, setActiveTab] = useState<'pesticides' | 'fertilizers' | 'herbicides' | 'postharvest'>('pesticides');

  const biologicalReplacements = {
    pesticides: {
      synthetic: 'Synthetic Neonicotinoids & Organophosphates (neurotoxins that kill honeybees and persist in groundwater).',
      biological: 'Beneficial predatory insects (ladybugs, lacewings, parasitic trichogramma wasps) + aromatic borders of sweet alyssum and yarrow.',
      result: '0% chemical residue on leafy greens; active pollination from 48 healthy on-site honeybee apiaries.',
    },
    fertilizers: {
      synthetic: 'Synthetic Haber-Bosch chemical nitrates & synthetic petroleum-derived NPK salts that scorch soil mycorrhizae.',
      biological: 'Deep compost humus inoculated with fungal mycorrhizae + nitrogen-fixing symbiotic clover and winter vetch.',
      result: 'Self-regenerating soil organic matter exceeding 8.4% (vs 1.5% on conventional chemical farmland).',
    },
    herbicides: {
      synthetic: 'Glyphosate (Roundup), 2,4-D, and chemical defoliants sprayed broadly over bare soil.',
      biological: 'Roller-crimped cereal rye mulch blankets, occultation silage tarps, and precision manual wheel-hoeing.',
      result: 'Thriving earthworm populations and zero systemic herbicide accumulation in food crops.',
    },
    postharvest: {
      synthetic: 'Synthetic paraffin wax coatings, chemical fungicidal chlorine baths, and pressurized ethylene gas artificial ripening.',
      biological: 'Raw 48°F underground well-water hydro-cooling, slow natural curing in cedar rooms, zero waxes or chemical sprays.',
      result: 'Clean, breathable produce with 100% natural skins and uncompromised heirloom aromatics.',
    },
  };

  return (
    <div className="w-full space-y-0">
      {/* 0% SYNTHETICS DEDICATED PROFESSIONAL HERO */}
      <section className="relative bg-earth-900 border-b border-earth-800 overflow-hidden">
        <div className="relative min-h-[480px] lg:min-h-[540px] flex items-center">
          <div className="absolute inset-0 z-0">
            <img
              src={FARM_IMAGES.soilHands}
              alt="Hands holding dark organic rich living soil with new green sprouts"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-earth-950/95 via-earth-900/85 to-farm-green-950/60" />
          </div>

          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24 text-white">
            <div className="max-w-3xl space-y-5">
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-farm-green-300">
                <ShieldCheck className="w-4 h-4 text-farm-green-400" />
                <span>Zero Synthetic Inputs Guarantee</span>
                <span aria-hidden="true" className="text-earth-400">·</span>
                <span className="text-terracotta-300">100% Biodynamic Purity</span>
              </div>

              <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-white leading-tight">
                0% Synthetics. 100% Biological Purity.
              </h1>

              <p className="text-base sm:text-lg text-earth-100/95 leading-relaxed font-normal max-w-2xl">
                We believe that food should never be treated with synthetic petroleum chemicals, 
                systemic neurotoxic sprays, or artificial post-harvest waxes. We cultivate healthy crops 
                by feeding the soil biology, not by sterilizing it with synthetic chemistry.
              </p>

              <div className="pt-2 flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={() => onNavigate('market')}
                  className="inline-flex items-center gap-2 px-6 py-3.5 text-xs font-semibold text-white bg-farm-green-700 hover:bg-farm-green-600 rounded-xl transition-all shadow-sm cursor-pointer"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Taste Pure Food in Market</span>
                </button>
                <button
                  type="button"
                  onClick={() => onNavigate('about')}
                  className="inline-flex items-center gap-2 px-6 py-3.5 text-xs font-semibold text-white bg-earth-800/80 hover:bg-earth-700 border border-earth-600 rounded-xl transition-all cursor-pointer"
                >
                  <span>Read Soil Biology Science</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* THE 4 PILLARS OF 0% SYNTHETICS */}
      <section className="bg-earth-100 border-b border-earth-200 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center md:text-left">
            <div>
              <p className="text-2xl font-serif font-bold text-earth-900">0% Pesticides</p>
              <p className="text-xs text-earth-600">No neonicotinoids or sprays</p>
            </div>
            <div>
              <p className="text-2xl font-serif font-bold text-farm-green-800">0% Chemical NPK</p>
              <p className="text-xs text-earth-600">No petroleum synthetic nitrates</p>
            </div>
            <div>
              <p className="text-2xl font-serif font-bold text-terracotta-700">0% Herbicides</p>
              <p className="text-xs text-earth-600">Zero glyphosate or atrazine</p>
            </div>
            <div>
              <p className="text-2xl font-serif font-bold text-earth-900">0% Waxes & Gases</p>
              <p className="text-xs text-earth-600">Zero artificial ripening or dips</p>
            </div>
          </div>
        </div>
      </section>

      {/* HOW WE REPLACE SYNTHETICS: INTERACTIVE COMPARISON */}
      <section className="py-16 lg:py-24 bg-white border-b border-earth-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          <div className="max-w-3xl space-y-3">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-farm-green-800">
              <ShieldCheck className="w-4 h-4" />
              <span>Agronomic Substitution Science</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl font-bold text-earth-900">
              How We Replace Chemical Farming with Living Biology
            </h2>
            <p className="text-sm text-earth-600 leading-relaxed">
              Industrial agriculture claims synthetic chemicals are necessary for yields. 
              Our 180-acre harvest yields prove that living biology is superior in both nutritional density and pest resistance.
            </p>
          </div>

          {/* Tab Selector */}
          <div className="flex flex-wrap gap-2 border-b border-earth-200 pb-4">
            <button
              type="button"
              onClick={() => setActiveTab('pesticides')}
              className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'pesticides'
                  ? 'bg-earth-900 text-white'
                  : 'bg-earth-100 text-earth-700 hover:bg-earth-200'
              }`}
            >
              1. Insecticide Elimination
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('fertilizers')}
              className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'fertilizers'
                  ? 'bg-earth-900 text-white'
                  : 'bg-earth-100 text-earth-700 hover:bg-earth-200'
              }`}
            >
              2. Chemical Fertilizer Elimination
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('herbicides')}
              className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'herbicides'
                  ? 'bg-earth-900 text-white'
                  : 'bg-earth-100 text-earth-700 hover:bg-earth-200'
              }`}
            >
              3. Herbicide / Glyphosate Elimination
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('postharvest')}
              className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'postharvest'
                  ? 'bg-earth-900 text-white'
                  : 'bg-earth-100 text-earth-700 hover:bg-earth-200'
              }`}
            >
              4. Wax & Ethylene Gas Elimination
            </button>
          </div>

          {/* Interactive Comparison Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-stretch">
            {/* The Conventional Way */}
            <div className="bg-red-50/50 border border-red-200 rounded-3xl p-7 space-y-4">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-red-800">
                <XCircle className="w-4 h-4 text-red-600" />
                <span>Conventional Industry Standard</span>
              </div>
              <h3 className="font-serif text-xl font-bold text-earth-900">
                Synthetic Chemical Input
              </h3>
              <p className="text-sm text-earth-700 leading-relaxed">
                {biologicalReplacements[activeTab].synthetic}
              </p>
            </div>

            {/* The Verdant Roots Biological Way */}
            <div className="bg-farm-green-50 border border-farm-green-300 rounded-3xl p-7 space-y-4">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-farm-green-800">
                <CheckCircle2 className="w-4 h-4 text-farm-green-700" />
                <span>Verdant Roots Biological Solution</span>
              </div>
              <h3 className="font-serif text-xl font-bold text-farm-green-950">
                Natural Ecological Alliance
              </h3>
              <p className="text-sm text-farm-green-900 leading-relaxed">
                {biologicalReplacements[activeTab].biological}
              </p>
              <div className="pt-3 border-t border-farm-green-200 text-xs text-farm-green-950 font-medium">
                <strong>Demonstrated Harvest Result:</strong> {biologicalReplacements[activeTab].result}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* INDEPENDENT LAB AUDIT & CERTIFICATIONS */}
      <section className="py-16 bg-earth-50 border-b border-earth-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <h2 className="font-serif text-3xl font-bold text-earth-900">
              Verified by Rigorous Laboratory Testing
            </h2>
            <p className="text-xs sm:text-sm text-earth-600">
              Every quarterly harvest undergoes multi-residue pesticide gas chromatography testing.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 bg-white rounded-2xl border border-earth-200 shadow-2xs space-y-3">
              <div className="p-2.5 rounded-lg bg-farm-green-100 text-farm-green-800 w-fit">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <h3 className="font-serif text-lg font-bold text-earth-900">Demeter Biodynamic Certified</h3>
              <p className="text-xs text-earth-600 leading-relaxed">
                The world’s highest standard for regenerative organic agriculture, requiring whole-farm biodiversity and zero chemical inputs.
              </p>
            </div>

            <div className="p-6 bg-white rounded-2xl border border-earth-200 shadow-2xs space-y-3">
              <div className="p-2.5 rounded-lg bg-farm-green-100 text-farm-green-800 w-fit">
                <FileText className="w-5 h-5" />
              </div>
              <h3 className="font-serif text-lg font-bold text-earth-900">0.000 PPM Residue Record</h3>
              <p className="text-xs text-earth-600 leading-relaxed">
                Independent laboratory residue screenings verify non-detectable levels across 400+ commercial agricultural pesticides.
              </p>
            </div>

            <div className="p-6 bg-white rounded-2xl border border-earth-200 shadow-2xs space-y-3">
              <div className="p-2.5 rounded-lg bg-farm-green-100 text-farm-green-800 w-fit">
                <HeartHandshake className="w-5 h-5" />
              </div>
              <h3 className="font-serif text-lg font-bold text-earth-900">Real Organic Project</h3>
              <p className="text-xs text-earth-600 leading-relaxed">
                Certified grown strictly in real living soil, never in hydroponic plastic piping or sterile coconut coir bags.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* VISITING ORGANIC STANDARDS & APEX RESEARCH INSTITUTIONS */}
      <OrganicVisitingWebsites
        title="Zero-Synthetics Standards & Advisory Networks"
        subtitle="Our 0% synthetic chemical protocol conforms to national and global organic frameworks established by the National Centre for Organic and Natural Farming (NCONF), the Organic Farming Association of India (OFAI), and IFOAM Organics International."
      />

      {/* BOTTOM ACTION BAR */}
      <section className="py-14 bg-earth-900 text-white text-center">
        <div className="max-w-2xl mx-auto px-4 space-y-5">
          <h2 className="font-serif text-2xl sm:text-3xl font-bold">
            Taste the Pure Difference of 0% Synthetics
          </h2>
          <p className="text-xs sm:text-sm text-earth-200">
            Clean produce you can eat right out of the field, unwashed and safe for children and families.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
            <button
              type="button"
              onClick={() => onNavigate('market')}
              className="px-6 py-3 text-xs font-semibold text-earth-900 bg-white hover:bg-earth-100 rounded-xl transition-all cursor-pointer"
            >
              Order 100% Pure Produce
            </button>
            <button
              type="button"
              onClick={() => onNavigate('about')}
              className="px-6 py-3 text-xs font-semibold text-white bg-farm-green-700 hover:bg-farm-green-600 rounded-xl transition-all cursor-pointer"
            >
              Learn More in About
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
