import React from 'react';
import { ArrowRight, Trees, SunMedium, ShieldCheck, Clock3, Leaf, Sun, CloudRain, Snowflake } from 'lucide-react';
import { FARM_IMAGES } from '../data/farmData';
import { ProduceItem } from '../types/farm';
import { PageId } from '../components/Header';

interface HomePageProps {
  onNavigate: (page: PageId) => void;
  onAddToCart?: (item: ProduceItem) => void;
}

export const HomePage: React.FC<HomePageProps> = ({ onNavigate }) => {
  return (
    <div className="w-full">
      {/* 
        EXCLUSIVE HD BANNER SECTION FOR HOME PAGE
        Includes full HD panoramic visual, editorial kicker, primary typography,
        seasonal portals, and regenerative quality metrics.
      */}
      <section className="relative w-full min-h-[calc(100vh-140px)] lg:min-h-[820px] flex flex-col justify-between overflow-hidden bg-earth-950">
        {/* Full HD Background Photography */}
        <div className="absolute inset-0 z-0">
          <img
            src={FARM_IMAGES.hero}
            alt="High-definition panoramic view of Verdant Roots organic farm at dawn with lush heirloom crop rows and timber barn"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center scale-100"
          />
          {/* Multi-stop atmospheric scrim for optimal legibility (Green, White, Earth) */}
          <div className="absolute inset-0 bg-gradient-to-r from-earth-950/95 via-earth-900/80 to-farm-green-950/50" />
          <div className="absolute inset-0 bg-gradient-to-t from-earth-950 via-transparent to-earth-950/40" />
        </div>

        {/* Central HD Banner Content */}
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 lg:pt-28 pb-12 flex-1 flex flex-col justify-center">
          <div className="max-w-3xl space-y-7">
            {/* Editorial Kicker in Earth & Green Palette */}
            <div className="flex flex-wrap items-center gap-2 text-xs font-semibold uppercase tracking-wider text-farm-green-200">
              <span className="text-white">Verdant Roots Organic Farmstead</span>
              <span aria-hidden="true" className="text-earth-400">·</span>
              <span className="text-earth-200">Demeter Biodynamic Certified</span>
              <span aria-hidden="true" className="text-earth-400">·</span>
              <span className="text-farm-green-300">100% Regenerative Living Soil</span>
            </div>

            {/* Display Headline */}
            <h1
              className="font-serif text-4xl sm:text-6xl lg:text-7xl font-bold tracking-tight text-white leading-[1.08]"
              style={{ textWrap: 'balance' }}
            >
              Grown in Living Soil. Harvested in Harmony with Nature.
            </h1>

            {/* Value Proposition */}
            <p className="text-base sm:text-xl text-earth-100/95 leading-relaxed font-normal max-w-2xl">
              Cultivating 180 acres of heirloom vegetables, orchard fruits, and open-pollinated seeds 
              with zero synthetic inputs. Hand-harvested at dawn and delivered to your doorstep within 24 hours.
            </p>

            {/* Primary & Secondary Call-to-Actions */}
            <div className="pt-3 flex flex-wrap items-center gap-3.5 sm:gap-4">
              <button
                type="button"
                onClick={() => onNavigate('market')}
                className="inline-flex items-center justify-center gap-2 px-7 py-4 text-sm font-semibold text-white bg-farm-green-700 hover:bg-farm-green-600 border border-farm-green-500 rounded-xl shadow-lg hover:shadow-xl transition-all cursor-pointer whitespace-nowrap"
              >
                <span>Shop Fresh Harvest & Boxes</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={() => onNavigate('spring')}
                className="inline-flex items-center justify-center gap-2 px-6 py-4 text-sm font-semibold text-white bg-earth-800/80 hover:bg-earth-700 border border-earth-600/70 rounded-xl backdrop-blur-sm transition-all cursor-pointer whitespace-nowrap"
              >
                <span>Explore 4 Seasons</span>
                <Leaf className="w-4 h-4 text-farm-green-300" />
              </button>

              <button
                type="button"
                onClick={() => onNavigate('about')}
                className="inline-flex items-center justify-center px-6 py-4 text-sm font-semibold text-earth-200 hover:text-white bg-white/10 hover:bg-white/20 border border-white/20 rounded-xl backdrop-blur-xs transition-all cursor-pointer whitespace-nowrap"
              >
                Our Soil Science
              </button>

              <button
                type="button"
                onClick={() => onNavigate('tours')}
                className="inline-flex items-center justify-center px-6 py-4 text-sm font-semibold text-earth-200 hover:text-white transition-colors cursor-pointer whitespace-nowrap"
              >
                Book Farm Tour &rarr;
              </button>
            </div>

            {/* Quick 4-Season Portals Embedded inside HD Banner */}
            <div className="pt-6">
              <p className="text-xs font-semibold uppercase tracking-wider text-earth-300 mb-3">
                Seasonal Direct Access Pages:
              </p>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 max-w-2xl">
                <button
                  type="button"
                  onClick={() => onNavigate('spring')}
                  className="flex items-center gap-2 p-3 rounded-lg bg-earth-900/80 hover:bg-farm-green-950/90 border border-earth-700/70 hover:border-farm-green-500/80 text-left transition-all cursor-pointer group"
                >
                  <Leaf className="w-4 h-4 text-farm-green-400 group-hover:scale-110 transition-transform shrink-0" />
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-white leading-none">Spring</p>
                    <p className="text-[10px] text-earth-300 truncate mt-1">Tender Greens</p>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => onNavigate('summer')}
                  className="flex items-center gap-2 p-3 rounded-lg bg-earth-900/80 hover:bg-earth-800/90 border border-earth-700/70 hover:border-terracotta-500/80 text-left transition-all cursor-pointer group"
                >
                  <Sun className="w-4 h-4 text-terracotta-400 group-hover:scale-110 transition-transform shrink-0" />
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-white leading-none">Summer</p>
                    <p className="text-[10px] text-earth-300 truncate mt-1">Tomatoes & Orchard</p>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => onNavigate('autumn')}
                  className="flex items-center gap-2 p-3 rounded-lg bg-earth-900/80 hover:bg-earth-800/90 border border-earth-700/70 hover:border-earth-500 text-left transition-all cursor-pointer group"
                >
                  <CloudRain className="w-4 h-4 text-earth-300 group-hover:scale-110 transition-transform shrink-0" />
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-white leading-none">Autumn</p>
                    <p className="text-[10px] text-earth-300 truncate mt-1">Roots & Squash</p>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => onNavigate('winter')}
                  className="flex items-center gap-2 p-3 rounded-lg bg-earth-900/80 hover:bg-farm-green-950/90 border border-earth-700/70 hover:border-farm-green-600/80 text-left transition-all cursor-pointer group"
                >
                  <Snowflake className="w-4 h-4 text-farm-green-300 group-hover:scale-110 transition-transform shrink-0" />
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-white leading-none">Winter</p>
                    <p className="text-[10px] text-earth-300 truncate mt-1">Cold Greens & Beans</p>
                  </div>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Integrated HD Banner Proof Metrics Strip - Interactive Portals to Dedicated Pages */}
        <div className="relative z-10 w-full border-t border-white/10 bg-earth-950/85 backdrop-blur-md">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <p className="text-[11px] font-semibold uppercase tracking-wider text-earth-400 mb-2.5">
              Click to Explore Our 4 Dedicated Standards:
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 lg:gap-4">
              {/* 180+ Acres Button Card */}
              <button
                type="button"
                onClick={() => onNavigate('acres')}
                className="group flex items-center justify-between p-3 rounded-xl bg-earth-900/60 hover:bg-earth-900 border border-white/10 hover:border-farm-green-500/80 transition-all text-left cursor-pointer"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="p-2 rounded-lg bg-farm-green-900/80 text-farm-green-300 border border-farm-green-700/50 group-hover:scale-105 transition-transform shrink-0">
                    <Trees className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm sm:text-base font-bold text-white font-serif group-hover:text-farm-green-300 transition-colors">
                      180+ Acres
                    </p>
                    <p className="text-[10px] text-earth-300 truncate">Living soil stewardship &rarr;</p>
                  </div>
                </div>
              </button>

              {/* 42 Varieties Button Card */}
              <button
                type="button"
                onClick={() => onNavigate('varieties')}
                className="group flex items-center justify-between p-3 rounded-xl bg-earth-900/60 hover:bg-earth-900 border border-white/10 hover:border-terracotta-500/80 transition-all text-left cursor-pointer"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="p-2 rounded-lg bg-terracotta-900/80 text-terracotta-300 border border-terracotta-700/50 group-hover:scale-105 transition-transform shrink-0">
                    <SunMedium className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm sm:text-base font-bold text-white font-serif group-hover:text-terracotta-300 transition-colors">
                      42 Varieties
                    </p>
                    <p className="text-[10px] text-earth-300 truncate">Heirloom cultivars directory &rarr;</p>
                  </div>
                </div>
              </button>

              {/* 0% Synthetics Button Card */}
              <button
                type="button"
                onClick={() => onNavigate('synthetics')}
                className="group flex items-center justify-between p-3 rounded-xl bg-earth-900/60 hover:bg-earth-900 border border-white/10 hover:border-farm-green-500/80 transition-all text-left cursor-pointer"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="p-2 rounded-lg bg-farm-green-900/80 text-farm-green-300 border border-farm-green-700/50 group-hover:scale-105 transition-transform shrink-0">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm sm:text-base font-bold text-white font-serif group-hover:text-farm-green-300 transition-colors">
                      0% Synthetics
                    </p>
                    <p className="text-[10px] text-earth-300 truncate">Pure biological guarantee &rarr;</p>
                  </div>
                </div>
              </button>

              {/* < 24 Hours Button Card */}
              <button
                type="button"
                onClick={() => onNavigate('freshness')}
                className="group flex items-center justify-between p-3 rounded-xl bg-earth-900/60 hover:bg-earth-900 border border-white/10 hover:border-terracotta-500/80 transition-all text-left cursor-pointer"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="p-2 rounded-lg bg-terracotta-900/80 text-terracotta-300 border border-terracotta-700/50 group-hover:scale-105 transition-transform shrink-0">
                    <Clock3 className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm sm:text-base font-bold text-white font-serif group-hover:text-terracotta-300 transition-colors">
                      &lt; 24 Hours
                    </p>
                    <p className="text-[10px] text-earth-300 truncate">Dawn-to-door timeline &rarr;</p>
                  </div>
                </div>
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
