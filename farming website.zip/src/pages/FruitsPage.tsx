import React, { useState } from 'react';
import { PageId } from '../components/Header';
import { FARM_IMAGES } from '../data/farmData';
import { ProduceItem } from '../types/farm';
import { ALL_42_VARIETIES, HeirloomVariety } from './VarietiesPage';
import { 
  Apple, 
  Sparkles, 
  ShieldCheck, 
  Sun, 
  ShoppingBag, 
  ArrowRight, 
  Check, 
  TreePine, 
  Thermometer, 
  BookOpen, 
  Layers, 
  Sprout, 
  Flame, 
  Droplets,
  Calendar
} from 'lucide-react';

interface FruitsPageProps {
  onNavigate: (page: PageId) => void;
  onAddToCart?: (item: ProduceItem) => void;
}

export const FruitsPage: React.FC<FruitsPageProps> = ({ onNavigate, onAddToCart }) => {
  const [selectedSeason, setSelectedSeason] = useState<string>('all');
  const [addedItem, setAddedItem] = useState<string | null>(null);

  // Filter 10 orchard fruit varieties from the catalog
  const fruitVarieties = ALL_42_VARIETIES.filter((v) => v.category === 'fruits');

  const filteredFruits = selectedSeason === 'all'
    ? fruitVarieties
    : fruitVarieties.filter(v => v.season.toLowerCase() === selectedSeason.toLowerCase());

  const handleAdd = (v: HeirloomVariety) => {
    if (onAddToCart) {
      const item: ProduceItem = {
        id: v.id,
        name: v.name,
        category: 'fruits',
        price: parseFloat(v.price.replace(/[^0-9.]/g, '')) || 5.5,
        unit: v.price.split('/')[1]?.trim() || 'tote',
        heirloomVariety: v.cultivar,
        description: `${v.flavor}. Ancestral lineage: ${v.origin}.`,
        harvestWindow: `${v.season} Harvest`,
        organicCert: 'Demeter Certified Biodynamic',
        inStock: true,
        image: v.image,
      };
      onAddToCart(item);
      setAddedItem(v.id);
      setTimeout(() => setAddedItem(null), 2000);
    }
  };

  return (
    <div className="w-full space-y-0">
      {/* HERO SECTION */}
      <section className="relative bg-earth-900 border-b border-earth-800 overflow-hidden">
        <div className="relative min-h-[500px] lg:min-h-[560px] flex items-center">
          <div className="absolute inset-0 z-0">
            <img
              src={FARM_IMAGES.orchardTour}
              alt="45-acre heritage fruit orchard with ripe apples, figs, and blooming pollinator understory"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-earth-950/95 via-earth-900/90 to-farm-green-950/70" />
          </div>

          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24 text-white">
            <div className="max-w-3xl space-y-5">
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-terracotta-300">
                <Apple className="w-4 h-4 text-terracotta-400" />
                <span>The 45-Acre Heritage Orchard Ecosystem</span>
                <span aria-hidden="true" className="text-earth-400">·</span>
                <span className="text-farm-green-300">100% Tree-Ripened</span>
              </div>

              <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-white leading-tight">
                Tree-Ripened Fruit: Up to 22.8° Brix Natural Sugar Density.
              </h1>

              <p className="text-base sm:text-lg text-earth-100/95 leading-relaxed font-normal max-w-2xl">
                Commercial supermarkets harvest fruit green and sour at 8° Brix, gassing them in shipping 
                containers with synthetic ethylene. Our 10 heritage fruit cultivars ripen 100% on the living branch, 
                nourishing on deep mycorrhizal fungal soil and pollinated by 48 on-farm bee hives.
              </p>

              <div className="pt-2 flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={() => {
                    const el = document.getElementById('fruit-directory');
                    el?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="inline-flex items-center gap-2 px-6 py-3.5 text-xs font-semibold text-white bg-terracotta-700 hover:bg-terracotta-600 rounded-xl transition-all shadow-sm cursor-pointer"
                >
                  <BookOpen className="w-4 h-4" />
                  <span>Explore 10 Heritage Orchard Fruits</span>
                </button>
                <button
                  type="button"
                  onClick={() => onNavigate('vegetables')}
                  className="inline-flex items-center gap-2 px-6 py-3.5 text-xs font-semibold text-white bg-earth-800 hover:bg-earth-700 border border-earth-600 rounded-xl transition-all cursor-pointer"
                >
                  <Sprout className="w-4 h-4 text-farm-green-300" />
                  <span>Explore Vegetables Guide</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* METRICS STRIP: ORCHARD HEALTH */}
      <section className="bg-earth-100 border-b border-earth-200 py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 text-center md:text-left">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-2xl bg-terracotta-100 text-terracotta-700">
                <TreePine className="w-6 h-6" />
              </div>
              <div>
                <p className="text-2xl font-serif font-bold text-earth-900">45 Acres</p>
                <p className="text-xs text-earth-600">Centennial heritage trees</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="p-3 rounded-2xl bg-farm-green-100 text-farm-green-700">
                <Sun className="w-6 h-6" />
              </div>
              <div>
                <p className="text-2xl font-serif font-bold text-earth-900">22.8° Brix</p>
                <p className="text-xs text-earth-600">Peak fig & peach natural sweetness</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="p-3 rounded-2xl bg-amber-100 text-amber-800">
                <Sparkles className="w-6 h-6" />
              </div>
              <div>
                <p className="text-2xl font-serif font-bold text-earth-900">48 Bee Hives</p>
                <p className="text-xs text-earth-600">Langstroth organic apiary</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="p-3 rounded-2xl bg-earth-200 text-earth-800">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div>
                <p className="text-2xl font-serif font-bold text-earth-900">0 Waxes</p>
                <p className="text-xs text-earth-600">Pure tree bloom intact</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* THE 10 ORCHARD CULTIVARS DIRECTORY */}
      <section id="fruit-directory" className="py-16 lg:py-24 bg-white border-b border-earth-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div className="max-w-2xl space-y-2">
              <span className="text-xs font-bold uppercase tracking-wider text-terracotta-700">
                Centennial Cultivar Profiles
              </span>
              <h2 className="font-serif text-3xl sm:text-4xl font-bold text-earth-900">
                The 10 Heritage Orchard Fruits
              </h2>
              <p className="text-xs sm:text-sm text-earth-600">
                From 1769 Franciscan mission figs to cold-hardy Danish Gravenstein cider apples, 
                every tree is managed organically without synthetic pesticides or post-harvest gas chambers.
              </p>
            </div>

            <button
              type="button"
              onClick={() => onNavigate('varieties')}
              className="inline-flex items-center gap-1.5 text-xs font-bold text-farm-green-800 hover:text-farm-green-900 underline cursor-pointer"
            >
              <span>View all 42 varieties & community likes &rarr;</span>
            </button>
          </div>

          {/* Season Filter Tabs */}
          <div className="flex flex-wrap gap-2 border-b border-earth-200 pb-4">
            <button
              type="button"
              onClick={() => setSelectedSeason('all')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                selectedSeason === 'all'
                  ? 'bg-earth-900 text-white shadow-2xs'
                  : 'bg-earth-100 text-earth-700 hover:bg-earth-200'
              }`}
            >
              All 10 Fruits
            </button>
            <button
              type="button"
              onClick={() => setSelectedSeason('summer')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                selectedSeason === 'summer'
                  ? 'bg-earth-900 text-white shadow-2xs'
                  : 'bg-earth-100 text-earth-700 hover:bg-earth-200'
              }`}
            >
              Summer Harvest (Figs, Berries, Peaches)
            </button>
            <button
              type="button"
              onClick={() => setSelectedSeason('autumn')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                selectedSeason === 'autumn'
                  ? 'bg-earth-900 text-white shadow-2xs'
                  : 'bg-earth-100 text-earth-700 hover:bg-earth-200'
              }`}
            >
              Autumn Harvest (Honeycrisp, Pears, Plums)
            </button>
            <button
              type="button"
              onClick={() => setSelectedSeason('winter')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                selectedSeason === 'winter'
                  ? 'bg-earth-900 text-white shadow-2xs'
                  : 'bg-earth-100 text-earth-700 hover:bg-earth-200'
              }`}
            >
              Winter Harvest (Cold-Framed Meyer Lemons)
            </button>
          </div>

          {/* Fruit Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredFruits.map((v) => (
              <div
                key={v.id}
                className="bg-earth-50 rounded-2xl border border-earth-200 overflow-hidden flex flex-col justify-between hover:border-terracotta-600 transition-all shadow-2xs group"
              >
                <div className="relative aspect-4/3 overflow-hidden bg-earth-200">
                  <img
                    src={v.image}
                    alt={v.name}
                    loading="lazy"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                  <div className="absolute top-2.5 left-2.5">
                    <span className="px-2.5 py-0.5 rounded text-[10px] font-bold bg-earth-900/80 text-white backdrop-blur-xs">
                      {v.season} Harvest
                    </span>
                  </div>
                  <div className="absolute bottom-2.5 left-2.5">
                    <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-terracotta-900/80 text-terracotta-200 backdrop-blur-xs">
                      {v.family}
                    </span>
                  </div>
                </div>

                <div className="p-5 flex-1 flex flex-col justify-between space-y-3">
                  <div>
                    <h3 className="font-serif text-lg font-bold text-earth-900 group-hover:text-terracotta-700 transition-colors">
                      {v.name}
                    </h3>
                    <p className="text-[11px] font-mono text-earth-500 italic mt-0.5">
                      {v.cultivar}
                    </p>
                    <p className="text-xs text-earth-700 mt-2 line-clamp-2 leading-relaxed">
                      {v.description}
                    </p>
                  </div>

                  <div className="pt-3 border-t border-earth-200 flex items-center justify-between">
                    <div>
                      <span className="text-xs font-bold text-earth-900">{v.price}</span>
                      <p className="text-[10px] text-earth-500">{v.baseLikes} Community Likes</p>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleAdd(v)}
                      className="px-3.5 py-1.5 rounded-lg text-xs font-bold bg-farm-green-800 hover:bg-farm-green-900 text-white transition-all cursor-pointer flex items-center gap-1.5"
                    >
                      {addedItem === v.id ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-farm-green-300" />
                          <span>Added</span>
                        </>
                      ) : (
                        <>
                          <ShoppingBag className="w-3.5 h-3.5" />
                          <span>Add to Basket</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* BRIX SUGAR SCIENCE & ETHYLENE COMPARISON */}
      <section className="py-16 bg-earth-50 border-b border-earth-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          <div className="max-w-2xl space-y-2">
            <span className="text-xs font-bold uppercase tracking-wider text-terracotta-700">
              Biochemistry of Sweetness
            </span>
            <h2 className="font-serif text-3xl font-bold text-earth-900">
              Why Tree-Ripened Fruit Outperforms Commercial Produce
            </h2>
            <p className="text-xs sm:text-sm text-earth-600">
              Brix (°Bx) measures the percentage of sucrose, fructose, and dissolved minerals in fruit juice.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="p-6 sm:p-8 rounded-3xl bg-white border border-earth-200 shadow-xs space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-farm-green-100 text-farm-green-800 flex items-center justify-center font-bold">
                  ✓
                </div>
                <div>
                  <h3 className="font-serif text-xl font-bold text-earth-900">
                    Verdant Roots Branch-Ripened
                  </h3>
                  <span className="text-xs text-farm-green-800 font-semibold">14.0° to 22.8° Brix</span>
                </div>
              </div>

              <ul className="space-y-3 text-xs text-earth-700">
                <li className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-farm-green-600 shrink-0 mt-0.5" />
                  <span>Harvested when sugars peak naturally on the tree branch under sun exposure.</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-farm-green-600 shrink-0 mt-0.5" />
                  <span>Retains the natural powdery "silver bloom" that protects fruit skin from moisture loss.</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-farm-green-600 shrink-0 mt-0.5" />
                  <span>Delivered locally within 24 hours of morning picking — zero cold storage warehouses.</span>
                </li>
              </ul>
            </div>

            <div className="p-6 sm:p-8 rounded-3xl bg-white border border-earth-200 shadow-xs space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-terracotta-100 text-terracotta-700 flex items-center justify-center font-bold">
                  ✗
                </div>
                <div>
                  <h3 className="font-serif text-xl font-bold text-earth-900">
                    Commercial Retail Supply Chain
                  </h3>
                  <span className="text-xs text-terracotta-700 font-semibold">8.0° to 10.5° Brix (Sour/Hard)</span>
                </div>
              </div>

              <ul className="space-y-3 text-xs text-earth-700">
                <li className="flex items-start gap-2">
                  <span className="text-terracotta-700 font-bold shrink-0 mt-0.5">·</span>
                  <span>Picked rock-hard and unripe weeks before sugars develop, solely to prevent bruising during 2,000-mile truck transit.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-terracotta-700 font-bold shrink-0 mt-0.5">·</span>
                  <span>Artificially turned red or yellow using petrochemical ethylene gas in ripening chambers.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-terracotta-700 font-bold shrink-0 mt-0.5">·</span>
                  <span>Coated in morpholine or shellac wax to disguise moisture dehydration on supermarket displays.</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* 4-SEASON ORCHARD STEWARDSHIP CYCLE */}
      <section className="py-16 bg-white border-b border-earth-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <span className="text-xs font-bold uppercase tracking-wider text-farm-green-800">
              Continuous Biological Care
            </span>
            <h2 className="font-serif text-3xl font-bold text-earth-900">
              The 4 Seasons in Our Heritage Orchard
            </h2>
            <p className="text-xs sm:text-sm text-earth-600">
              How our orchardists nurture tree canopy vitality year-round without synthetic chemistry.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="p-6 rounded-2xl bg-earth-50 border border-earth-200 space-y-2.5">
              <span className="text-xs font-bold text-farm-green-800 uppercase tracking-wider">Winter</span>
              <h3 className="font-serif text-base font-bold text-earth-900">Dormant Tree Pruning</h3>
              <p className="text-xs text-earth-600 leading-relaxed">
                Hand-shaping fruit tree branches to open the canopy to maximum sunlight and prevent fungal spore buildup.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-earth-50 border border-earth-200 space-y-2.5">
              <span className="text-xs font-bold text-farm-green-800 uppercase tracking-wider">Spring</span>
              <h3 className="font-serif text-base font-bold text-earth-900">Apiary Blossom Flight</h3>
              <p className="text-xs text-earth-600 leading-relaxed">
                Our 48 honeybee hives wake up, pollinating millions of apple and pear blossoms across the 45-acre grove.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-earth-50 border border-earth-200 space-y-2.5">
              <span className="text-xs font-bold text-terracotta-700 uppercase tracking-wider">Summer</span>
              <h3 className="font-serif text-base font-bold text-earth-900">Hand Fruit Thinning</h3>
              <p className="text-xs text-earth-600 leading-relaxed">
                Removing excess fruit clusters so remaining tree fruits receive concentrated sap, mineral depth, and sugar.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-earth-50 border border-earth-200 space-y-2.5">
              <span className="text-xs font-bold text-terracotta-700 uppercase tracking-wider">Autumn</span>
              <h3 className="font-serif text-base font-bold text-earth-900">Cider Press & Packing</h3>
              <p className="text-xs text-earth-600 leading-relaxed">
                Picking dead-ripe apples, pears, and plums directly into cushioned crates and pressing raw unfiltered cider.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* BOTTOM ACTION CTA */}
      <section className="py-14 bg-earth-900 text-white text-center">
        <div className="max-w-2xl mx-auto px-4 space-y-5">
          <h2 className="font-serif text-3xl font-bold">
            Taste the Heritage Orchard This Week
          </h2>
          <p className="text-xs sm:text-sm text-earth-200">
            Order fresh fruit crates in our market or visit our orchard on a weekend walking tour.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
            <button
              type="button"
              onClick={() => onNavigate('market')}
              className="px-6 py-3.5 text-xs font-bold text-earth-900 bg-white hover:bg-earth-100 rounded-xl transition-all cursor-pointer shadow-sm"
            >
              Shop Fruit Totes in Market
            </button>
            <button
              type="button"
              onClick={() => onNavigate('tours')}
              className="px-6 py-3.5 text-xs font-bold text-white bg-terracotta-700 hover:bg-terracotta-600 rounded-xl transition-all cursor-pointer shadow-sm"
            >
              Book Orchard Walking Tour
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
