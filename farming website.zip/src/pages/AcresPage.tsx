import React, { useState } from 'react';
import { PageId } from '../components/Header';
import { FARM_IMAGES } from '../data/farmData';
import { Trees, Compass, Droplets, Wind, ArrowRight, ShieldCheck, MapPin, Sparkles, CheckCircle2 } from 'lucide-react';

interface AcresPageProps {
  onNavigate: (page: PageId) => void;
}

export const AcresPage: React.FC<AcresPageProps> = ({ onNavigate }) => {
  const [selectedParcel, setSelectedParcel] = useState<number>(0);

  const parcels = [
    {
      id: 0,
      name: 'South Slope Heirloom Beds',
      acreage: '70 Acres',
      type: 'Permanent Broadfork Vegetable Beds',
      soilType: 'Rich Willamette River Loam',
      crops: 'Heirloom Rainbow Carrots, Chioggia Beets, Lacinato Kale, Heirloom Tomatoes',
      practices: 'Strict no-till, permanent clover living pathways, hand-broadfork aerated, drip-tape subterranean irrigation.',
      keyFact: 'Over 14,000 yards of biodynamic compost applied annually across permanent raised beds.',
    },
    {
      id: 1,
      name: 'Suncrest Heritage Orchard & Apiary',
      acreage: '45 Acres',
      type: 'Centennial Fruit Trees & Pollinator Habitat',
      soilType: 'Clay-Loam with Deep Mycorrhizal Fungal Webs',
      crops: 'Honeycrisp & Gravenstein Apples, Black Mission Figs, Italian Prune Plums, Meyer Lemons',
      practices: 'Understory wildflower meadow, 48 active Langstroth honeybee hives, native perennial insectaries.',
      keyFact: '99% pollination rate achieved entirely through native mason bees and on-farm honeybee apiaries.',
    },
    {
      id: 2,
      name: 'Riparian Hedgerows & Wetland Sanctuary',
      acreage: '35 Acres',
      type: 'Native Wildlife Corridors & Bio-Swales',
      soilType: 'Natural Wetland Peat & Bio-Filtration Silt',
      crops: 'Native Elderberry, Willow Windbreaks, Wild Yarrow, Cattail Retention Basins',
      practices: 'Natural rainfall catchment, zero pesticide drift buffer zones, bird nesting towers for natural rodent control.',
      keyFact: 'Filters 100% of farm surface run-off before water returns to the pristine river basin.',
    },
    {
      id: 3,
      name: 'Biological Cover Crop Rotations',
      acreage: '30 Acres',
      type: 'Fallow & Soil Regeneration Rotation',
      soilType: 'High-Humus Regenerating Topsoil',
      crops: 'Crimson Clover, Austrian Winter Peas, Hairy Vetch, Deep-Taproot Daikon Radish',
      practices: 'Roller-crimped green manure, atmospheric nitrogen fixing, root-channel aeration without mechanical till.',
      keyFact: 'Naturally injects 180 lbs of biological nitrogen per acre without a single ounce of synthetic chemicals.',
    },
  ];

  return (
    <div className="w-full space-y-0">
      {/* 180+ ACRES DEDICATED PROFESSIONAL HERO */}
      <section className="relative bg-earth-900 border-b border-earth-800 overflow-hidden">
        <div className="relative min-h-[480px] lg:min-h-[540px] flex items-center">
          <div className="absolute inset-0 z-0">
            <img
              src={FARM_IMAGES.hero}
              alt="Panoramic view across 180+ acres of verdant organic farmland, crop rows, and wooded hills"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-earth-950/95 via-earth-900/85 to-farm-green-950/60" />
          </div>

          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24 text-white">
            <div className="max-w-3xl space-y-5">
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-farm-green-300">
                <Trees className="w-4 h-4 text-farm-green-400" />
                <span>The Land & Ecosystem Stewardship</span>
                <span aria-hidden="true" className="text-earth-400">·</span>
                <span className="text-terracotta-300">Pacific Northwest</span>
              </div>

              <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-white leading-tight">
                180+ Acres of Regenerative Living Soil.
              </h1>

              <p className="text-base sm:text-lg text-earth-100/95 leading-relaxed font-normal max-w-2xl">
                More than an organic farmstead — a contiguous 180-acre living sanctuary where 
                heirloom vegetables, century-old fruit orchards, native pollinator corridors, and 
                regenerative cover crops thrive in biological balance.
              </p>

              <div className="pt-2 flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={() => onNavigate('tours')}
                  className="inline-flex items-center gap-2 px-6 py-3.5 text-xs font-semibold text-white bg-farm-green-700 hover:bg-farm-green-600 rounded-xl transition-all shadow-sm cursor-pointer"
                >
                  <Compass className="w-4 h-4" />
                  <span>Book a 180-Acre Walking Tour</span>
                </button>
                <button
                  type="button"
                  onClick={() => onNavigate('market')}
                  className="inline-flex items-center gap-2 px-6 py-3.5 text-xs font-semibold text-white bg-earth-800/80 hover:bg-earth-700 border border-earth-600 rounded-xl transition-all cursor-pointer"
                >
                  <span>Shop Harvest from our Land</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* QUICK HIGHLIGHT STRIP */}
      <section className="bg-earth-100 border-b border-earth-200 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center md:text-left">
            <div>
              <p className="text-2xl font-serif font-bold text-earth-900">180.4 Acres</p>
              <p className="text-xs text-earth-600">Total contiguous farm acreage</p>
            </div>
            <div>
              <p className="text-2xl font-serif font-bold text-farm-green-800">420 Metric Tons</p>
              <p className="text-xs text-earth-600">CO2 sequestered annually in humus</p>
            </div>
            <div>
              <p className="text-2xl font-serif font-bold text-terracotta-700">100% Rainfall</p>
              <p className="text-xs text-earth-600">Bio-filtered on-site through swales</p>
            </div>
            <div>
              <p className="text-2xl font-serif font-bold text-earth-900">48 Bee Hives</p>
              <p className="text-xs text-earth-600">Native pollinator apiaries in orchards</p>
            </div>
          </div>
        </div>
      </section>

      {/* INTERACTIVE PARCEL EXPLORER */}
      <section className="py-16 lg:py-24 bg-white border-b border-earth-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          <div className="max-w-3xl space-y-3">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-farm-green-800">
              <MapPin className="w-4 h-4" />
              <span>Interactive Land Zoning & Parcels</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl font-bold text-earth-900">
              Explore Our 4 Ecological Zones
            </h2>
            <p className="text-sm text-earth-600 leading-relaxed">
              Every acre of our 180-acre land is purposefully allocated to create closed-loop biological resilience.
              Click through the parcels to inspect our soil profiles, cultivation techniques, and ecological roles.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Parcel Selectors */}
            <div className="lg:col-span-5 space-y-3">
              {parcels.map((p) => {
                const isSelected = selectedParcel === p.id;
                return (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setSelectedParcel(p.id)}
                    className={`w-full text-left p-5 rounded-2xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-earth-900 text-white border-earth-900 shadow-md'
                        : 'bg-earth-50 text-earth-900 border-earth-200 hover:bg-earth-100/80'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <span className={`text-xs font-bold uppercase tracking-wider ${isSelected ? 'text-farm-green-300' : 'text-farm-green-800'}`}>
                        {p.acreage}
                      </span>
                      <span className={`text-xs ${isSelected ? 'text-earth-300' : 'text-earth-500'}`}>
                        Zone {p.id + 1}
                      </span>
                    </div>
                    <h3 className="font-serif text-lg font-bold">{p.name}</h3>
                    <p className={`text-xs mt-1 truncate ${isSelected ? 'text-earth-200' : 'text-earth-600'}`}>
                      {p.type}
                    </p>
                  </button>
                );
              })}
            </div>

            {/* Selected Parcel Deep Dive Card */}
            <div className="lg:col-span-7 bg-earth-50 border border-earth-200 rounded-3xl p-7 lg:p-9 space-y-6">
              <div className="flex items-center justify-between border-b border-earth-200 pb-5">
                <div>
                  <span className="text-xs font-semibold uppercase tracking-wider text-farm-green-800">
                    {parcels[selectedParcel].acreage} · Dedicated Organic Land
                  </span>
                  <h3 className="font-serif text-2xl sm:text-3xl font-bold text-earth-900 mt-1">
                    {parcels[selectedParcel].name}
                  </h3>
                </div>
                <div className="p-3 bg-farm-green-100 text-farm-green-800 rounded-2xl shrink-0">
                  <Trees className="w-6 h-6" />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 bg-white rounded-xl border border-earth-200">
                  <p className="text-xs font-semibold uppercase tracking-wider text-earth-500">Soil Character</p>
                  <p className="text-sm font-bold text-earth-900 mt-1">{parcels[selectedParcel].soilType}</p>
                </div>
                <div className="p-4 bg-white rounded-xl border border-earth-200">
                  <p className="text-xs font-semibold uppercase tracking-wider text-earth-500">Key Cultivars</p>
                  <p className="text-sm font-bold text-earth-900 mt-1">{parcels[selectedParcel].crops}</p>
                </div>
              </div>

              <div className="space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-earth-800">
                  Agronomic Stewardship Practices
                </h4>
                <p className="text-sm text-earth-700 leading-relaxed">
                  {parcels[selectedParcel].practices}
                </p>
              </div>

              <div className="p-4 bg-farm-green-50 border border-farm-green-200 rounded-2xl flex items-start gap-3">
                <Sparkles className="w-5 h-5 text-farm-green-800 shrink-0 mt-0.5" />
                <div>
                  <p className="text-xs font-bold text-farm-green-950 uppercase tracking-wider">Ecological Landmark</p>
                  <p className="text-xs text-farm-green-900 mt-0.5 leading-relaxed">
                    {parcels[selectedParcel].keyFact}
                  </p>
                </div>
              </div>

              <div className="pt-2 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => onNavigate('tours')}
                  className="inline-flex items-center gap-1.5 text-xs font-bold text-farm-green-800 hover:text-farm-green-950 cursor-pointer"
                >
                  <span>See this parcel on our weekend guided tour</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* REGENERATIVE FIELD PHOTOS SHOWCASE */}
      <section className="py-16 bg-earth-100 border-b border-earth-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <h2 className="font-serif text-3xl font-bold text-earth-900">Life Across the 180 Acres</h2>
            <p className="text-xs sm:text-sm text-earth-600">
              Unfiltered photos from our working organic acreage throughout the year.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="group rounded-2xl overflow-hidden border border-earth-200 bg-white shadow-2xs">
              <div className="aspect-4/3 overflow-hidden">
                <img
                  src={FARM_IMAGES.hero}
                  alt="Dawn sunrise across crop rows"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="p-4 space-y-1">
                <p className="font-serif text-base font-bold text-earth-900">Dawn Vegetable Rows</p>
                <p className="text-xs text-earth-600">70 acres of permanent raised beds misted by morning fog.</p>
              </div>
            </div>

            <div className="group rounded-2xl overflow-hidden border border-earth-200 bg-white shadow-2xs">
              <div className="aspect-4/3 overflow-hidden">
                <img
                  src={FARM_IMAGES.orchardTour}
                  alt="Heritage fruit orchard with wildflower groundcover"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="p-4 space-y-1">
                <p className="font-serif text-base font-bold text-earth-900">Centennial Orchard Canopy</p>
                <p className="text-xs text-earth-600">Heritage fruit varieties underplanted with sweet clover.</p>
              </div>
            </div>

            <div className="group rounded-2xl overflow-hidden border border-earth-200 bg-white shadow-2xs">
              <div className="aspect-4/3 overflow-hidden">
                <img
                  src={FARM_IMAGES.soilHands}
                  alt="Living compost and seedlings"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="p-4 space-y-1">
                <p className="font-serif text-base font-bold text-earth-900">Living Humus Topsoil</p>
                <p className="text-xs text-earth-600">Biodynamic compost nourishing billions of microbial allies.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* BOTTOM ACTION JUMPER */}
      <section className="py-14 bg-earth-900 text-white text-center">
        <div className="max-w-2xl mx-auto px-4 space-y-5">
          <h2 className="font-serif text-2xl sm:text-3xl font-bold">
            Experience the 180-Acre Ecosystem in Person
          </h2>
          <p className="text-xs sm:text-sm text-earth-200">
            Join our head agronomist for a weekend walking tour, or enjoy weekly harvest shares delivered directly from our soil.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
            <button
              type="button"
              onClick={() => onNavigate('tours')}
              className="px-6 py-3 text-xs font-semibold text-earth-900 bg-white hover:bg-earth-100 rounded-xl transition-all cursor-pointer"
            >
              Book Field Walking Tour
            </button>
            <button
              type="button"
              onClick={() => onNavigate('market')}
              className="px-6 py-3 text-xs font-semibold text-white bg-farm-green-700 hover:bg-farm-green-600 rounded-xl transition-all cursor-pointer"
            >
              Order Produce from our Fields
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
