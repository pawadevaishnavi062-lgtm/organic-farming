import React, { useState, useMemo, useEffect } from 'react';
import { PageId } from '../components/Header';
import { FARM_IMAGES } from '../data/farmData';
import { ProduceItem } from '../types/farm';
import { 
  Dna, 
  Search, 
  Check, 
  ShoppingBag, 
  ArrowRight, 
  Heart, 
  Sparkles, 
  Info, 
  X, 
  Share2, 
  SlidersHorizontal,
  Flame,
  Award,
  Calendar,
  Layers
} from 'lucide-react';

interface VarietiesPageProps {
  onNavigate: (page: PageId) => void;
  onAddToCart?: (item: ProduceItem) => void;
}

export interface HeirloomVariety {
  id: string;
  name: string;
  cultivar: string;
  category: 'vegetables' | 'fruits' | 'seeds' | 'greens';
  family: string;
  origin: string;
  season: 'Spring' | 'Summer' | 'Autumn' | 'Winter';
  flavor: string;
  image: string;
  price: string;
  baseLikes: number;
  description: string;
}

export const ALL_42_VARIETIES: HeirloomVariety[] = [
  // Heirloom Vegetables (16)
  {
    id: 'v1',
    name: 'Rainbow Heirloom Carrots',
    cultivar: 'Daucus carota sativus',
    category: 'vegetables',
    family: 'Apiaceae',
    origin: '17th c. Afghan heirloom',
    season: 'Autumn',
    flavor: 'Earthy sweetness, high beta-carotene crisp',
    image: 'https://images.unsplash.com/photo-1598170845058-32b9d6a5da37?auto=format&fit=crop&w=800&q=80',
    price: '$4.50 / bunch',
    baseLikes: 348,
    description: 'Vibrant purple, solar yellow, and scarlet heritage carrots pulled with lush tender tops intact. Celebrated for high polyphenols and sweet crunch.'
  },
  {
    id: 'v2',
    name: 'Chioggia Candy-Stripe Beets',
    cultivar: 'Beta vulgaris',
    category: 'vegetables',
    family: 'Amaranthaceae',
    origin: '1840 Chioggia, Italy',
    season: 'Autumn',
    flavor: 'Mild, sweet earthy flavor without bitterness',
    image: 'https://images.unsplash.com/photo-1593105544559-ecb03bf76f82?auto=format&fit=crop&w=800&q=80',
    price: '$4.00 / bunch',
    baseLikes: 295,
    description: 'Famed Venetian bullseye heirloom with alternating concentric rings of deep ruby and pure white. Superb shaved raw or roasted in organic olive oil.'
  },
  {
    id: 'v3',
    name: 'Cherokee Purple Tomatoes',
    cultivar: 'Solanum lycopersicum',
    category: 'vegetables',
    family: 'Solanaceae',
    origin: 'Cherokee ancestral heirloom, pre-1890',
    season: 'Summer',
    flavor: 'Rich, smoky, wine-like complex umami',
    image: 'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?auto=format&fit=crop&w=800&q=80',
    price: '$6.50 / lb',
    baseLikes: 512,
    description: 'Ancestral seed preserved by the Cherokee Nation. Renowned for its dusky rose-purple shoulders and incomparable vinous, smoky sweetness.'
  },
  {
    id: 'v4',
    name: 'Brandywine Heirloom Tomatoes',
    cultivar: 'Solanum lycopersicum',
    category: 'vegetables',
    family: 'Solanaceae',
    origin: '1885 Amish heirloom',
    season: 'Summer',
    flavor: 'Perfect sweet-tart balance, velvety flesh',
    image: 'https://images.unsplash.com/photo-1546470427-e26264be0b11?auto=format&fit=crop&w=800&q=80',
    price: '$6.00 / lb',
    baseLikes: 438,
    description: 'The benchmark of heirloom beefsteak tomatoes with potato-leaf foliage and deep pink fruits bursting with quintessential old-fashioned flavor.'
  },
  {
    id: 'v5',
    name: 'Sun Gold Cherry Tomatoes',
    cultivar: 'Solanum lycopersicum',
    category: 'vegetables',
    family: 'Solanaceae',
    origin: 'Open-pollinated heritage cross',
    season: 'Summer',
    flavor: 'Intense tropical sweetness, thin delicate skin',
    image: 'https://images.unsplash.com/photo-1561136594-7f68413baa99?auto=format&fit=crop&w=800&q=80',
    price: '$5.00 / pint',
    baseLikes: 489,
    description: 'Sun-warmed golden clusters with extraordinarily high brix sugar levels. A farm-visitor favorite harvested daily at peak ripeness.'
  },
  {
    id: 'v6',
    name: 'Romanesco Cauliflower',
    cultivar: 'Brassica oleracea',
    category: 'vegetables',
    family: 'Brassicaceae',
    origin: '16th c. Rome, Italy',
    season: 'Autumn',
    flavor: 'Nutty, tender, sweet fractal florets',
    image: 'https://images.unsplash.com/photo-1568584711075-3d021a7c3ca3?auto=format&fit=crop&w=800&q=80',
    price: '$5.50 / head',
    baseLikes: 376,
    description: 'A botanical masterpiece exhibiting natural logarithmic spirals. Cooks faster than standard cauliflower with a sweet, delicate nuttiness.'
  },
  {
    id: 'v7',
    name: 'Dinosaur Lacinato Kale',
    cultivar: 'Brassica oleracea acephala',
    category: 'vegetables',
    family: 'Brassicaceae',
    origin: '18th c. Tuscany, Italy',
    season: 'Winter',
    flavor: 'Rich, deeply savory, non-bitter cold sweetness',
    image: 'https://images.unsplash.com/photo-1524179091875-bf99a9a6af57?auto=format&fit=crop&w=800&q=80',
    price: '$3.75 / bunch',
    baseLikes: 310,
    description: 'Embossed strap leaves known in Tuscany as Cavolo Nero. Frost converts its starches into natural sugars for cold-weather braises.'
  },
  {
    id: 'v8',
    name: 'French Breakfast Radishes',
    cultivar: 'Raphanus sativus',
    category: 'vegetables',
    family: 'Brassicaceae',
    origin: '1879 Parisian heirloom',
    season: 'Spring',
    flavor: 'Crisp, peppery crunch with a mild sweet finish',
    image: 'https://images.unsplash.com/photo-1566842600175-97dca489844f?auto=format&fit=crop&w=800&q=80',
    price: '$3.50 / bunch',
    baseLikes: 264,
    description: 'Elongated scarlet roots tipped in pure white. Traditionally paired with cold cultured butter and coarse sea salt on warm crusty bread.'
  },
  {
    id: 'v9',
    name: 'Purple Sprouting Broccoli',
    cultivar: 'Brassica oleracea italica',
    category: 'vegetables',
    family: 'Brassicaceae',
    origin: 'Ancient Mediterranean heirloom',
    season: 'Spring',
    flavor: 'Tender sweet florets with purple anthocyanins',
    image: 'https://images.unsplash.com/photo-1459411621453-7b03977f4bfc?auto=format&fit=crop&w=800&q=80',
    price: '$4.75 / bunch',
    baseLikes: 288,
    description: 'Extremely hardy heirloom producing abundant side shoots loaded with vivid violet florets rich in antioxidants and sulfur compounds.'
  },
  {
    id: 'v10',
    name: 'Delicata Winter Squash',
    cultivar: 'Cucurbita pepo',
    category: 'vegetables',
    family: 'Cucurbitaceae',
    origin: '1894 American heirloom',
    season: 'Autumn',
    flavor: 'Brown-sugar sweet with edible tender skin',
    image: 'https://images.unsplash.com/photo-1508747703725-719777637510?auto=format&fit=crop&w=800&q=80',
    price: '$3.50 / lb',
    baseLikes: 362,
    description: 'Creamy yellow cylindrical squash with forest-green stripes. The delicate rind softens completely when roasted with sage and brown butter.'
  },
  {
    id: 'v11',
    name: 'Sugar Snap Peas',
    cultivar: 'Pisum sativum',
    category: 'vegetables',
    family: 'Fabaceae',
    origin: 'Heritage open-pollinated',
    season: 'Spring',
    flavor: 'Bursting sweet juice and crisp succulent pod',
    image: 'https://images.unsplash.com/photo-1515543237350-b3eea1ec8082?auto=format&fit=crop&w=800&q=80',
    price: '$5.50 / lb',
    baseLikes: 415,
    description: 'Thick, crunchy pods filled with plump, sweet peas. Hand-picked at dawn when morning dew concentrates vine moisture.'
  },
  {
    id: 'v12',
    name: 'Costata Romanesco Zucchini',
    cultivar: 'Cucurbita pepo',
    category: 'vegetables',
    family: 'Cucurbitaceae',
    origin: 'Centuries-old Lazio landrace',
    season: 'Summer',
    flavor: 'Dense, nutty, non-watery firm flesh',
    image: 'https://images.unsplash.com/photo-1563865436874-9aef32095fad?auto=format&fit=crop&w=800&q=80',
    price: '$4.00 / lb',
    baseLikes: 245,
    description: 'Distinctive prominent ribs and mottled green skin. Low water content makes it the chef gold standard for pan-searing without sogging.'
  },
  {
    id: 'v13',
    name: 'Golden Detroit Beets',
    cultivar: 'Beta vulgaris',
    category: 'vegetables',
    family: 'Amaranthaceae',
    origin: '1828 Golden table beet',
    season: 'Autumn',
    flavor: 'Honey-like sweetness, vibrant golden flesh',
    image: 'https://images.unsplash.com/photo-1541832676-9b763b0239ab?auto=format&fit=crop&w=800&q=80',
    price: '$4.50 / bunch',
    baseLikes: 279,
    description: 'Luminous golden roots that do not bleed in culinary preparations. Mild, mellow sweetness loved by those who avoid earthy red varieties.'
  },
  {
    id: 'v14',
    name: 'Purple Dragon Carrots',
    cultivar: 'Daucus carota sativus',
    category: 'vegetables',
    family: 'Apiaceae',
    origin: 'Ancient purple taproot lineage',
    season: 'Winter',
    flavor: 'Spicy-sweet outer rind with bright yellow core',
    image: 'https://images.unsplash.com/photo-1447175008436-054170c2e979?auto=format&fit=crop&w=800&q=80',
    price: '$4.50 / bunch',
    baseLikes: 382,
    description: 'Rich maroon exterior with a sun-burst yellow-orange center. High anthocyanin content provides potent biological antioxidant properties.'
  },
  {
    id: 'v15',
    name: 'Copra Storage Yellow Onions',
    cultivar: 'Allium cepa',
    category: 'vegetables',
    family: 'Amaryllidaceae',
    origin: 'Hard European winter keeper',
    season: 'Winter',
    flavor: 'High sulfur pungency mellowing to deep sweetness',
    image: 'https://images.unsplash.com/photo-1618512496248-a07fe83aa8cb?auto=format&fit=crop&w=800&q=80',
    price: '$3.00 / 2 lb bag',
    baseLikes: 198,
    description: 'Thick copper skin with rock-hard storage bulbs. Naturally cured in our timber drying barns to preserve culinary integrity all winter.'
  },
  {
    id: 'v16',
    name: 'Georgia Southern Collards',
    cultivar: 'Brassica oleracea',
    category: 'vegetables',
    family: 'Brassicaceae',
    origin: '1880 American heirloom',
    season: 'Winter',
    flavor: 'Silk-tender texture, mineral-rich cold greens',
    image: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=800&q=80',
    price: '$3.50 / bunch',
    baseLikes: 224,
    description: 'Traditional open-headed blue-green collards bred to withstand deep winter frosts and develop complex, buttery tenderness when slow-simmered.'
  },

  // Orchard Fruits (10)
  {
    id: 'f1',
    name: 'Heritage Honeycrisp Apples',
    cultivar: 'Malus domestica',
    category: 'fruits',
    family: 'Rosaceae',
    origin: 'Orchard standard heritage cross',
    season: 'Autumn',
    flavor: 'Explosive snap crunch with rich honeyed acidity',
    image: 'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?auto=format&fit=crop&w=800&q=80',
    price: '$5.50 / 3 lb tote',
    baseLikes: 467,
    description: 'Grown on deep loamy orchard knolls without synthetic waxes or chemical shelf-life sprays. Unmatched cell structure creates explosive snap.'
  },
  {
    id: 'f2',
    name: 'Gravenstein Cider Apples',
    cultivar: 'Malus domestica',
    category: 'fruits',
    family: 'Rosaceae',
    origin: '17th c. Danish heritage cultivar',
    season: 'Summer',
    flavor: 'Aromatic vinous tartness, incomparable pie apple',
    image: 'https://images.unsplash.com/photo-1568702846914-96b305d2aaeb?auto=format&fit=crop&w=800&q=80',
    price: '$5.00 / 3 lb tote',
    baseLikes: 351,
    description: 'Slow Food Ark of Taste passenger. Early ripening heirloom with yellow-green skin streaked in scarlet, famed for aromatic ciders.'
  },
  {
    id: 'f3',
    name: 'Black Mission Figs',
    cultivar: 'Ficus carica',
    category: 'fruits',
    family: 'Moraceae',
    origin: '1769 Franciscan mission stock',
    season: 'Summer',
    flavor: 'Deep strawberry jam interior, velvety purple skin',
    image: 'https://images.unsplash.com/photo-1601379327928-bedfac7c1932?auto=format&fit=crop&w=800&q=80',
    price: '$8.50 / pint',
    baseLikes: 532,
    description: 'Tree-ripened until skins gently fissure with syrupy sweetness. Picked into padded flats daily to ensure delicate fruit integrity.'
  },
  {
    id: 'f4',
    name: 'Italian Prune Plums',
    cultivar: 'Prunus domestica',
    category: 'fruits',
    family: 'Rosaceae',
    origin: 'Old world European heritage plum',
    season: 'Autumn',
    flavor: 'Dense freestone golden flesh, sweet drying plum',
    image: 'https://images.unsplash.com/photo-1596363505729-4190a9506133?auto=format&fit=crop&w=800&q=80',
    price: '$6.00 / basket',
    baseLikes: 318,
    description: 'Deep cobalt-purple skin covered in natural silver bloom. Freestone golden amber flesh cooks into luxurious compotes and tarts.'
  },
  {
    id: 'f5',
    name: 'Meyer Lemons (Cold-Framed)',
    cultivar: 'Citrus x meyeri',
    category: 'fruits',
    family: 'Rutaceae',
    origin: '1908 cold-hardy citrus',
    season: 'Winter',
    flavor: 'Floral, sweet-tart with edible perfumed peel',
    image: 'https://images.unsplash.com/photo-1533089860892-a7c6f0a88666?auto=format&fit=crop&w=800&q=80',
    price: '$5.50 / bag',
    baseLikes: 394,
    description: 'Protected in passive solar timber frames during sub-zero frost nights. Thin, fragrant orange-tinted peel with mild culinary acidity.'
  },
  {
    id: 'f6',
    name: 'Seckel Sugar Pears',
    cultivar: 'Pyrus communis',
    category: 'fruits',
    family: 'Rosaceae',
    origin: 'Late 1700s Pennsylvania wild seedling',
    season: 'Autumn',
    flavor: 'Spicy, cinnamon-sugar tender bite',
    image: 'https://images.unsplash.com/photo-1514756331096-242fdeb70d4a?auto=format&fit=crop&w=800&q=80',
    price: '$5.00 / 2 lb tote',
    baseLikes: 273,
    description: 'Petite bite-sized sugar pears with olive skin blushed in dark garnet. Dense, creamy grain with natural warm spice undertones.'
  },
  {
    id: 'f7',
    name: 'Heritage Bosc Pears',
    cultivar: 'Pyrus communis',
    category: 'fruits',
    family: 'Rosaceae',
    origin: '1807 Belgian russet pear',
    season: 'Autumn',
    flavor: 'Honeyed nutmeg aroma, crisp dense flesh',
    image: 'https://images.unsplash.com/photo-1615485290382-441e4d049cb5?auto=format&fit=crop&w=800&q=80',
    price: '$5.50 / 3 lb tote',
    baseLikes: 290,
    description: 'Elegant tapered neck with warm cinnamon-russet skin. Holds shape beautifully when poached in estate spiced cider or red wine.'
  },
  {
    id: 'f8',
    name: 'Wild Marion Blackberries',
    cultivar: 'Rubus armeniacus',
    category: 'fruits',
    family: 'Rosaceae',
    origin: 'Willamette Valley native hybrid',
    season: 'Summer',
    flavor: 'Complex earthy berry depth, intense aroma',
    image: 'https://images.unsplash.com/photo-1563746098251-d35aef196e83?auto=format&fit=crop&w=800&q=80',
    price: '$6.00 / half pint',
    baseLikes: 446,
    description: 'King of blackberries. Cultivated on cedar trellises along the stream corridor with rich volcanic sweetness and gentle earthy tartness.'
  },
  {
    id: 'f9',
    name: 'Heritage Golden Raspberries',
    cultivar: 'Rubus idaeus',
    category: 'fruits',
    family: 'Rosaceae',
    origin: 'Rare yellow heritage cultivar',
    season: 'Summer',
    flavor: 'Subtle apricot note with gentle acidity',
    image: 'https://images.unsplash.com/photo-1577069808021-4b13a525f279?auto=format&fit=crop&w=800&q=80',
    price: '$6.50 / half pint',
    baseLikes: 387,
    description: 'Luminous champagne-yellow berries that are sweeter and less acidic than red varieties. Hand-gathered in lightweight woven baskets.'
  },
  {
    id: 'f10',
    name: 'Early Gold Peach',
    cultivar: 'Prunus persica',
    category: 'fruits',
    family: 'Rosaceae',
    origin: 'Open-pollinated river bench peach',
    season: 'Summer',
    flavor: 'Juicy nectar, velvet skin, freestone ease',
    image: 'https://images.unsplash.com/photo-1595124245030-41448b199d6d?auto=format&fit=crop&w=800&q=80',
    price: '$7.00 / 4-pack',
    baseLikes: 478,
    description: 'Sun-kissed orchard peaches picked dead-ripe from southern-facing slopes. Incomparable fragrant syrup that drips when sliced.'
  },

  // Heritage Seeds & Legumes (10)
  {
    id: 's1',
    name: 'Speckled Calypso Dry Beans',
    cultivar: 'Phaseolus vulgaris',
    category: 'seeds',
    family: 'Fabaceae',
    origin: 'Caribbean & Native American heirloom',
    season: 'Winter',
    flavor: 'Silky potato-like texture when simmered',
    image: 'https://images.unsplash.com/photo-1551462147-ff29053bfc14?auto=format&fit=crop&w=800&q=80',
    price: '$6.50 / 1 lb pouch',
    baseLikes: 312,
    description: 'Striking yin-yang pattern of black and white. Creamy, velvety broth when slow-cooked with garden alliums and bay leaf.'
  },
  {
    id: 's2',
    name: 'Cherokee Trail of Tears Beans',
    cultivar: 'Phaseolus vulgaris',
    category: 'seeds',
    family: 'Fabaceae',
    origin: 'Cherokee preserved seed, 1838',
    season: 'Autumn',
    flavor: 'Rich black bean soup stock, dense texture',
    image: 'https://images.unsplash.com/photo-1588714477688-cf28a50e94f7?auto=format&fit=crop&w=800&q=80',
    price: '$6.50 / 1 lb pouch',
    baseLikes: 421,
    description: 'Carried along the historic 1838 forced march by the Cherokee people. Produces lustrous jet-black beans with deep, rich broth flavor.'
  },
  {
    id: 's3',
    name: 'Mammoth Russian Sunflower Seeds',
    cultivar: 'Helianthus annuus',
    category: 'seeds',
    family: 'Asteraceae',
    origin: '1870 open-pollinated Russian giant',
    season: 'Autumn',
    flavor: 'Large nutty gray-stripe seed for snacking',
    image: 'https://images.unsplash.com/photo-1597848212624-a19eb35e2651?auto=format&fit=crop&w=800&q=80',
    price: '$4.75 / 8 oz pack',
    baseLikes: 365,
    description: 'Towering 12-foot stalks with massive 18-inch seedheads. Sun-dried on the plant and gently hulled for rich protein-dense snacking.'
  },
  {
    id: 's4',
    name: 'Kakai Hulless Pumpkin Seeds',
    cultivar: 'Cucurbita pepo',
    category: 'seeds',
    family: 'Cucurbitaceae',
    origin: 'Austrian hulless oilseed pepita',
    season: 'Autumn',
    flavor: 'Buttery, rich in zinc and heart-healthy oils',
    image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=800&q=80',
    price: '$7.00 / 8 oz pack',
    baseLikes: 334,
    description: 'Naturally naked dark green pepita seeds grown without tough outer hulls. Packed with beneficial minerals and cold-pressed oil.'
  },
  {
    id: 's5',
    name: 'Glass Gem Ornamental Flint Corn',
    cultivar: 'Zea mays',
    category: 'seeds',
    family: 'Poaceae',
    origin: 'Cherokee breeder Carl Barnes heirloom',
    season: 'Autumn',
    flavor: 'Glassy translucent popcorn kernels',
    image: 'https://images.unsplash.com/photo-1551754655-cd27e38d2076?auto=format&fit=crop&w=800&q=80',
    price: '$5.50 / seed packet',
    baseLikes: 495,
    description: 'A miraculous array of jewel-toned translucent kernels in sapphire, emerald, amber, and ruby. Pops into crisp miniature white popcorn.'
  },
  {
    id: 's6',
    name: 'Crimson Clover Cover Crop Seed',
    cultivar: 'Trifolium incarnatum',
    category: 'seeds',
    family: 'Fabaceae',
    origin: 'Naturalized Mediterranean pollinator seed',
    season: 'Spring',
    flavor: 'Living nitrogen factory for soil enrichment',
    image: 'https://images.unsplash.com/photo-1500651230702-0e2d8a49d4ad?auto=format&fit=crop&w=800&q=80',
    price: '$8.00 / 2 lb bag',
    baseLikes: 240,
    description: 'Our secret weapon for synthetic-free soil fertility. Fixes 140 lbs of atmospheric nitrogen per acre while nourishing native wild bees.'
  },
  {
    id: 's7',
    name: 'Heirloom Black Chia Seed',
    cultivar: 'Salvia hispanica',
    category: 'seeds',
    family: 'Lamiaceae',
    origin: 'Pre-Columbian Mesoamerican crop',
    season: 'Winter',
    flavor: 'Omega-3 rich mucilage seeds for morning porridge',
    image: 'https://images.unsplash.com/photo-1514733670139-4d87a1941d55?auto=format&fit=crop&w=800&q=80',
    price: '$6.00 / 8 oz pouch',
    baseLikes: 298,
    description: 'Ancient runner seed prized by Aztec messengers. Forms a soothing soluble gel when soaked, delivering rich plant omega-3 fatty acids.'
  },
  {
    id: 's8',
    name: 'Hopi Blue Corn Seeds',
    cultivar: 'Zea mays',
    category: 'seeds',
    family: 'Poaceae',
    origin: 'Hopi ancestral drought-hardy corn',
    season: 'Autumn',
    flavor: 'Sweet, earthy masa harina for tortillas',
    image: 'https://images.unsplash.com/photo-1536704689279-d599b8d2342c?auto=format&fit=crop&w=800&q=80',
    price: '$6.00 / packet',
    baseLikes: 358,
    description: 'Ancestral dryland corn with 30% higher protein than modern hybrid field corn. Milled on stone wheels into lavender-blue organic masa.'
  },
  {
    id: 's9',
    name: 'Jacob’s Cattle Dry Beans',
    cultivar: 'Phaseolus vulgaris',
    category: 'seeds',
    family: 'Fabaceae',
    origin: 'Passamaquoddy heirloom of Maine',
    season: 'Winter',
    flavor: 'Creamy, holds shape perfectly in winter stew',
    image: 'https://images.unsplash.com/photo-1515543237350-b3eea1ec8082?auto=format&fit=crop&w=800&q=80',
    price: '$6.50 / 1 lb pouch',
    baseLikes: 289,
    description: 'Snow-white dry bean marked with rich maroon splashes like a Hereford steer. Famed in New England beanpots for never turning to mush.'
  },
  {
    id: 's10',
    name: 'French Green Du Puy Lentils',
    cultivar: 'Lens culinaris',
    category: 'seeds',
    family: 'Fabaceae',
    origin: 'Le Puy volcanic soil heirloom',
    season: 'Winter',
    flavor: 'Peppery, nutty, never turns to mush',
    image: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=800&q=80',
    price: '$5.50 / 1 lb pouch',
    baseLikes: 304,
    description: 'Slate-green tiny lentils with dark blue marbling. High mineral content retains a firm al dente texture in warm goat-cheese salads.'
  },

  // Salad Greens & Herbs (6)
  {
    id: 'g1',
    name: 'Marvel of Four Seasons Butterhead',
    cultivar: 'Lactuca sativa',
    category: 'greens',
    family: 'Asteraceae',
    origin: '1885 French heirloom lettuce',
    season: 'Spring',
    flavor: 'Silky, butter-soft leaves tipped in bronze red',
    image: 'https://images.unsplash.com/photo-1622206151226-18ca2c9ab4a1?auto=format&fit=crop&w=800&q=80',
    price: '$4.00 / head',
    baseLikes: 377,
    description: 'Merveille des Quatre Saisons. Gorgeous rosettes of tender folded leaves transitioning from pale creamy heart to crimson ruffled edges.'
  },
  {
    id: 'g2',
    name: 'Wild Sylvetta Arugula',
    cultivar: 'Diplotaxis tenuifolia',
    category: 'greens',
    family: 'Brassicaceae',
    origin: 'Ancient wild European rocket',
    season: 'Spring',
    flavor: 'Spicy, nutty, sharp pungent mustard kick',
    image: 'https://images.unsplash.com/photo-1509358271058-acd22cc93898?auto=format&fit=crop&w=800&q=80',
    price: '$3.75 / bag',
    baseLikes: 341,
    description: 'Narrow deeply lobed rustic greens. Far more intense, peppery, and cold-resistant than commercial cultivated salad arugula.'
  },
  {
    id: 'g3',
    name: 'Tatsoi Spoon Mustard',
    cultivar: 'Brassica rapa rosularis',
    category: 'greens',
    family: 'Brassicaceae',
    origin: 'Traditional Asian winter green',
    season: 'Winter',
    flavor: 'Mild cabbage sweetness, dense dark spoons',
    image: 'https://images.unsplash.com/photo-1543362906-acfc16c67564?auto=format&fit=crop&w=800&q=80',
    price: '$3.50 / bunch',
    baseLikes: 271,
    description: 'Grows in dense circular rosettes hugging frosty ground. Thick, glossy spoon-shaped leaves with tender succulent white ribs.'
  },
  {
    id: 'g4',
    name: 'Red Ribbon Sorrel',
    cultivar: 'Rumex acetosa',
    category: 'greens',
    family: 'Polygonaceae',
    origin: 'Perennial European woodland herb',
    season: 'Spring',
    flavor: 'Crisp green apple tartness, citrus tang',
    image: 'https://images.unsplash.com/photo-1518531933037-91b2f5f229cc?auto=format&fit=crop&w=800&q=80',
    price: '$3.50 / bundle',
    baseLikes: 319,
    description: 'Spear-shaped leaves shot through with crimson venation. Provides an exhilarating citrus-tang burst in spring salads and fish sauces.'
  },
  {
    id: 'g5',
    name: 'Genovese Basil Heirloom',
    cultivar: 'Ocimum basilicum',
    category: 'greens',
    family: 'Lamiaceae',
    origin: 'Ligurian pesto heritage standard',
    season: 'Summer',
    flavor: 'Sweet anise fragrance, pure pesto essence',
    image: 'https://images.unsplash.com/photo-1608686207856-001b95cf60ca?auto=format&fit=crop&w=800&q=80',
    price: '$3.00 / bunch',
    baseLikes: 463,
    description: 'Large cupped leaves laden with volatile aromatic oils. Hand-pinched early in the morning before flowering to retain essential sweetness.'
  },
  {
    id: 'g6',
    name: 'Watercress Spring Greens',
    cultivar: 'Nasturtium officinale',
    category: 'greens',
    family: 'Brassicaceae',
    origin: 'Wild spring-fed cold watercress',
    season: 'Spring',
    flavor: 'Clean, pepper-sharp antioxidant powerhouse',
    image: 'https://images.unsplash.com/photo-1576045057995-568f588f82fb?auto=format&fit=crop&w=800&q=80',
    price: '$4.25 / bundle',
    baseLikes: 329,
    description: 'Harvested directly from our natural gravel-filtered spring beds. Incredibly crisp hollow stems with sharp, purifying watercress pungency.'
  },
];

const STORAGE_LIKES_KEY = 'hearth_organic_farm_likes_map_v1';
const STORAGE_USER_LIKED_KEY = 'hearth_organic_farm_user_liked_v1';

export const VarietiesPage: React.FC<VarietiesPageProps> = ({ onNavigate, onAddToCart }) => {
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'vegetables' | 'fruits' | 'seeds' | 'greens'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'likes' | 'name' | 'season' | 'family'>('likes');
  const [filterLikedOnly, setFilterLikedOnly] = useState(false);
  const [addedItem, setAddedItem] = useState<string | null>(null);
  const [detailModalItem, setDetailModalItem] = useState<HeirloomVariety | null>(null);
  
  // Likes system state with localStorage persistence
  const [likesMap, setLikesMap] = useState<Record<string, number>>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_LIKES_KEY);
      if (saved) return JSON.parse(saved);
    } catch {
      // Fallback
    }
    const initial: Record<string, number> = {};
    ALL_42_VARIETIES.forEach(v => {
      initial[v.id] = v.baseLikes;
    });
    return initial;
  });

  const [userLikedSet, setUserLikedSet] = useState<Record<string, boolean>>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_USER_LIKED_KEY);
      if (saved) return JSON.parse(saved);
    } catch {
      // Fallback
    }
    return {};
  });

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_LIKES_KEY, JSON.stringify(likesMap));
    } catch (e) {
      console.warn('Could not persist likesMap', e);
    }
  }, [likesMap]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_USER_LIKED_KEY, JSON.stringify(userLikedSet));
    } catch (e) {
      console.warn('Could not persist userLikedSet', e);
    }
  }, [userLikedSet]);

  const toggleLike = (varietyId: string, e?: React.MouseEvent) => {
    if (e) {
      e.stopPropagation();
    }
    const isCurrentlyLiked = !!userLikedSet[varietyId];
    setUserLikedSet(prev => ({
      ...prev,
      [varietyId]: !isCurrentlyLiked,
    }));
    setLikesMap(prev => {
      const current = prev[varietyId] ?? (ALL_42_VARIETIES.find(v => v.id === varietyId)?.baseLikes || 100);
      return {
        ...prev,
        [varietyId]: isCurrentlyLiked ? Math.max(0, current - 1) : current + 1,
      };
    });
  };

  const totalCommunityLikes = useMemo(() => {
    return Object.values(likesMap).reduce((sum, count) => sum + count, 0);
  }, [likesMap]);

  const userLikedCount = useMemo(() => {
    return Object.values(userLikedSet).filter(Boolean).length;
  }, [userLikedSet]);

  // Fallback category photo selector
  const getFallbackImage = (category: HeirloomVariety['category']) => {
    switch (category) {
      case 'fruits': return FARM_IMAGES.fruits;
      case 'seeds': return FARM_IMAGES.seeds;
      case 'greens': return FARM_IMAGES.greens;
      default: return FARM_IMAGES.vegetables;
    }
  };

  const filteredAndSortedVarieties = useMemo(() => {
    const list = ALL_42_VARIETIES.filter((v) => {
      const matchesCat = selectedCategory === 'all' || v.category === selectedCategory;
      const matchesSearch =
        v.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        v.cultivar.toLowerCase().includes(searchQuery.toLowerCase()) ||
        v.family.toLowerCase().includes(searchQuery.toLowerCase()) ||
        v.origin.toLowerCase().includes(searchQuery.toLowerCase()) ||
        v.flavor.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesLiked = !filterLikedOnly || !!userLikedSet[v.id];
      return matchesCat && matchesSearch && matchesLiked;
    });

    return list.sort((a, b) => {
      if (sortBy === 'likes') {
        const likesA = likesMap[a.id] ?? a.baseLikes;
        const likesB = likesMap[b.id] ?? b.baseLikes;
        return likesB - likesA;
      }
      if (sortBy === 'name') {
        return a.name.localeCompare(b.name);
      }
      if (sortBy === 'family') {
        return a.family.localeCompare(b.family);
      }
      if (sortBy === 'season') {
        const seasons = ['Spring', 'Summer', 'Autumn', 'Winter'];
        return seasons.indexOf(a.season) - seasons.indexOf(b.season);
      }
      return 0;
    });
  }, [selectedCategory, searchQuery, filterLikedOnly, userLikedSet, sortBy, likesMap]);

  const handleAddProduce = (v: HeirloomVariety, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (onAddToCart) {
      const mockProduceItem: ProduceItem = {
        id: v.id,
        name: v.name,
        category: v.category === 'seeds' ? 'seeds' : v.category === 'fruits' ? 'fruits' : 'vegetables',
        price: parseFloat(v.price.replace(/[^0-9.]/g, '')) || 4.5,
        unit: v.price.split('/')[1]?.trim() || 'unit',
        heirloomVariety: v.cultivar,
        description: `${v.flavor}. Ancestral origin: ${v.origin}.`,
        harvestWindow: `${v.season} Harvest`,
        organicCert: 'Demeter Biodynamic Certified Heirloom',
        inStock: true,
        image: v.image,
      };
      onAddToCart(mockProduceItem);
      setAddedItem(v.id);
      setTimeout(() => setAddedItem(null), 2000);
    }
  };

  return (
    <div className="w-full space-y-0">
      {/* 42 VARIETIES DEDICATED PROFESSIONAL HERO */}
      <section className="relative bg-earth-900 border-b border-earth-800 overflow-hidden">
        <div className="relative min-h-[480px] lg:min-h-[520px] flex items-center">
          <div className="absolute inset-0 z-0">
            <img
              src={FARM_IMAGES.vegetables}
              alt="Artisanal heirloom vegetables, rainbow carrots, and heirloom tomatoes"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-earth-950/95 via-earth-900/90 to-farm-green-950/70" />
          </div>

          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24 text-white">
            <div className="max-w-3xl space-y-5">
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-farm-green-300">
                <Dna className="w-4 h-4 text-farm-green-400" />
                <span>Living Genetic Diversity & Seed Preservation</span>
                <span aria-hidden="true" className="text-earth-400">·</span>
                <span className="text-terracotta-300">Open-Pollinated Strains</span>
              </div>

              <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-white leading-tight">
                42 Heirloom Varieties. Every Photo, Lineage & Community Favorite.
              </h1>

              <p className="text-base sm:text-lg text-earth-100/95 leading-relaxed font-normal max-w-2xl">
                Commercial industrial farming sacrificed 90% of global botanical genetics for machine packing. 
                We steward 42 distinct heritage cultivars — each individually photographed, cataloged with ancestral roots, 
                and voted by our community. Click the heart on your favorites to save them to your seasonal basket.
              </p>

              <div className="pt-2 flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={() => onNavigate('market')}
                  className="inline-flex items-center gap-2 px-6 py-3.5 text-xs font-semibold text-white bg-farm-green-700 hover:bg-farm-green-600 rounded-xl transition-all shadow-sm cursor-pointer"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>Shop Fresh Heirlooms in Market</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setSortBy('likes');
                    const element = document.getElementById('variety-grid');
                    element?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="inline-flex items-center gap-2 px-6 py-3.5 text-xs font-semibold text-white bg-terracotta-700 hover:bg-terracotta-600 rounded-xl transition-all cursor-pointer"
                >
                  <Flame className="w-4 h-4 text-terracotta-200" />
                  <span>Explore Most Liked Cultivars ({totalCommunityLikes.toLocaleString()} Likes)</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SUMMARY STATS & COMMUNITY LIKES STRIP */}
      <section className="bg-earth-100 border-b border-earth-200 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 text-center md:text-left">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-earth-200/80 text-earth-800">
                <Layers className="w-5 h-5" />
              </div>
              <div>
                <p className="text-2xl font-serif font-bold text-earth-900">42 Cultivars</p>
                <p className="text-xs text-earth-600">Photographed & documented</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-rose-100 text-rose-600">
                <Heart className="w-5 h-5 fill-rose-500" />
              </div>
              <div>
                <p className="text-2xl font-serif font-bold text-earth-900">
                  {totalCommunityLikes.toLocaleString()}
                </p>
                <p className="text-xs text-earth-600">Community heirloom likes</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-farm-green-100 text-farm-green-700">
                <Award className="w-5 h-5" />
              </div>
              <div>
                <p className="text-2xl font-serif font-bold text-farm-green-800">100% True-Seed</p>
                <p className="text-xs text-earth-600">Non-GMO, non-patented</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-terracotta-100 text-terracotta-700">
                <Calendar className="w-5 h-5" />
              </div>
              <div>
                <p className="text-2xl font-serif font-bold text-terracotta-700">
                  {userLikedCount > 0 ? `${userLikedCount} Saved` : '4 Seasons'}
                </p>
                <p className="text-xs text-earth-600">
                  {userLikedCount > 0 ? 'In your personal favorites' : 'Continuous living rotation'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* INTERACTIVE 42 VARIETIES DIRECTORY */}
      <section id="variety-grid" className="py-12 lg:py-20 bg-white border-b border-earth-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          
          {/* Controls Bar: Search, Category Tabs, Sorting, and Liked Filter */}
          <div className="space-y-4">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-farm-green-800">
                  <Sparkles className="w-3.5 h-3.5 text-farm-green-600" />
                  <span>Curated Botanical Catalog</span>
                </div>
                <h2 className="font-serif text-3xl sm:text-4xl font-bold text-earth-900 mt-1">
                  Explore All 42 Varieties & Photos
                </h2>
                <p className="text-xs sm:text-sm text-earth-600 mt-1">
                  Showing {filteredAndSortedVarieties.length} of 42 living heirloom cultivars with real-time community likes.
                </p>
              </div>

              {/* Search & Sort Controls */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                <div className="relative w-full sm:w-64">
                  <Search className="w-4 h-4 text-earth-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    placeholder="Search name, cultivar, origin..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-earth-300 focus:outline-none focus:border-farm-green-600 bg-earth-50 text-earth-900 placeholder-earth-400"
                  />
                  {searchQuery && (
                    <button
                      type="button"
                      onClick={() => setSearchQuery('')}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-earth-400 hover:text-earth-600 p-0.5 cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-earth-300 bg-earth-50 text-xs text-earth-800 shrink-0">
                    <SlidersHorizontal className="w-3.5 h-3.5 text-earth-500" />
                    <span className="text-[11px] font-medium text-earth-600">Sort:</span>
                    <select
                      value={sortBy}
                      onChange={(e) => setSortBy(e.target.value as any)}
                      aria-label="Sort varieties by"
                      className="bg-transparent font-semibold text-earth-900 focus:outline-none cursor-pointer"
                    >
                      <option value="likes">Most Liked ❤️</option>
                      <option value="name">Name (A-Z)</option>
                      <option value="season">Season</option>
                      <option value="family">Plant Family</option>
                    </select>
                  </div>

                  {/* Liked Only Toggle Filter */}
                  <button
                    type="button"
                    onClick={() => setFilterLikedOnly(!filterLikedOnly)}
                    className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer border ${
                      filterLikedOnly
                        ? 'bg-rose-50 border-rose-300 text-rose-700 shadow-2xs'
                        : 'bg-earth-50 border-earth-300 text-earth-700 hover:bg-earth-100'
                    }`}
                    title="Filter by items you liked"
                  >
                    <Heart className={`w-3.5 h-3.5 ${filterLikedOnly ? 'fill-rose-500 text-rose-500' : 'text-earth-400'}`} />
                    <span>My Liked ({userLikedCount})</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Category Filter Pills */}
            <div className="flex flex-wrap gap-2 pt-2 border-b border-earth-200 pb-4">
              <button
                type="button"
                onClick={() => setSelectedCategory('all')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  selectedCategory === 'all'
                    ? 'bg-earth-900 text-white shadow-2xs'
                    : 'bg-earth-100 text-earth-700 hover:bg-earth-200'
                }`}
              >
                All 42 Cultivars
              </button>
              <button
                type="button"
                onClick={() => setSelectedCategory('vegetables')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  selectedCategory === 'vegetables'
                    ? 'bg-earth-900 text-white shadow-2xs'
                    : 'bg-earth-100 text-earth-700 hover:bg-earth-200'
                }`}
              >
                Heirloom Vegetables (16)
              </button>
              <button
                type="button"
                onClick={() => setSelectedCategory('fruits')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  selectedCategory === 'fruits'
                    ? 'bg-earth-900 text-white shadow-2xs'
                    : 'bg-earth-100 text-earth-700 hover:bg-earth-200'
                }`}
              >
                Orchard Fruits (10)
              </button>
              <button
                type="button"
                onClick={() => setSelectedCategory('seeds')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  selectedCategory === 'seeds'
                    ? 'bg-earth-900 text-white shadow-2xs'
                    : 'bg-earth-100 text-earth-700 hover:bg-earth-200'
                }`}
              >
                Heritage Seeds & Legumes (10)
              </button>
              <button
                type="button"
                onClick={() => setSelectedCategory('greens')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  selectedCategory === 'greens'
                    ? 'bg-earth-900 text-white shadow-2xs'
                    : 'bg-earth-100 text-earth-700 hover:bg-earth-200'
                }`}
              >
                Salad Greens & Herbs (6)
              </button>
            </div>
          </div>

          {/* 42 Variety Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredAndSortedVarieties.map((v) => {
              const currentLikes = likesMap[v.id] ?? v.baseLikes;
              const isLiked = !!userLikedSet[v.id];

              return (
                <div
                  key={v.id}
                  onClick={() => setDetailModalItem(v)}
                  className="group bg-earth-50 rounded-2xl border border-earth-200 overflow-hidden flex flex-col justify-between hover:border-farm-green-600 hover:shadow-md transition-all duration-300 cursor-pointer"
                >
                  {/* Photo Header */}
                  <div className="relative aspect-4/3 overflow-hidden bg-earth-200">
                    <img
                      src={v.image}
                      alt={`${v.name} - ${v.cultivar}`}
                      loading="lazy"
                      referrerPolicy="no-referrer"
                      onError={(e) => {
                        (e.currentTarget as HTMLImageElement).src = getFallbackImage(v.category);
                      }}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    
                    {/* Dark gradient for text contrast */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/30" />

                    {/* Season Tag */}
                    <div className="absolute top-3 left-3 flex items-center gap-1.5">
                      <span className="px-2.5 py-1 text-[10px] font-semibold tracking-wide uppercase rounded-md bg-earth-950/75 text-white backdrop-blur-xs border border-white/20">
                        {v.season} Harvest
                      </span>
                    </div>

                    {/* Interactive Like Button Floating on Photo */}
                    <button
                      type="button"
                      onClick={(e) => toggleLike(v.id, e)}
                      aria-label={`${isLiked ? 'Unlike' : 'Like'} ${v.name}`}
                      className={`absolute top-3 right-3 flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold backdrop-blur-md transition-all cursor-pointer shadow-sm ${
                        isLiked
                          ? 'bg-rose-600 text-white border border-rose-400 scale-105'
                          : 'bg-earth-900/70 hover:bg-earth-900 text-white/90 hover:text-white border border-white/20'
                      }`}
                    >
                      <Heart
                        className={`w-3.5 h-3.5 transition-transform ${
                          isLiked ? 'fill-white text-white scale-110' : 'text-rose-300'
                        }`}
                      />
                      <span className="tabular-nums font-bold text-[11px]">{currentLikes}</span>
                    </button>

                    {/* Plant Family pill on photo bottom */}
                    <div className="absolute bottom-3 left-3 text-white">
                      <span className="text-[10px] font-mono tracking-wider uppercase px-2 py-0.5 rounded-sm bg-farm-green-900/80 backdrop-blur-xs text-farm-green-200 border border-farm-green-600/40">
                        {v.family}
                      </span>
                    </div>
                  </div>

                  {/* Card Content */}
                  <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                    <div className="space-y-1.5">
                      <div className="flex items-start justify-between gap-2">
                        <h3 className="font-serif text-lg sm:text-xl font-bold text-earth-900 group-hover:text-farm-green-800 transition-colors">
                          {v.name}
                        </h3>
                      </div>
                      <p className="text-[11px] font-mono text-earth-500 italic">
                        {v.cultivar}
                      </p>

                      <div className="pt-2 text-xs text-earth-700 space-y-1">
                        <p className="line-clamp-1">
                          <span className="font-semibold text-earth-900">Lineage:</span> {v.origin}
                        </p>
                        <p className="line-clamp-2">
                          <span className="font-semibold text-earth-900">Flavor:</span> {v.flavor}
                        </p>
                      </div>
                    </div>

                    {/* Bottom Action Bar */}
                    <div className="pt-3 border-t border-earth-200/90 flex items-center justify-between gap-2">
                      <div>
                        <span className="text-xs font-bold text-earth-900">{v.price}</span>
                        <p className="text-[10px] text-earth-500">Living heirloom</p>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setDetailModalItem(v);
                          }}
                          className="p-1.5 text-earth-600 hover:text-earth-900 hover:bg-earth-200 rounded-lg transition-colors cursor-pointer"
                          title="View variety story"
                        >
                          <Info className="w-4 h-4" />
                        </button>

                        <button
                          type="button"
                          onClick={(e) => handleAddProduce(v, e)}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-farm-green-800 hover:bg-farm-green-900 text-white transition-all cursor-pointer shadow-2xs"
                        >
                          {addedItem === v.id ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-farm-green-300" />
                              <span>Added</span>
                            </>
                          ) : (
                            <>
                              <ShoppingBag className="w-3.5 h-3.5" />
                              <span>Add</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Empty State */}
          {filteredAndSortedVarieties.length === 0 && (
            <div className="text-center py-16 text-earth-500 space-y-3 bg-earth-50 rounded-2xl border border-dashed border-earth-300 p-8">
              <Heart className="w-8 h-8 text-earth-400 mx-auto" />
              <p className="text-base font-serif text-earth-800 font-bold">
                No heirloom varieties found matching your criteria.
              </p>
              <p className="text-xs text-earth-500 max-w-md mx-auto">
                {filterLikedOnly 
                  ? 'You haven\'t liked any varieties in this category yet. Click the heart on any card to add it to your favorites!'
                  : 'Try adjusting your search query or switching categories.'}
              </p>
              <button
                type="button"
                onClick={() => {
                  setSelectedCategory('all');
                  setSearchQuery('');
                  setFilterLikedOnly(false);
                }}
                className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-farm-green-800 bg-earth-200 hover:bg-earth-300 rounded-xl transition-all cursor-pointer"
              >
                <span>Reset All Filters</span>
              </button>
            </div>
          )}
        </div>
      </section>

      {/* DETAIL MODAL FOR DEEP HERITAGE STORY & HIGH-RES PHOTO */}
      {detailModalItem && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-earth-950/70 backdrop-blur-xs animate-in fade-in duration-200"
          onClick={() => setDetailModalItem(null)}
        >
          <div
            className="relative w-full max-w-2xl bg-white rounded-3xl border border-earth-200 shadow-2xl overflow-hidden max-h-[90vh] flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Image Header */}
            <div className="relative aspect-16/9 w-full bg-earth-900 overflow-hidden shrink-0">
              <img
                src={detailModalItem.image}
                alt={detailModalItem.name}
                referrerPolicy="no-referrer"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src = getFallbackImage(detailModalItem.category);
                }}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
              
              <button
                type="button"
                onClick={() => setDetailModalItem(null)}
                className="absolute top-4 right-4 p-2 rounded-full bg-black/60 hover:bg-black text-white transition-colors cursor-pointer"
                title="Close"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="absolute bottom-4 left-5 right-5 text-white flex items-end justify-between">
                <div>
                  <span className="text-[11px] font-mono uppercase tracking-wider px-2 py-0.5 rounded bg-farm-green-800 text-farm-green-200">
                    {detailModalItem.family} • {detailModalItem.season} Harvest
                  </span>
                  <h3 className="font-serif text-2xl sm:text-3xl font-bold mt-1">
                    {detailModalItem.name}
                  </h3>
                  <p className="text-xs font-mono text-earth-300 italic">
                    {detailModalItem.cultivar}
                  </p>
                </div>

                {/* Big Interactive Like inside Modal */}
                <button
                  type="button"
                  onClick={() => toggleLike(detailModalItem.id)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-full text-xs font-bold transition-transform cursor-pointer shadow-md ${
                    userLikedSet[detailModalItem.id]
                      ? 'bg-rose-600 text-white'
                      : 'bg-white/90 hover:bg-white text-earth-900'
                  }`}
                >
                  <Heart
                    className={`w-4 h-4 ${
                      userLikedSet[detailModalItem.id]
                        ? 'fill-white text-white'
                        : 'text-rose-600 fill-rose-100'
                    }`}
                  />
                  <span>
                    {likesMap[detailModalItem.id] ?? detailModalItem.baseLikes} Likes
                  </span>
                </button>
              </div>
            </div>

            {/* Modal Body */}
            <div className="p-6 overflow-y-auto space-y-5 text-earth-800">
              <div className="space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-earth-500">
                  Botanical & Seed Lineage
                </h4>
                <p className="text-sm leading-relaxed text-earth-900">
                  {detailModalItem.description}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 rounded-2xl bg-earth-50 border border-earth-200 text-xs">
                <div>
                  <span className="font-bold text-earth-900">Ancestral Origin:</span>
                  <p className="text-earth-700 mt-0.5">{detailModalItem.origin}</p>
                </div>
                <div>
                  <span className="font-bold text-earth-900">Flavor Profile:</span>
                  <p className="text-earth-700 mt-0.5">{detailModalItem.flavor}</p>
                </div>
                <div>
                  <span className="font-bold text-earth-900">Harvest Window:</span>
                  <p className="text-earth-700 mt-0.5">{detailModalItem.season} Field Cycle</p>
                </div>
                <div>
                  <span className="font-bold text-earth-900">Market Price:</span>
                  <p className="text-farm-green-800 font-bold mt-0.5">{detailModalItem.price}</p>
                </div>
              </div>

              <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3 border-t border-earth-200">
                <div className="text-xs text-earth-500">
                  <span>Open-pollinated true seed. Zero synthetic inputs.</span>
                </div>

                <div className="flex items-center gap-2 w-full sm:w-auto">
                  <button
                    type="button"
                    onClick={() => {
                      handleAddProduce(detailModalItem);
                    }}
                    className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-farm-green-800 hover:bg-farm-green-900 text-white text-xs font-bold transition-all cursor-pointer"
                  >
                    {addedItem === detailModalItem.id ? (
                      <>
                        <Check className="w-4 h-4 text-farm-green-300" />
                        <span>Added to Harvest Basket!</span>
                      </>
                    ) : (
                      <>
                        <ShoppingBag className="w-4 h-4" />
                        <span>Add {detailModalItem.name} ({detailModalItem.price})</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* BOTTOM ACTION BAR */}
      <section className="py-16 bg-earth-900 text-white text-center">
        <div className="max-w-2xl mx-auto px-4 space-y-5">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-farm-green-900/80 text-farm-green-300 text-xs font-semibold border border-farm-green-700/50">
            <Heart className="w-3.5 h-3.5 fill-rose-500 text-rose-500" />
            <span>Community Favorite Seeds</span>
          </div>

          <h2 className="font-serif text-3xl sm:text-4xl font-bold">
            Taste All 42 Varieties Across the 4 Seasons
          </h2>
          <p className="text-xs sm:text-sm text-earth-200 leading-relaxed">
            Every week our CSA members receive a curated crate containing peak seasonal picks from this 42-variety directory.
            Vote for your favorites and join our seasonal harvest rotation.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4 pt-3">
            <button
              type="button"
              onClick={() => onNavigate('market')}
              className="px-6 py-3.5 text-xs font-bold text-earth-900 bg-white hover:bg-earth-100 rounded-xl transition-all cursor-pointer shadow-sm"
            >
              Order Weekly Farm Share Box
            </button>
            <button
              type="button"
              onClick={() => onNavigate('spring')}
              className="inline-flex items-center gap-2 px-6 py-3.5 text-xs font-bold text-white bg-farm-green-700 hover:bg-farm-green-600 rounded-xl transition-all cursor-pointer shadow-sm"
            >
              <span>Explore Spring Varieties</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
