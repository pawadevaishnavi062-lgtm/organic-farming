import React, { useState, useEffect } from 'react';
import { PageId } from '../components/Header';
import { FARM_IMAGES } from '../data/farmData';
import { 
  User, 
  Lock, 
  Mail, 
  ArrowRight, 
  CheckCircle2, 
  ShoppingBag, 
  Calendar, 
  MapPin, 
  Clock, 
  ShieldCheck, 
  Sparkles, 
  LogOut, 
  Edit3, 
  Eye, 
  EyeOff, 
  Package, 
  ChevronRight,
  Heart,
  Truck
} from 'lucide-react';

interface LoginPageProps {
  onNavigate: (page: PageId) => void;
  currentUser?: UserProfile | null;
  onLogin?: (user: UserProfile) => void;
  onLogout?: () => void;
}

export interface UserProfile {
  name: string;
  email: string;
  memberId: string;
  memberTier: 'Hearth Master Share' | 'Field Sprout Share' | 'Heritage Patron' | 'Farm Visitor';
  memberSince: string;
  nextDeliveryDate: string;
  deliveryWindow: string;
  address: string;
  deliveryNotes: string;
  boxContents: string[];
  recentOrdersCount: number;
}

const DEMO_USERS: Record<string, UserProfile> = {
  elena: {
    name: 'Elena Rostova',
    email: 'elena.rostova@farmstead.org',
    memberId: 'CSA-8492',
    memberTier: 'Hearth Master Share',
    memberSince: 'March 2023',
    nextDeliveryDate: 'This Thursday, Nov 6',
    deliveryWindow: '8:00 AM – 11:30 AM',
    address: '428 Riverbend Woods Way, Portland, OR',
    deliveryNotes: 'Leave in insulated cedar cooler on covered front porch. Gate code: #4102.',
    boxContents: [
      'Rainbow Heirloom Carrots (bunch)',
      'Lacinato Dinosaur Kale',
      'Chioggia Candy-Stripe Beets',
      'Heritage Honeycrisp Apples (3 lb)',
      'Black Mission Figs (pint)',
      'Speckled Calypso Dry Beans (1 lb)'
    ],
    recentOrdersCount: 24,
  },
  marcus: {
    name: 'Marcus Vance',
    email: 'marcus.vance@livingsoil.net',
    memberId: 'CSA-3104',
    memberTier: 'Field Sprout Share',
    memberSince: 'September 2024',
    nextDeliveryDate: 'Next Tuesday, Nov 11',
    deliveryWindow: '1:00 PM – 4:00 PM',
    address: '814 Hawthorn Bluff, Hood River, OR',
    deliveryNotes: 'Ring bell upon drop-off. Side garden latch is unlocked.',
    boxContents: [
      'Butterhead Four Seasons Lettuce',
      'French Breakfast Radishes',
      'Sugar Snap Peas',
      'Costata Romanesco Zucchini'
    ],
    recentOrdersCount: 8,
  },
};

export const LoginPage: React.FC<LoginPageProps> = ({ 
  onNavigate, 
  currentUser: initialUser, 
  onLogin, 
  onLogout 
}) => {
  const [activeTab, setActiveTab] = useState<'signin' | 'register'>('signin');
  const [showPassword, setShowPassword] = useState(false);
  
  // Sign-in form state
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(true);
  
  // Registration form state
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regTier, setRegTier] = useState<UserProfile['memberTier']>('Hearth Master Share');
  const [regAddress, setRegAddress] = useState('');

  // Active user in local state
  const [user, setUser] = useState<UserProfile | null>(() => {
    if (initialUser) return initialUser;
    try {
      const saved = localStorage.getItem('verdant_roots_user_session');
      if (saved) return JSON.parse(saved);
    } catch {
      // Ignore
    }
    return null;
  });

  const [notification, setNotification] = useState<string | null>(null);
  const [showEditNotes, setShowEditNotes] = useState(false);
  const [deliveryNotes, setDeliveryNotes] = useState(user?.deliveryNotes || '');

  // Keep deliveryNotes synced if user changes
  useEffect(() => {
    if (user) {
      setDeliveryNotes(user.deliveryNotes);
    }
  }, [user]);

  const handleSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setNotification('Please fill in both email and password.');
      return;
    }
    // Authenticate or fallback
    const matched = Object.values(DEMO_USERS).find(u => u.email.toLowerCase() === email.toLowerCase());
    const loggedUser: UserProfile = matched || {
      name: email.split('@')[0].replace('.', ' ').replace(/^./, str => str.toUpperCase()),
      email,
      memberId: `CSA-${Math.floor(1000 + Math.random() * 9000)}`,
      memberTier: 'Hearth Master Share',
      memberSince: 'November 2026',
      nextDeliveryDate: 'This Thursday, Nov 6',
      deliveryWindow: '8:00 AM – 11:30 AM',
      address: '104 Orchard Valley Drive',
      deliveryNotes: 'Leave in shaded porch box.',
      boxContents: ['Rainbow Heirloom Carrots', 'Lacinato Kale', 'Heritage Apples', 'Speckled Calypso Beans'],
      recentOrdersCount: 1,
    };

    saveSession(loggedUser);
    setNotification('Signed in successfully! Welcome to your farmstead portal.');
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (!regName || !regEmail || !regPassword) {
      setNotification('Please complete all registration fields.');
      return;
    }

    const newUser: UserProfile = {
      name: regName,
      email: regEmail,
      memberId: `CSA-${Math.floor(1000 + Math.random() * 9000)}`,
      memberTier: regTier,
      memberSince: 'November 2026',
      nextDeliveryDate: 'Next Thursday, Nov 13',
      deliveryWindow: '8:00 AM – 11:30 AM',
      address: regAddress || 'Your farm delivery address',
      deliveryNotes: 'Leave by front entryway in reusable tote.',
      boxContents: [
        'Seasonal Hearth Harvest Crate (12-14 items)',
        'Estate Raw Honey Jar',
        'Dawn Fresh Greens'
      ],
      recentOrdersCount: 0,
    };

    saveSession(newUser);
    setNotification('Welcome to Verdant Roots CSA! Your membership account is activated.');
  };

  const handleQuickDemoLogin = (key: 'elena' | 'marcus') => {
    const demo = DEMO_USERS[key];
    saveSession(demo);
    setNotification(`Signed in as ${demo.name} (${demo.memberTier}).`);
  };

  const saveSession = (profile: UserProfile) => {
    setUser(profile);
    try {
      localStorage.setItem('verdant_roots_user_session', JSON.stringify(profile));
    } catch (e) {
      console.warn('Could not save session', e);
    }
    if (onLogin) onLogin(profile);
  };

  const handleSignOut = () => {
    setUser(null);
    try {
      localStorage.removeItem('verdant_roots_user_session');
    } catch (e) {
      console.warn('Could not remove session', e);
    }
    if (onLogout) onLogout();
    setNotification('Signed out of member portal.');
  };

  const handleSaveNotes = () => {
    if (!user) return;
    const updated = { ...user, deliveryNotes };
    saveSession(updated);
    setShowEditNotes(false);
    setNotification('Delivery instructions updated successfully.');
  };

  return (
    <div className="w-full bg-earth-50 min-h-[calc(100vh-80px)]">
      {/* TOP NOTIFICATION BANNER */}
      {notification && (
        <div className="bg-farm-green-900 text-white text-xs py-2.5 px-4 text-center border-b border-farm-green-800 flex items-center justify-center gap-2 animate-in fade-in">
          <Sparkles className="w-4 h-4 text-farm-green-300" />
          <span>{notification}</span>
          <button 
            type="button" 
            onClick={() => setNotification(null)}
            className="ml-3 text-farm-green-300 hover:text-white underline cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* IF LOGGED IN: MEMBER DASHBOARD */}
      {user ? (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16 space-y-8">
          {/* Header Profile Banner */}
          <div className="bg-earth-900 rounded-3xl p-6 sm:p-10 text-white relative overflow-hidden border border-earth-800 shadow-xl">
            <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <span className="px-3 py-1 rounded-full text-[11px] font-bold bg-farm-green-800/90 text-farm-green-200 border border-farm-green-600/50 uppercase tracking-wider">
                    {user.memberTier}
                  </span>
                  <span className="text-earth-400 text-xs">· Member #{user.memberId}</span>
                </div>
                <h1 className="font-serif text-3xl sm:text-4xl font-bold tracking-tight">
                  Welcome back, {user.name}
                </h1>
                <p className="text-xs sm:text-sm text-earth-300 max-w-xl">
                  Living Soil Member since {user.memberSince} • 100% Biodynamic Harvest Deliveries
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={() => onNavigate('market')}
                  className="px-5 py-2.5 rounded-xl text-xs font-bold bg-farm-green-700 hover:bg-farm-green-600 text-white transition-all cursor-pointer shadow-sm flex items-center gap-2"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>Farm Marketplace</span>
                </button>
                <button
                  type="button"
                  onClick={handleSignOut}
                  className="px-4 py-2.5 rounded-xl text-xs font-semibold bg-earth-800 hover:bg-earth-700 text-earth-200 hover:text-white border border-earth-700 transition-all cursor-pointer flex items-center gap-2"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Sign Out</span>
                </button>
              </div>
            </div>

            {/* Subtle background graphic */}
            <div className="absolute right-0 top-0 bottom-0 w-1/3 opacity-10 pointer-events-none bg-gradient-to-l from-white to-transparent" />
          </div>

          {/* Grid: Next Delivery Status & Active Share Customization */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left 2 Cols: Next Delivery Card */}
            <div className="lg:col-span-2 space-y-6">
              {/* Delivery Alert Card */}
              <div className="bg-white rounded-3xl p-6 sm:p-8 border border-earth-200 shadow-xs space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-earth-200 gap-4">
                  <div className="flex items-center gap-3">
                    <div className="p-3 rounded-2xl bg-farm-green-100 text-farm-green-800">
                      <Truck className="w-6 h-6" />
                    </div>
                    <div>
                      <span className="text-[11px] font-bold uppercase tracking-wider text-farm-green-800">
                        Next Dispatch
                      </span>
                      <h2 className="font-serif text-xl sm:text-2xl font-bold text-earth-900">
                        {user.nextDeliveryDate}
                      </h2>
                    </div>
                  </div>

                  <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-earth-100 text-earth-800 text-xs font-semibold">
                    <Clock className="w-3.5 h-3.5 text-earth-500" />
                    <span>{user.deliveryWindow}</span>
                  </div>
                </div>

                {/* Box Contents Breakdown */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-earth-600 flex items-center gap-2">
                      <Package className="w-4 h-4 text-earth-700" />
                      <span>Scheduled Harvest Share Crate Items</span>
                    </h3>
                    <span className="text-[11px] text-earth-500">Picked at dawn within 24h</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {user.boxContents.map((item, idx) => (
                      <div
                        key={idx}
                        className="flex items-center gap-2.5 p-3 rounded-xl bg-earth-50 border border-earth-200/80 text-xs text-earth-800"
                      >
                        <CheckCircle2 className="w-4 h-4 text-farm-green-700 shrink-0" />
                        <span className="font-medium">{item}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Delivery Address & Notes */}
                <div className="p-4 rounded-2xl bg-earth-50/70 border border-earth-200 space-y-3 text-xs">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2 font-bold text-earth-900">
                      <MapPin className="w-4 h-4 text-terracotta-700 shrink-0" />
                      <span>Delivery Drop-off Address:</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setShowEditNotes(!showEditNotes)}
                      className="text-farm-green-800 font-bold hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <Edit3 className="w-3 h-3" />
                      <span>{showEditNotes ? 'Cancel' : 'Edit Drop Instructions'}</span>
                    </button>
                  </div>
                  <p className="text-earth-700 pl-6">{user.address}</p>

                  {!showEditNotes ? (
                    <div className="pl-6 pt-1 text-[11px] text-earth-600 italic">
                      Instructions: "{user.deliveryNotes}"
                    </div>
                  ) : (
                    <div className="pl-6 pt-2 space-y-2">
                      <textarea
                        value={deliveryNotes}
                        onChange={(e) => setDeliveryNotes(e.target.value)}
                        className="w-full p-2.5 rounded-xl border border-earth-300 text-xs text-earth-900 bg-white focus:outline-none focus:border-farm-green-700"
                        rows={2}
                        placeholder="Instructions for the farm electric delivery driver..."
                      />
                      <button
                        type="button"
                        onClick={handleSaveNotes}
                        className="px-4 py-1.5 rounded-lg text-xs font-bold bg-farm-green-800 hover:bg-farm-green-900 text-white cursor-pointer"
                      >
                        Save Instructions
                      </button>
                    </div>
                  )}
                </div>

                {/* Action Buttons */}
                <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => onNavigate('market')}
                    className="text-xs font-bold text-farm-green-800 hover:text-farm-green-900 flex items-center gap-1 cursor-pointer"
                  >
                    <span>Add Extra Heritage Eggs or Honey to this delivery &rarr;</span>
                  </button>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setNotification('Your delivery for this Thursday has been paused for vacation hold.')}
                      className="px-3.5 py-1.5 rounded-xl text-xs font-semibold text-earth-700 bg-earth-100 hover:bg-earth-200 transition-colors cursor-pointer"
                    >
                      Pause Delivery
                    </button>
                    <button
                      type="button"
                      onClick={() => onNavigate('varieties')}
                      className="px-3.5 py-1.5 rounded-xl text-xs font-semibold text-white bg-earth-900 hover:bg-earth-800 transition-colors cursor-pointer"
                    >
                      Browse Heirlooms
                    </button>
                  </div>
                </div>
              </div>

              {/* Quick Links: Produce Guides */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <button
                  type="button"
                  onClick={() => onNavigate('vegetables')}
                  className="p-5 rounded-2xl bg-white border border-earth-200 hover:border-farm-green-600 text-left transition-all group cursor-pointer shadow-xs"
                >
                  <span className="text-[11px] font-bold text-farm-green-800 uppercase tracking-wider">
                    Crop Guide
                  </span>
                  <h4 className="font-serif text-lg font-bold text-earth-900 group-hover:text-farm-green-800 transition-colors mt-0.5">
                    Heirloom Vegetables Deep Dive &rarr;
                  </h4>
                  <p className="text-xs text-earth-600 mt-1">
                    Polyphenol profiles, nightshades, root cellaring & soil microbiology.
                  </p>
                </button>

                <button
                  type="button"
                  onClick={() => onNavigate('fruits')}
                  className="p-5 rounded-2xl bg-white border border-earth-200 hover:border-terracotta-600 text-left transition-all group cursor-pointer shadow-xs"
                >
                  <span className="text-[11px] font-bold text-terracotta-700 uppercase tracking-wider">
                    Orchard Guide
                  </span>
                  <h4 className="font-serif text-lg font-bold text-earth-900 group-hover:text-terracotta-700 transition-colors mt-0.5">
                    Orchard Fruits & Sugar Brix &rarr;
                  </h4>
                  <p className="text-xs text-earth-600 mt-1">
                    Heritage honeycrisp apples, Franciscan figs, stone fruits & native bees.
                  </p>
                </button>
              </div>
            </div>

            {/* Right Col: Account Perks & Membership Details */}
            <div className="space-y-6">
              <div className="bg-white rounded-3xl p-6 border border-earth-200 shadow-xs space-y-5">
                <h3 className="font-serif text-lg font-bold text-earth-900">
                  Member Benefits & Impact
                </h3>

                <div className="space-y-4 text-xs">
                  <div className="flex items-start gap-3">
                    <ShieldCheck className="w-5 h-5 text-farm-green-700 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-bold text-earth-900">100% Living Soil Guaranteed</p>
                      <p className="text-earth-600 mt-0.5">Zero synthetic chemicals, glyphosates, or artificial waxes touch your food.</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Heart className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-bold text-earth-900">Priority Heirloom Seed Drops</p>
                      <p className="text-earth-600 mt-0.5">Exclusive first access to limited harvest Black Mission Figs and Cherokee Purple tomatoes.</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Calendar className="w-5 h-5 text-terracotta-700 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-bold text-earth-900">Complimentary Orchard Tours</p>
                      <p className="text-earth-600 mt-0.5">2 free farm walking tour passes included each season for members.</p>
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t border-earth-200">
                  <button
                    type="button"
                    onClick={() => onNavigate('tours')}
                    className="w-full py-2.5 rounded-xl text-xs font-bold text-farm-green-900 bg-farm-green-50 hover:bg-farm-green-100 border border-farm-green-200 transition-colors cursor-pointer"
                  >
                    Book Member Farm Walking Tour
                  </button>
                </div>
              </div>

              {/* Past Deliveries Mini-Widget */}
              <div className="bg-earth-100/70 rounded-3xl p-6 border border-earth-200 space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-earth-700">
                  Your Farmstead History
                </h4>
                <div className="text-xs space-y-1.5 text-earth-800">
                  <p><strong className="text-earth-900">Total Boxes Enjoyed:</strong> {user.recentOrdersCount} deliveries</p>
                  <p><strong className="text-earth-900">Soil Stewardship:</strong> 120 lbs compost funded</p>
                  <p><strong className="text-earth-900">Carbon Offset:</strong> 100% electric van routes</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* IF NOT LOGGED IN: PROFESSIONAL AUTH PORTAL */
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-20">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            {/* Left Col: Brand Presentation & Heritage Imagery (5 cols) */}
            <div className="lg:col-span-5 space-y-6">
              <div className="space-y-3">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-farm-green-100 text-farm-green-800 border border-farm-green-300">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>CSA Member Portal & Farmstand Sign-In</span>
                </div>
                <h1 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-earth-900 leading-tight">
                  Welcome to Your Living Soil Community
                </h1>
                <p className="text-xs sm:text-sm text-earth-700 leading-relaxed font-normal">
                  Manage weekly CSA farm boxes, customize harvest selections, monitor dawn dispatch windows, 
                  and save your favorite heirloom seed cultivars.
                </p>
              </div>

              {/* Farm Image Card */}
              <div className="relative rounded-3xl overflow-hidden aspect-16/10 border border-earth-200 shadow-md">
                <img
                  src={FARM_IMAGES.harvestBasket}
                  alt="Harvest crate filled with fresh organic vegetables"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                <div className="absolute bottom-4 left-5 right-5 text-white space-y-1">
                  <p className="font-serif text-base font-bold">180 Acres • 42 Heirlooms • 0% Synthetics</p>
                  <p className="text-xs text-earth-200">Dawn-harvested produce delivered right to your door.</p>
                </div>
              </div>

              {/* Quick Demo Login Triggers */}
              <div className="p-4 rounded-2xl bg-white border border-earth-200 space-y-2.5">
                <span className="text-[11px] font-bold uppercase tracking-wider text-earth-600 block">
                  Quick Demo Accounts (Instant 1-Click Sign In):
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => handleQuickDemoLogin('elena')}
                    className="p-2.5 rounded-xl bg-earth-50 hover:bg-earth-100 border border-earth-200 text-left transition-colors cursor-pointer"
                  >
                    <p className="text-xs font-bold text-earth-900">Elena Rostova</p>
                    <p className="text-[10px] text-farm-green-800 font-medium">Hearth Box Member (Full)</p>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleQuickDemoLogin('marcus')}
                    className="p-2.5 rounded-xl bg-earth-50 hover:bg-earth-100 border border-earth-200 text-left transition-colors cursor-pointer"
                  >
                    <p className="text-xs font-bold text-earth-900">Marcus Vance</p>
                    <p className="text-[10px] text-terracotta-700 font-medium">Field Sprout Member</p>
                  </button>
                </div>
              </div>
            </div>

            {/* Right Col: Sign In / Registration Form Card (7 cols) */}
            <div className="lg:col-span-7">
              <div className="bg-white rounded-3xl border border-earth-200 shadow-lg p-6 sm:p-10 space-y-6">
                {/* Tabs */}
                <div className="flex border-b border-earth-200">
                  <button
                    type="button"
                    onClick={() => setActiveTab('signin')}
                    className={`flex-1 pb-4 text-center text-sm font-serif font-bold transition-colors cursor-pointer ${
                      activeTab === 'signin'
                        ? 'border-b-2 border-farm-green-800 text-farm-green-900'
                        : 'text-earth-500 hover:text-earth-800'
                    }`}
                  >
                    Member Sign In
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveTab('register')}
                    className={`flex-1 pb-4 text-center text-sm font-serif font-bold transition-colors cursor-pointer ${
                      activeTab === 'register'
                        ? 'border-b-2 border-farm-green-800 text-farm-green-900'
                        : 'text-earth-500 hover:text-earth-800'
                    }`}
                  >
                    Join CSA / Create Account
                  </button>
                </div>

                {/* SIGN IN FORM */}
                {activeTab === 'signin' && (
                  <form onSubmit={handleSignIn} className="space-y-4">
                    <div className="space-y-1.5">
                      <label className="block text-xs font-semibold text-earth-800">
                        Email Address
                      </label>
                      <div className="relative">
                        <Mail className="w-4 h-4 text-earth-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                        <input
                          type="email"
                          required
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          placeholder="elena.rostova@farmstead.org"
                          className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-earth-300 text-xs text-earth-900 focus:outline-none focus:border-farm-green-700 bg-earth-50/50"
                        />
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <label className="block text-xs font-semibold text-earth-800">
                          Password
                        </label>
                        <button
                          type="button"
                          onClick={() => setNotification('Password reset link sent to registered email address.')}
                          className="text-[11px] text-farm-green-800 hover:underline cursor-pointer"
                        >
                          Forgot password?
                        </button>
                      </div>
                      <div className="relative">
                        <Lock className="w-4 h-4 text-earth-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                        <input
                          type={showPassword ? 'text' : 'password'}
                          required
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          placeholder="••••••••••••"
                          className="w-full pl-10 pr-10 py-2.5 rounded-xl border border-earth-300 text-xs text-earth-900 focus:outline-none focus:border-farm-green-700 bg-earth-50/50"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3.5 top-1/2 -translate-y-1/2 text-earth-400 hover:text-earth-600 p-0.5 cursor-pointer"
                        >
                          {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-1">
                      <label className="flex items-center gap-2 text-xs text-earth-700 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={rememberMe}
                          onChange={(e) => setRememberMe(e.target.checked)}
                          className="rounded text-farm-green-800 focus:ring-farm-green-600"
                        />
                        <span>Remember my login session</span>
                      </label>
                    </div>

                    <button
                      type="submit"
                      className="w-full py-3 px-4 rounded-xl text-xs font-bold text-white bg-farm-green-800 hover:bg-farm-green-900 transition-all flex items-center justify-center gap-2 cursor-pointer shadow-sm"
                    >
                      <span>Sign In to Member Portal</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </form>
                )}

                {/* REGISTRATION FORM */}
                {activeTab === 'register' && (
                  <form onSubmit={handleRegister} className="space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-1.5">
                        <label className="block text-xs font-semibold text-earth-800">
                          Full Name
                        </label>
                        <input
                          type="text"
                          required
                          value={regName}
                          onChange={(e) => setRegName(e.target.value)}
                          placeholder="Maya Lin"
                          className="w-full px-3.5 py-2.5 rounded-xl border border-earth-300 text-xs text-earth-900 focus:outline-none focus:border-farm-green-700 bg-earth-50/50"
                        />
                      </div>

                      <div className="space-y-1.5">
                        <label className="block text-xs font-semibold text-earth-800">
                          Email Address
                        </label>
                        <input
                          type="email"
                          required
                          value={regEmail}
                          onChange={(e) => setRegEmail(e.target.value)}
                          placeholder="maya@example.com"
                          className="w-full px-3.5 py-2.5 rounded-xl border border-earth-300 text-xs text-earth-900 focus:outline-none focus:border-farm-green-700 bg-earth-50/50"
                        />
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <label className="block text-xs font-semibold text-earth-800">
                        Select Farm Share Subscription
                      </label>
                      <select
                        value={regTier}
                        onChange={(e) => setRegTier(e.target.value as any)}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-earth-300 text-xs text-earth-900 focus:outline-none focus:border-farm-green-700 bg-earth-50/50 cursor-pointer"
                      >
                        <option value="Hearth Master Share">The Hearth Harvest Box ($42/wk - 12-14 varieties)</option>
                        <option value="Field Sprout Share">The Sprout Box ($26/wk - 6-8 varieties)</option>
                        <option value="Heritage Patron">Heritage Master Feast ($58/wk + Raw Honey & Flour)</option>
                        <option value="Farm Visitor">Farm Visitor / Farmstand Account (Pay-as-you-go)</option>
                      </select>
                    </div>

                    <div className="space-y-1.5">
                      <label className="block text-xs font-semibold text-earth-800">
                        Delivery Address
                      </label>
                      <input
                        type="text"
                        value={regAddress}
                        onChange={(e) => setRegAddress(e.target.value)}
                        placeholder="Street Address, City, Zip Code"
                        className="w-full px-3.5 py-2.5 rounded-xl border border-earth-300 text-xs text-earth-900 focus:outline-none focus:border-farm-green-700 bg-earth-50/50"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="block text-xs font-semibold text-earth-800">
                        Create Password
                      </label>
                      <input
                        type="password"
                        required
                        value={regPassword}
                        onChange={(e) => setRegPassword(e.target.value)}
                        placeholder="Minimum 8 characters"
                        className="w-full px-3.5 py-2.5 rounded-xl border border-earth-300 text-xs text-earth-900 focus:outline-none focus:border-farm-green-700 bg-earth-50/50"
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full py-3 px-4 rounded-xl text-xs font-bold text-white bg-farm-green-800 hover:bg-farm-green-900 transition-all flex items-center justify-center gap-2 cursor-pointer shadow-sm"
                    >
                      <span>Create Account & Join Living Soil Share</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </form>
                )}

                <div className="pt-4 border-t border-earth-200 text-center text-xs text-earth-600">
                  <span>Questions about membership? Call the farmstead office at </span>
                  <a href="tel:5035550192" className="text-farm-green-800 font-bold hover:underline">
                    (503) 555-0192
                  </a>
                </div>
              </div>
            </div>

          </div>
        </div>
      )}
    </div>
  );
};
