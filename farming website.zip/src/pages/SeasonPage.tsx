import React from 'react';
import { FARM_IMAGES } from '../data/farmData';
import { ProduceItem } from '../types/farm';
import { ArrowRight, Calendar, Leaf, Sun, CloudRain, Snowflake, Check, Plus, ChefHat, Sparkles } from 'lucide-react';

export type SeasonType = 'spring' | 'summer' | 'autumn' | 'winter';

interface SeasonConfig {
  id: SeasonType;
  title: string;
  tagline: string;
  months: string;
  heroImage: string;
  kicker: string;
  description: string;
  agronomyTitle: string;
  agronomyDetails: string[];
  crops: {
    id: string;
    name: string;
    variety: string;
    status: string;
    flavor: string;
    price: number;
    unit: string;
    image: string;
  }[];
  recipe: {
    title: string;
    time: string;
    ingredients: string[];
    instructions: string;
  };
}

export const SEASONS_CONFIG: Record<SeasonType, SeasonConfig> = {
  spring: {
    id: 'spring',
    title: 'Spring Harvest: Awakening & Tender Greens',
    tagline: 'The soil microbiome awakens as daylight lengthens and frost recedes.',
    months: 'March — May',
    heroImage: FARM_IMAGES.greens,
    kicker: 'The Vernal Equinox & High-Tunnel Awakening',
    description:
      'Spring on our farmstead is a celebration of crisp vibrancy. As winter cover crops are crimped to feed the earthworms, our high-tunnel hoop houses burst with tender salad greens, sweet Nantes carrots, and peppery radishes harvested with morning dew.',
    agronomyTitle: 'Spring Soil Biology & Practices',
    agronomyDetails: [
      'Broadfork bed aeration to gently wake aerobic fungal networks without mechanical rototilling.',
      'Crimping winter crimson clover to create a living green manure blanket rich in atmospheric nitrogen.',
      'Transplanting over 20,000 cold-hardy brassica seedlings into compost-warmed beds.',
      'Sowing early pollinator borders with borage, sweet alyssum, and calendula for early emerging bumblebees.',
    ],
    crops: [
      {
        id: 'spring-spinach',
        name: 'Bloomsdale Savoy Spinach',
        variety: '1925 Heirloom Savoy',
        status: 'Peak Harvest',
        flavor: 'Thick, succulent leaves with natural sweetness unlocked by cool spring mornings.',
        price: 3.75,
        unit: 'Large bunch (~1 lb)',
        image: FARM_IMAGES.greens,
      },
      {
        id: 'spring-radish',
        name: 'French Breakfast & Watermelon Radishes',
        variety: 'Heritage Bi-Color Roots',
        status: 'Peak Harvest',
        flavor: 'Aquatic, peppery crunch with tender greens ideal for farmstead sautéing.',
        price: 3.5,
        unit: 'Bunch with tops',
        image: FARM_IMAGES.vegetables,
      },
      {
        id: 'spring-peas',
        name: 'Super Sugar Snap Peas',
        variety: 'Open-Pollinated Trellised Vine',
        status: 'Peak Harvest',
        flavor: 'Juicy, edible pods bursting with early botanical sugars; eaten raw straight from the vine.',
        price: 4.5,
        unit: 'Pint carton (~12 oz)',
        image: FARM_IMAGES.greens,
      },
      {
        id: 'spring-carrots',
        name: 'Little Finger Nantes Carrots',
        variety: 'Early French Landrace',
        status: 'Emerging Harvest',
        flavor: 'Exceptionally tender cores with delicate sweet aromatics; zero bitterness.',
        price: 4.25,
        unit: 'Early bunch (~1 lb)',
        image: FARM_IMAGES.vegetables,
      },
      {
        id: 'spring-kale',
        name: 'Tuscan Baby Dinosaur Kale',
        variety: 'Cavolo Nero',
        status: 'Peak Harvest',
        flavor: 'Silky, mineral-rich leaves perfect for raw massage salads with lemon and olive oil.',
        price: 3.75,
        unit: 'Fresh bunch (~1 lb)',
        image: FARM_IMAGES.greens,
      },
      {
        id: 'spring-herbs',
        name: 'Wild Chives & Chervil Bouquet',
        variety: 'Perennial Herb Bed Harvest',
        status: 'Peak Harvest',
        flavor: 'Delicate anise and mild onion notes that define classic spring culinary dishes.',
        price: 3.0,
        unit: 'Fresh bouquet',
        image: FARM_IMAGES.greens,
      },
    ],
    recipe: {
      title: 'Spring Shaved Radish & Tender Greens with Wildflower Vinaigrette',
      time: '15 Minutes · No Cooking Required',
      ingredients: [
        '1 bunch French Breakfast radishes, thinly mandoline-shaved',
        '1 tub Bloomsdale baby spinach & arugula',
        '3 tbsp estate raw wildflower honey',
        '2 tbsp Meyer lemon juice',
        'Cold-pressed extra virgin olive oil & flaky sea salt',
      ],
      instructions:
        'Toss shaved radishes with ice water for 5 minutes for maximum crunch. Whisk wildflower honey, lemon juice, and olive oil. Gently dress tender greens and top with radish rounds and edible borage flowers.',
    },
  },

  summer: {
    id: 'summer',
    title: 'Summer Harvest: Peak Solar Abundance',
    tagline: 'Vibrant sun-drenched vine crops, heirloom nightshades, and sweet orchard fruits.',
    months: 'June — August',
    heroImage: FARM_IMAGES.hero,
    kicker: 'The Solar Zenith & Vine-Ripened Glory',
    description:
      'Summer is the high crescendo of the farmstead year. Our fields hum with resident honeybees and predatory dragonflies. Heirloom tomatoes ripen to deep purple and sunburst gold, sweet peppers turn fire-engine red, and stone-ground heritage flours are milled for harvest gatherings.',
    agronomyTitle: 'Summer Soil Biology & Practices',
    agronomyDetails: [
      'Sub-surface drip tape irrigation delivering rainwater collected in our winter gravity cisterns.',
      'Applying aerobic aerated compost teas rich in protozoa to suppress powdery mildew on squash leaves.',
      'Pruning and trellising indeterminate heirloom tomatoes to maximize sun exposure and airflow.',
      'Active companion planting of French marigolds and basil to naturally repel hornworms without chemicals.',
    ],
    crops: [
      {
        id: 'summer-tomatoes',
        name: 'Cherokee Purple & Brandywine Tomatoes',
        variety: 'Century-Old Heirlooms',
        status: 'Peak Harvest',
        flavor: 'Unmatched complexity; rich wine-like acidity balanced by deep sun sugars.',
        price: 5.5,
        unit: 'Pint basket (~12 oz)',
        image: FARM_IMAGES.vegetables,
      },
      {
        id: 'summer-peppers',
        name: 'Jimmy Nardello Sweet Italian Peppers',
        variety: '1887 Southern Italian Landrace',
        status: 'Peak Harvest',
        flavor: 'Thin skin, completely sweet with zero heat; melts when pan-blistered.',
        price: 4.5,
        unit: '1 lb basket',
        image: FARM_IMAGES.vegetables,
      },
      {
        id: 'summer-eggplant',
        name: 'Rosa Bianca Heirloom Eggplant',
        variety: 'Italian Ribbed Heritage',
        status: 'Peak Harvest',
        flavor: 'Creamy, delicate flesh with zero bitterness; ideal for grilling with herbs.',
        price: 4.75,
        unit: 'Each (~1.2 lbs)',
        image: FARM_IMAGES.vegetables,
      },
      {
        id: 'summer-corn',
        name: 'Golden Bantam Non-GMO Sweet Corn',
        variety: '1902 Open-Pollinated Cultivar',
        status: 'Peak Harvest',
        flavor: 'Authentic rich corn flavor packed with natural fructose sugars.',
        price: 5.0,
        unit: 'Bunch of 4 ears',
        image: FARM_IMAGES.harvestBasket,
      },
      {
        id: 'summer-figs',
        name: 'Estate Black Mission Figs',
        variety: 'Historic Orchard Trees',
        status: 'Peak Harvest',
        flavor: 'Honeyed jam-like interior with velvety skin; picked dead-ripe.',
        price: 6.5,
        unit: '1 lb carton',
        image: FARM_IMAGES.fruits,
      },
      {
        id: 'summer-beans',
        name: 'Dragon Tongue Speckled Bush Beans',
        variety: '19th Century Dutch Heirloom',
        status: 'Peak Harvest',
        flavor: 'Tender, stringless pods with nutty sweet flavor eaten raw or steamed.',
        price: 4.0,
        unit: '1 lb basket',
        image: FARM_IMAGES.seeds,
      },
    ],
    recipe: {
      title: 'Rustic Charred Pepper & Sun-Ripened Heirloom Tomato Carpaccio',
      time: '20 Minutes',
      ingredients: [
        '3 large Cherokee Purple tomatoes, thick-sliced',
        '4 Jimmy Nardello sweet peppers, pan-blistered with olive oil',
        'Fresh torn basil & estate honey drizzle',
        'Coarse Maldon sea salt & cracked black peppercorns',
      ],
      instructions:
        'Arrange tomato slices in an overlapping fan on a rustic stoneware platter. Top with warm blistered peppers, torn purple basil leaves, a light drizzle of wildflower honey and fruity olive oil.',
    },
  },

  autumn: {
    id: 'autumn',
    title: 'Autumn Harvest: Golden Roots & Orchard Bounty',
    tagline: 'Curing squashes, tree-ripened heritage apples, and cold-sweetened roots.',
    months: 'September — November',
    heroImage: FARM_IMAGES.fruits,
    kicker: 'The Equinox Harvest & Winter Preparation',
    description:
      'As crisp mountain air descends on the valley, nighttime frosts trigger a biological miracle: plants convert their starches into natural antifreeze sugars. Dinosaur kale becomes sweet as candy, while heritage cider apples and winter squashes are sun-cured on open field racks.',
    agronomyTitle: 'Autumn Soil Biology & Practices',
    agronomyDetails: [
      'Planting winter hardneck garlic cloves in compost beds beneath 4 inches of straw mulch.',
      'Sowing winter rye and hairy vetch cover crops to protect topsoil from torrential autumn rains.',
      'Thermophilic composting of all spent crop residues at 145°F to build next year’s living humus.',
      'Sun-curing Butternut and Delicata squash on ventilated slatted benches for extended cellar life.',
    ],
    crops: [
      {
        id: 'autumn-apples',
        name: 'Cox’s Orange Pippin & Ashmead’s Apples',
        variety: '18th Century Heritage Orchard',
        status: 'Peak Harvest',
        flavor: 'Intense aromatic punch with hints of elderflower, pear, and effervescent cider.',
        price: 6.0,
        unit: '3 lb paper tote',
        image: FARM_IMAGES.fruits,
      },
      {
        id: 'autumn-squash',
        name: 'Delicata & Waltham Butternut Squash',
        variety: 'Field Sun-Cured Heritage',
        status: 'Peak Harvest',
        flavor: 'Caramel sweetness with dense velvety flesh; edible tender striped skins.',
        price: 4.5,
        unit: 'Each (~2 lbs)',
        image: FARM_IMAGES.harvestBasket,
      },
      {
        id: 'autumn-beets',
        name: 'Chioggia Candy Cane & Touchstone Beets',
        variety: 'Bullseye-Ringed Heritage',
        status: 'Peak Harvest',
        flavor: 'Mellow, buttery sweet earthy notes; incredible roasted with rosemary.',
        price: 4.25,
        unit: 'Bunch of 4-5 roots',
        image: FARM_IMAGES.vegetables,
      },
      {
        id: 'autumn-kale',
        name: 'Frost-Kissed Lacinato Dinosaur Kale',
        variety: 'Cold-Adapted Cavolo Nero',
        status: 'Peak Harvest',
        flavor: 'Frost transforms starches into concentrated sugars; hearty and tender.',
        price: 3.75,
        unit: 'Large bunch (~1 lb)',
        image: FARM_IMAGES.greens,
      },
      {
        id: 'autumn-carrots',
        name: 'Cosmic Purple & Yellowstone Carrots',
        variety: 'Heirloom Deep Root Cultivars',
        status: 'Peak Harvest',
        flavor: 'Crunchy, sweet, and packed with potent antioxidant anthocyanins.',
        price: 4.5,
        unit: 'Bunch (~1.5 lbs)',
        image: FARM_IMAGES.vegetables,
      },
      {
        id: 'autumn-seeds',
        name: 'Heirloom Bean & Botanical Seed Vault',
        variety: 'Jacob’s Cattle Speckled Beans',
        status: 'Hand-Screened',
        flavor: 'Rich, creamy heirloom dry beans and open-pollinated seeds for next season.',
        price: 16.0,
        unit: 'Heritage Tin (5 Varieties)',
        image: FARM_IMAGES.seeds,
      },
    ],
    recipe: {
      title: 'Roasted Delicata Squash with Brown Butter & Fresh Sage',
      time: '35 Minutes',
      ingredients: [
        '2 Delicata squashes, halved, seeded, and sliced into 1/2-inch half-moons',
        '3 tbsp farm pasture butter',
        '8 fresh sage leaves from the culinary garden',
        '1 tbsp estate wildflower honey & sea salt',
      ],
      instructions:
        'Toss squash slices with olive oil and roast at 400°F for 25 minutes until caramelized. In a small skillet, brown the butter with sage leaves until crispy. Drizzle over roasted squash and finish with honey and flaky sea salt.',
    },
  },

  winter: {
    id: 'winter',
    title: 'Winter Harvest: Root Cellars & Deep Soil Rest',
    tagline: 'Cold-hardy leeks, damp sand-cellared roots, and greenhouse winter greens.',
    months: 'December — February',
    heroImage: FARM_IMAGES.soilHands,
    kicker: 'The Solstice Rest & Cold-Hardy Biology',
    description:
      'While the upper ground sleeps under frost and snow, life deep underground continues. Microbes and fungal hyphae break down organic matter in thermal insulation. We harvest intensely hardy winter greens, blue leeks from under thick straw, and sweet cellared root vegetables.',
    agronomyTitle: 'Winter Soil Biology & Practices',
    agronomyDetails: [
      'Maintaining active root cellar sand boxes at 38°F and 90% humidity to keep roots crisp for months.',
      'Covering passive solar greenhouse beds with floating spun-bond row covers during freezing nights.',
      'Indoor log cultivation of gourmet lion’s mane and golden oyster mushrooms in humidity chambers.',
      'Hand-screening and germination testing of heirloom seed bank varieties for upcoming spring sowing.',
    ],
    crops: [
      {
        id: 'winter-leeks',
        name: 'Bleu de Solaise Winter King Leeks',
        variety: '19th Century French Blue Leek',
        status: 'Peak Harvest',
        flavor: 'Deeply sweet and tender; pulled straight from freezing soil mulches.',
        price: 4.75,
        unit: 'Bunch of 3 large stalks',
        image: FARM_IMAGES.vegetables,
      },
      {
        id: 'winter-mushrooms',
        name: 'Estate Golden Oyster & Lion’s Mane',
        variety: 'Woodlot Log Cultivation',
        status: 'Peak Harvest',
        flavor: 'Velvety, buttery texture with delicate nutty aroma when pan-seared.',
        price: 9.0,
        unit: 'Woodland box (0.75 lb)',
        image: FARM_IMAGES.harvestBasket,
      },
      {
        id: 'winter-cellared-carrots',
        name: 'Damp Sand Cellared Nantes Carrots',
        variety: 'Root Cellar Preserved',
        status: 'Cellared Storage',
        flavor: 'Concentrated sugars and dense crunch without moisture loss.',
        price: 4.25,
        unit: '2 lb tote bag',
        image: FARM_IMAGES.vegetables,
      },
      {
        id: 'winter-greens',
        name: 'Miner’s Lettuce & Winter Mache',
        variety: 'High-Tunnel Cold Greens',
        status: 'Peak Harvest',
        flavor: 'Delicate, nutty, aquatic winter salad green that thrives below freezing.',
        price: 4.0,
        unit: '1/2 lb clamshell',
        image: FARM_IMAGES.greens,
      },
      {
        id: 'winter-citrus',
        name: 'Meyer Lemons & Blood Oranges',
        variety: 'Sheltered Orchard Citrus',
        status: 'Peak Harvest',
        flavor: 'Bursting with floral winter vitamin C and bright fruit acidity.',
        price: 6.5,
        unit: '2 lb tote bag',
        image: FARM_IMAGES.fruits,
      },
      {
        id: 'winter-flour',
        name: 'Stone-Ground Heritage Red Fife Flour',
        variety: 'Cold Watermill Ground',
        status: 'Milled Fresh',
        flavor: 'Rich germ oils and nutty aroma for comforting winter sourdough baking.',
        price: 7.5,
        unit: '2 lb cloth sack',
        image: FARM_IMAGES.seeds,
      },
    ],
    recipe: {
      title: 'Braised Winter King Leek & Cannellini Bean Hearth Stew',
      time: '45 Minutes',
      ingredients: [
        '3 large Bleu de Solaise leeks, washed and sliced into 1-inch discs',
        '2 cups soaked heirloom dry beans (cooked tender)',
        '3 cloves Music hardneck garlic, minced',
        '3 cups rich vegetable stock & fresh thyme',
        'Stone-ground sourdough bread for serving',
      ],
      instructions:
        'Sauté leeks in olive oil over gentle heat for 12 minutes until softened and translucent. Add garlic, thyme, and cooked beans with stock. Simmer for 25 minutes until broth is rich and thickened. Serve in warm earthenware bowls with toasted sourdough.',
    },
  },
};

interface SeasonPageProps {
  season: SeasonType;
  onNavigate: (page: string) => void;
  onAddToCart: (item: ProduceItem) => void;
}

export const SeasonPage: React.FC<SeasonPageProps> = ({ season, onNavigate, onAddToCart }) => {
  const config = SEASONS_CONFIG[season];

  const seasonIcons: Record<SeasonType, React.ReactNode> = {
    spring: <Leaf className="w-5 h-5 text-farm-green-700" />,
    summer: <Sun className="w-5 h-5 text-terracotta-600" />,
    autumn: <CloudRain className="w-5 h-5 text-earth-700" />,
    winter: <Snowflake className="w-5 h-5 text-farm-green-600" />,
  };

  const allSeasons: SeasonType[] = ['spring', 'summer', 'autumn', 'winter'];

  return (
    <div className="space-y-0">
      {/* PROFESSIONAL SEASONAL HERO SECTION */}
      <section className="relative bg-earth-900 border-b border-earth-800 overflow-hidden">
        <div className="relative min-h-[480px] lg:min-h-[540px] flex items-center">
          <div className="absolute inset-0 z-0">
            <img
              src={config.heroImage}
              alt={`${config.title} photography`}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-earth-950/95 via-earth-900/85 to-farm-green-950/55" />
          </div>

          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-20 text-white">
            <div className="max-w-3xl space-y-5">
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-farm-green-200">
                <span className="flex items-center gap-1.5">
                  {seasonIcons[season]}
                  <span className="capitalize">{season} Season</span>
                </span>
                <span aria-hidden="true" className="text-earth-400">·</span>
                <span className="text-terracotta-300 font-serif tabular-nums">{config.months}</span>
              </div>

              <h1 className="font-serif text-4xl sm:text-5xl font-bold tracking-tight text-white leading-tight">
                {config.title}
              </h1>

              <p className="text-base sm:text-lg text-earth-100/95 leading-relaxed font-normal">
                {config.description}
              </p>

              <div className="pt-2 flex flex-wrap items-center gap-4">
                <button
                  type="button"
                  onClick={() => onNavigate('market')}
                  className="inline-flex items-center gap-2 px-6 py-3.5 text-xs font-semibold text-white bg-farm-green-700 hover:bg-farm-green-600 rounded-lg transition-colors cursor-pointer shadow-xs"
                >
                  <span>Order {season.charAt(0).toUpperCase() + season.slice(1)} Harvest Share</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => onNavigate('market')}
                  className="inline-flex items-center gap-2 px-5 py-3.5 text-xs font-semibold text-earth-200 hover:text-white transition-colors cursor-pointer"
                >
                  View 12-Month Calendar &rarr;
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* QUICK SEASON SWITCHER NAV BAR */}
      <nav aria-label="Season Switcher" className="bg-earth-100/80 border-b border-earth-200 py-3">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-4 overflow-x-auto scrollbar-none">
          <span className="text-xs font-semibold text-earth-700 shrink-0">Explore Other Seasons:</span>
          <div className="flex items-center gap-2 shrink-0">
            {allSeasons.map((s) => {
              const isCurrent = s === season;
              return (
                <button
                  key={s}
                  type="button"
                  onClick={() => onNavigate(s)}
                  className={`flex items-center gap-1.5 py-1.5 px-3 rounded-lg text-xs font-semibold transition-all cursor-pointer capitalize ${
                    isCurrent
                      ? 'bg-farm-green-800 text-white shadow-xs'
                      : 'bg-white text-earth-800 hover:bg-earth-200/80 border border-earth-200'
                  }`}
                >
                  {seasonIcons[s]}
                  <span>{s} ({SEASONS_CONFIG[s].months.split('—')[0].trim()})</span>
                </button>
              );
            })}
          </div>
        </div>
      </nav>

      {/* SEASONAL CROPS HARVEST SHOWCASE */}
      <section className="py-20 lg:py-24 bg-white border-b border-earth-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          <div className="max-w-3xl space-y-2">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-farm-green-800">
              <Sparkles className="w-4 h-4 text-terracotta-700" />
              <span>What Is In Season Now</span>
              <span aria-hidden="true" className="text-earth-300">·</span>
              <span className="text-terracotta-700">{config.months}</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl font-bold text-earth-900">
              {season.charAt(0).toUpperCase() + season.slice(1)} Fresh Picks & Heirloom Varieties
            </h2>
            <p className="text-sm sm:text-base text-earth-600 font-normal">
              Pulled daily at dawn and delivered in zero-plastic compostable cartons.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {config.crops.map((crop) => (
              <div
                key={crop.id}
                className="bg-earth-50 rounded-2xl border border-earth-200 overflow-hidden shadow-2xs hover:shadow-xs transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="h-48 w-full overflow-hidden bg-earth-200 relative">
                    <img
                      src={crop.image}
                      alt={crop.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-xs px-2.5 py-1 rounded-md text-[11px] font-semibold text-farm-green-900 border border-earth-200 shadow-2xs">
                      {crop.status}
                    </div>
                  </div>

                  <div className="p-5 space-y-2">
                    <div className="text-[11px] font-semibold text-terracotta-700 uppercase tracking-wider">
                      {crop.variety}
                    </div>
                    <h3 className="font-serif text-lg font-bold text-earth-900">
                      {crop.name}
                    </h3>
                    <p className="text-xs text-earth-600 leading-relaxed font-normal">
                      {crop.flavor}
                    </p>
                  </div>
                </div>

                <div className="p-5 pt-3 border-t border-earth-200 flex items-center justify-between">
                  <div>
                    <span className="font-serif text-base font-bold text-earth-900 tabular-nums">
                      ${crop.price.toFixed(2)}
                    </span>
                    <span className="text-[11px] text-earth-500 block">{crop.unit}</span>
                  </div>

                  <button
                    type="button"
                    onClick={() =>
                      onAddToCart({
                        id: crop.id,
                        name: crop.name,
                        category: 'vegetables',
                        price: crop.price,
                        unit: crop.unit,
                        heirloomVariety: crop.variety,
                        description: crop.flavor,
                        harvestWindow: `${season} harvest`,
                        organicCert: '100% Certified Organic',
                        inStock: true,
                        image: crop.image,
                      })
                    }
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-farm-green-800 hover:bg-farm-green-900 rounded-lg transition-colors cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add to Basket</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SEASONAL AGRONOMY & FIELD PRACTICES */}
      <section className="py-20 bg-earth-50 border-b border-earth-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            <div className="lg:col-span-6 space-y-5">
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-farm-green-800">
                <Calendar className="w-4 h-4 text-terracotta-700" />
                <span>Field Phenology</span>
              </div>
              <h2 className="font-serif text-3xl sm:text-4xl font-bold text-earth-900">
                {config.agronomyTitle}
              </h2>
              <p className="text-sm sm:text-base text-earth-700 leading-relaxed font-normal">
                Every season demands an entirely different relationship with the living soil. Rather
                than fighting against nature with greenhouse fuel or chemical growth hormones, our growers
                synchronize field work with soil moisture, night temperatures, and natural insect predator cycles.
              </p>

              <div className="space-y-3 pt-2">
                {config.agronomyDetails.map((detail, idx) => (
                  <div key={idx} className="flex items-start gap-3 p-3.5 rounded-xl bg-white border border-earth-200">
                    <div className="w-5 h-5 rounded-full bg-farm-green-100 text-farm-green-800 flex items-center justify-center shrink-0 mt-0.5">
                      <Check className="w-3.5 h-3.5" />
                    </div>
                    <span className="text-xs text-earth-800 font-normal leading-relaxed">{detail}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Farm Kitchen Seasonal Recipe Card */}
            <div className="lg:col-span-6">
              <div className="bg-white rounded-3xl border border-earth-200 p-8 shadow-xs space-y-6">
                <div className="flex items-center justify-between border-b border-earth-100 pb-4">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-terracotta-100 text-terracotta-700 flex items-center justify-center">
                      <ChefHat className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-[11px] font-semibold text-terracotta-700 uppercase tracking-wider block">
                        Farm Kitchen Recipe
                      </span>
                      <h3 className="font-serif text-lg font-bold text-earth-900">
                        {config.recipe.title}
                      </h3>
                    </div>
                  </div>
                  <span className="text-xs text-earth-500 font-medium shrink-0">
                    {config.recipe.time}
                  </span>
                </div>

                <div className="space-y-3 text-xs text-earth-700">
                  <h4 className="font-semibold text-earth-900 uppercase tracking-wider text-[11px]">
                    Ingredients from this week's harvest:
                  </h4>
                  <ul className="space-y-1.5 list-disc pl-4">
                    {config.recipe.ingredients.map((ing, i) => (
                      <li key={i}>{ing}</li>
                    ))}
                  </ul>
                </div>

                <div className="space-y-2 text-xs text-earth-700 border-t border-earth-100 pt-4 leading-relaxed">
                  <h4 className="font-semibold text-earth-900 uppercase tracking-wider text-[11px]">
                    Preparation:
                  </h4>
                  <p>{config.recipe.instructions}</p>
                </div>

                <div className="pt-2">
                  <button
                    type="button"
                    onClick={() => onNavigate('market')}
                    className="w-full py-2.5 text-xs font-semibold text-white bg-farm-green-800 hover:bg-farm-green-900 rounded-lg transition-colors cursor-pointer text-center"
                  >
                    Get These Ingredients in This Week's Box
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
