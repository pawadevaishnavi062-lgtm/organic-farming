import React, { useState } from 'react';
import { FarmTours } from '../components/FarmTours';
import { FARM_IMAGES } from '../data/farmData';
import { MapPin, Clock, Calendar, HelpCircle, ChevronDown, ChevronUp } from 'lucide-react';

export const ToursPage: React.FC = () => {
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  const faqs = [
    {
      q: 'What should we wear for farm walks and workshops?',
      a: 'We recommend sturdy closed-toe shoes or mud boots, as field paths can be damp in the morning. A sun hat, weather-appropriate layers, and a refillable water bottle will keep you comfortable during the 2-hour walk.',
    },
    {
      q: 'Are children and families welcome?',
      a: 'Yes, absolutely! Our "Orchard, Bees & Honey Extraction Walk" is specifically crafted for all ages. Kids love observing the glass observation hives, pulling fresh carrots, and meeting our heritage pollinators.',
    },
    {
      q: 'Where do we park upon arrival?',
      a: 'Parking is free in the marked south gravel apron adjacent to the Cedar Barn Farm Stand. Please drive slowly (under 10 mph) on the farm lane to protect walking pollinators and free-ranging barn swallows.',
    },
    {
      q: 'Can we purchase fresh produce during our tour visit?',
      a: 'Yes! The Cedar Barn Farm Stand is stocked with that morning’s freshly harvested produce, stone-ground flour, raw comb honey, and fresh culinary herbs. Tour guests receive 10% off their farmstand basket on the day of their tour.',
    },
    {
      q: 'What is the cancellation or weather rescheduling policy?',
      a: 'Tours proceed in light PNW mist (we have covered pavilions in the orchard). In the event of severe weather or torrential rain, you may reschedule for any future weekend or receive a full 100% refund up to 24 hours prior.',
    },
  ];

  return (
    <div className="space-y-0">
      {/* TOURS PAGE DEDICATED PROFESSIONAL HERO */}
      <section className="relative bg-earth-900 border-b border-earth-800 overflow-hidden">
        <div className="relative min-h-[460px] lg:min-h-[520px] flex items-center">
          <div className="absolute inset-0 z-0">
            <img
              src={FARM_IMAGES.orchardTour}
              alt="Sunlit organic orchard with wildflower pollinator meadows between trees and weathered cedar fence"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-earth-950/95 via-earth-900/85 to-farm-green-950/60" />
          </div>

          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-20 text-white">
            <div className="max-w-3xl space-y-5">
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-farm-green-200">
                <span>Farmgate Hospitality</span>
                <span aria-hidden="true" className="text-earth-400">·</span>
                <span className="text-terracotta-300">Open Gates Philosophy</span>
              </div>

              <h1 className="font-serif text-4xl sm:text-5xl font-bold tracking-tight text-white leading-tight">
                Walk the Land: Field Tours, Apiary & Workshops.
              </h1>

              <p className="text-base sm:text-lg text-earth-100/90 leading-relaxed font-normal">
                Agricultural transparency means open gates. Come touch living compost, taste
                sun-ripened heirloom fruit straight from the tree, and discover how biological
                farming restores ecological balance to our valley.
              </p>

              {/* Guarantees strip */}
              <div className="pt-2 flex flex-wrap items-center gap-6 text-xs text-earth-200">
                <span className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-farm-green-300" />
                  Farm Stand: Wed – Sun · 8 AM – 4 PM
                </span>
                <span aria-hidden="true" className="text-earth-500">·</span>
                <span className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-farm-green-300" />
                  Weekend Morning Tours
                </span>
                <span aria-hidden="true" className="text-earth-500">·</span>
                <span className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-farm-green-300" />
                  Riverdale Basin, OR
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* INTERACTIVE TOUR OFFERINGS & RESERVATION MODULE */}
      <FarmTours />

      {/* WHAT YOU WILL TOUCH, TASTE & LEARN PHOTO SECTION */}
      <section className="py-20 bg-earth-50 border-b border-earth-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          <div className="text-center max-w-2xl mx-auto space-y-3">
            <div className="flex items-center justify-center gap-2 text-xs font-semibold uppercase tracking-wider text-farm-green-800">
              <Calendar className="w-4 h-4" />
              <span>Sensory Farm Immersion</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl font-bold text-earth-900">
              Taste, Touch & Experience Living Earth
            </h2>
            <p className="text-xs sm:text-sm text-earth-600 font-normal">
              Every tour includes guided tastings, hands-on soil exploration, and seasonal harvests.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white rounded-2xl border border-earth-200 overflow-hidden shadow-2xs group">
              <div className="h-48 w-full overflow-hidden bg-earth-100">
                <img
                  src={FARM_IMAGES.vegetables}
                  alt="Organic heirloom rainbow carrots, dinosaur kale, and golden beets pulled from living soil"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="p-5 space-y-2">
                <div className="text-[11px] font-semibold text-terracotta-700 uppercase tracking-wider">
                  Morning Veggie Pull
                </div>
                <h3 className="font-serif text-base font-bold text-earth-900">
                  Pull Heirloom Roots from Living Loam
                </h3>
                <p className="text-xs text-earth-600 leading-relaxed font-normal">
                  Put on boots and pull fresh rainbow carrots and beets straight from compost-mulched beds.
                </p>
              </div>
            </div>

            <div className="bg-white rounded-2xl border border-earth-200 overflow-hidden shadow-2xs group">
              <div className="h-48 w-full overflow-hidden bg-earth-100">
                <img
                  src={FARM_IMAGES.fruits}
                  alt="Orchard red apples, purple mission figs, and fresh Meyer lemons"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="p-5 space-y-2">
                <div className="text-[11px] font-semibold text-terracotta-700 uppercase tracking-wider">
                  Orchard Harvest Walk
                </div>
                <h3 className="font-serif text-base font-bold text-earth-900">
                  Sample Sun-Ripened Heritage Fruit
                </h3>
                <p className="text-xs text-earth-600 leading-relaxed font-normal">
                  Walk beneath 40-year heritage trees and taste fresh apples, mission figs, and citrus blossoms.
                </p>
              </div>
            </div>

            <div className="bg-white rounded-2xl border border-earth-200 overflow-hidden shadow-2xs group">
              <div className="h-48 w-full overflow-hidden bg-earth-100">
                <img
                  src={FARM_IMAGES.seeds}
                  alt="Speckled heirloom beans, sunflower seeds, and pumpkin seeds in clay saucers"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="p-5 space-y-2">
                <div className="text-[11px] font-semibold text-terracotta-700 uppercase tracking-wider">
                  Seed Potting Workshop
                </div>
                <h3 className="font-serif text-base font-bold text-earth-900">
                  Save Open-Pollinated Heritage Seeds
                </h3>
                <p className="text-xs text-earth-600 leading-relaxed font-normal">
                  Learn seed screening and plant your own heirloom bean seedling to take home in compost soil.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FARM STAND VISITING DETAILS & LOCATION */}
      <section className="py-20 bg-white border-b border-earth-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            <div className="lg:col-span-6 space-y-5">
              <div className="flex items-center gap-2 text-xs font-semibold text-farm-green-800 uppercase tracking-wider">
                <MapPin className="w-4 h-4 text-terracotta-700" />
                <span>Farmgate Destination</span>
              </div>
              <h2 className="font-serif text-3xl sm:text-4xl font-bold text-earth-900">
                The Cedar Barn Farm Stand
              </h2>
              <p className="text-sm sm:text-base text-earth-700 leading-relaxed font-normal">
                Nestled at the entrance of our property, the historic Cedar Barn has been lovingly
                restored as our community market hub. Stop by for freshly pulled roots, organic salad
                greens, wildflower honey, and fresh-baked heritage sourdough bread.
              </p>

              <div className="p-5 rounded-xl bg-earth-50 border border-earth-200 space-y-3 text-xs text-earth-800">
                <div className="flex justify-between pb-2 border-b border-earth-200 font-semibold">
                  <span>Farm Stand Opening Hours</span>
                  <span className="text-farm-green-800">Open 5 Days / Week</span>
                </div>
                <div className="flex justify-between">
                  <span>Wednesday — Friday</span>
                  <span className="font-medium">8:00 AM – 4:00 PM</span>
                </div>
                <div className="flex justify-between">
                  <span>Saturday & Sunday</span>
                  <span className="font-medium">8:00 AM – 5:00 PM (Fresh Bread Drop at 9 AM)</span>
                </div>
                <div className="flex justify-between text-earth-500">
                  <span>Monday & Tuesday</span>
                  <span>Closed for Field Planting & Harvest</span>
                </div>
              </div>

              <div className="text-xs text-earth-600 space-y-1">
                <p><strong>Physical Address:</strong> 4820 Clover Valley Road, Riverdale Basin, OR 97128</p>
                <p><strong>Contact:</strong> (503) 555-0192 · visits@verdantrootsfarm.org</p>
              </div>
            </div>

            {/* Visitor FAQ Accordion */}
            <div className="lg:col-span-6 space-y-4">
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-earth-600 mb-2">
                <HelpCircle className="w-4 h-4 text-farm-green-800" />
                <span>Frequently Asked Visitor Questions</span>
              </div>

              {faqs.map((faq, index) => {
                const isOpen = openFaqIndex === index;
                return (
                  <div
                    key={index}
                    className="rounded-xl border border-earth-200 bg-earth-50/70 overflow-hidden transition-all shadow-2xs"
                  >
                    <button
                      type="button"
                      onClick={() => setOpenFaqIndex(isOpen ? null : index)}
                      className="w-full p-4 text-left flex items-center justify-between gap-4 font-serif text-sm font-bold text-earth-900 cursor-pointer"
                    >
                      <span>{faq.q}</span>
                      {isOpen ? (
                        <ChevronUp className="w-4 h-4 text-farm-green-800 shrink-0" />
                      ) : (
                        <ChevronDown className="w-4 h-4 text-earth-500 shrink-0" />
                      )}
                    </button>
                    {isOpen && (
                      <div className="px-4 pb-4 text-xs text-earth-700 leading-relaxed font-normal border-t border-earth-200/60 pt-3">
                        {faq.a}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
