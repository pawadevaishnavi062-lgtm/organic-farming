import { HarvestMarket } from '../components/HarvestMarket';
import { CropCalendar } from '../components/CropCalendar';
import { SeasonalCalendar } from '../components/SeasonalCalendar';
import { FARM_IMAGES } from '../data/farmData';
import { ProduceItem } from '../types/farm';
import { PageId } from '../components/Header';
import { Truck, RotateCcw, PackageCheck, HelpCircle, ArrowRight, Dna } from 'lucide-react';

interface MarketPageProps {
  onAddToCart: (item: ProduceItem) => void;
  onNavigate: (page: PageId) => void;
}

export const MarketPage: React.FC<MarketPageProps> = ({ onAddToCart, onNavigate }) => {
  return (
    <div className="space-y-0">
      {/* MARKET PAGE DEDICATED PROFESSIONAL HERO */}
      <section className="relative bg-earth-900 border-b border-earth-800 overflow-hidden">
        <div className="relative min-h-[460px] lg:min-h-[520px] flex items-center">
          <div className="absolute inset-0 z-0">
            <img
              src={FARM_IMAGES.harvestBasket}
              alt="Harvest crate brimming with freshly pulled rainbow carrots, beets, and organic kale"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-earth-950/95 via-earth-900/85 to-farm-green-950/60" />
          </div>

          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-20 text-white">
            <div className="max-w-3xl space-y-5">
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-farm-green-200">
                <span>The Farmstand & CSA Marketplace</span>
                <span aria-hidden="true" className="text-earth-400">·</span>
                <span className="text-terracotta-300">Morning Harvest Dispatch</span>
              </div>

              <h1 className="font-serif text-4xl sm:text-5xl font-bold tracking-tight text-white leading-tight">
                Fresh from Living Earth: Heirloom Produce & Harvest Shares.
              </h1>

              <p className="text-base sm:text-lg text-earth-100/90 leading-relaxed font-normal">
                Every crop listed below is grown in our living no-till soil, harvested at dawn, and
                delivered without synthetic preservatives or chemical waxes. Select a weekly curated
                farm share box or build your own custom produce basket.
              </p>

              {/* Guarantees strip */}
              <div className="pt-2 flex flex-wrap items-center gap-6 text-xs text-earth-200">
                <span className="flex items-center gap-2">
                  <PackageCheck className="w-4 h-4 text-farm-green-300" />
                  100% Compostable Boxes
                </span>
                <span aria-hidden="true" className="text-earth-500">·</span>
                <span className="flex items-center gap-2">
                  <Truck className="w-4 h-4 text-farm-green-300" />
                  Zero Emission Local Electric Delivery
                </span>
                <span aria-hidden="true" className="text-earth-500">·</span>
                <span className="flex items-center gap-2">
                  <RotateCcw className="w-4 h-4 text-farm-green-300" />
                  Pause or Cancel Anytime
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 42 VARIETIES LINK BANNER */}
      <section className="bg-earth-100 border-b border-earth-200 py-3.5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-earth-800">
            <span className="p-1 rounded bg-farm-green-800 text-white">
              <Dna className="w-3.5 h-3.5" />
            </span>
            <span className="font-bold text-earth-900">42 Living Heirloom Cultivars</span>
            <span className="text-earth-400 hidden sm:inline">·</span>
            <span className="text-earth-600 hidden sm:inline">Individual photos, ancestral origins, and community likes.</span>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('varieties')}
            className="font-bold text-farm-green-800 hover:text-farm-green-900 flex items-center gap-1.5 cursor-pointer shrink-0 group"
          >
            <span>Explore 42 Varieties & Photos</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
          </button>
        </div>
      </section>

      {/* FULL PRODUCT MARKETPLACE */}
      <HarvestMarket onAddToCart={onAddToCart} />

      {/* INTERACTIVE CROP CALENDAR COMPONENT */}
      <CropCalendar onAddToCart={onAddToCart} />

      {/* 4-SEASON OVERVIEW CALENDAR */}
      <SeasonalCalendar onNavigate={onNavigate} />

      {/* HOW CSA SUBSCRIPTIONS WORK */}
      <section className="py-20 bg-earth-50 border-b border-earth-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          <div className="text-center max-w-2xl mx-auto space-y-3">
            <div className="flex items-center justify-center gap-2 text-xs font-semibold uppercase tracking-wider text-farm-green-800">
              <HelpCircle className="w-4 h-4" />
              <span>Simple, Transparent Membership</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl font-bold text-earth-900">
              How Your Farm Share Works
            </h2>
            <p className="text-xs sm:text-sm text-earth-600 font-normal">
              Direct connection between local eaters and ecological growers.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="p-6 rounded-2xl bg-white border border-earth-200 shadow-2xs space-y-3">
              <span className="font-serif text-2xl font-bold text-terracotta-700">01</span>
              <h3 className="font-serif text-base font-bold text-earth-900">Choose Your Share</h3>
              <p className="text-xs text-earth-600 leading-relaxed font-normal">
                Select The Hearth Box for families, The Sprout Box for couples, or tailor an individual weekly order.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-white border border-earth-200 shadow-2xs space-y-3">
              <span className="font-serif text-2xl font-bold text-terracotta-700">02</span>
              <h3 className="font-serif text-base font-bold text-earth-900">Dawn Field Harvest</h3>
              <p className="text-xs text-earth-600 leading-relaxed font-normal">
                Our growers hand-pick your vegetables at peak dawn sugar concentration to maximize shelf life and flavor.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-white border border-earth-200 shadow-2xs space-y-3">
              <span className="font-serif text-2xl font-bold text-terracotta-700">03</span>
              <h3 className="font-serif text-base font-bold text-earth-900">Same-Day Dispatch</h3>
              <p className="text-xs text-earth-600 leading-relaxed font-normal">
                Delivered straight to your doorstep via local electric van, or ready for pickup at our Cedar Barn farmstand.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-white border border-earth-200 shadow-2xs space-y-3">
              <span className="font-serif text-2xl font-bold text-terracotta-700">04</span>
              <h3 className="font-serif text-base font-bold text-earth-900">Closed-Loop Return</h3>
              <p className="text-xs text-earth-600 leading-relaxed font-normal">
                Leave out your empty cartons on delivery day for reuse, or compost them in your backyard garden soil.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
