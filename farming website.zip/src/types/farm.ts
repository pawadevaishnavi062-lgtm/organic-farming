export interface ProduceItem {
  id: string;
  name: string;
  category: 'boxes' | 'vegetables' | 'fruits' | 'pantry' | 'seeds';
  price: number;
  unit: string;
  heirloomVariety: string;
  description: string;
  harvestWindow: string;
  organicCert: string;
  inStock: boolean;
  image?: string;
}

export interface CartItem {
  product: ProduceItem;
  quantity: number;
}

export interface FarmTour {
  id: string;
  title: string;
  duration: string;
  pricePerPerson: number;
  schedule: string;
  focus: string;
  description: string;
  spotsLeft: number;
}

export interface CropSeasonInfo {
  season: 'Spring' | 'Summer' | 'Autumn' | 'Winter';
  months: string;
  crops: {
    name: string;
    variety: string;
    status: 'Peak Harvest' | 'Greenhouse Nursery' | 'Root Cellared' | 'Emerging';
    notes: string;
  }[];
}
