import React from 'react';
import { ArrowRight, ShieldCheck, SunMedium, Clock3, Trees } from 'lucide-react';
import { FARM_IMAGES } from '../data/farmData';

export const Hero: React.FC = () => {
  return (
    <section id="hero" className="relative bg-earth-100 border-b border-earth-200 overflow-hidden">
      {/* Background Hero Image with measured contrast gradient scrim in Earth & Forest tones */}
      <div className="relative min-h-[620px] lg:min-h-[700px] flex items-center">
        <div className="absolute inset-0 z-0">
          <img
            src={FARM_IMAGES.hero}
            alt="Lush regenerative organic farm rows bathed in morning sunrise light with barn in background"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center"
          />
          {/* Multi-stop gradient scrim blending deep earth loam and forest shades for rich atmospheric depth */}
          <div className="absolute inset-0 bg-gradient-to-r from-earth-950/90 via-earth-900/75 to-farm-green-950/45" />
        </div>

        {/* Hero Content Container */}
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-28 text-white">
          <div className="max-w-2xl lg:max-w-3xl space-y-6">
            {/* Clean unboxed editorial kicker in Sage & Earth Sand */}
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-farm-green-200">
              <span>Third-Generation Organic Stewards</span>
              <span aria-hidden="true" className="text-earth-300">·</span>
              <span className="text-earth-200">Demeter Biodynamic Certified</span>
            </div>

            {/* Hero Headline in Crisp White */}
            <h1
              className="font-serif text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-white leading-tight"
              style={{ textWrap: 'balance' }}
            >
              Grown in Living Soil. Harvested in Harmony with Nature.
            </h1>

            {/* Concrete value proposition */}
            <p className="text-base sm:text-lg text-earth-100/90 leading-relaxed font-normal max-w-2xl">
              We cultivate 180 acres of heirloom produce, orchard fruits, and botanicals using no-till
              biological methods. Building living microbial fertility without synthetic fertilizers or
              pesticides, and dispatching fresh harvest boxes straight to your kitchen within 24 hours of picking.
            </p>

            {/* Action buttons: Botanical Green, Terracotta Earth & Crisp White */}
            <div className="pt-4 flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
              <a
                href="#harvest-market"
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm font-semibold text-white bg-farm-green-700 hover:bg-farm-green-600 border border-farm-green-600 rounded-lg shadow-sm hover:shadow-md transition-all whitespace-nowrap"
              >
                <span>Explore Seasonal Harvest</span>
                <ArrowRight className="w-4 h-4" />
              </a>
              <a
                href="#soil-practices"
                className="inline-flex items-center justify-center px-6 py-3.5 text-sm font-semibold text-white bg-white/15 hover:bg-white/25 border border-white/30 rounded-lg backdrop-blur-xs transition-all whitespace-nowrap"
              >
                Discover Soil Science
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Adjacency Proof & Metric Row in Warm Earth & Fresh Green */}
      <div className="bg-earth-50 border-t border-earth-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 lg:gap-8">
            <div className="flex items-start gap-3.5 p-3 rounded-xl bg-white border border-earth-200/80 shadow-2xs">
              <div className="p-2.5 rounded-lg bg-farm-green-100 text-farm-green-800 shrink-0">
                <Trees className="w-5 h-5" />
              </div>
              <div>
                <p className="text-2xl font-bold text-earth-900 font-serif tabular-nums">180+ Acres</p>
                <p className="text-xs text-earth-600 mt-0.5">Regenerative living soil under no-till care</p>
              </div>
            </div>

            <div className="flex items-start gap-3.5 p-3 rounded-xl bg-white border border-earth-200/80 shadow-2xs">
              <div className="p-2.5 rounded-lg bg-terracotta-100 text-terracotta-700 shrink-0">
                <SunMedium className="w-5 h-5" />
              </div>
              <div>
                <p className="text-2xl font-bold text-earth-900 font-serif tabular-nums">42 Varieties</p>
                <p className="text-xs text-earth-600 mt-0.5">Heirloom seeds preserved & open-pollinated</p>
              </div>
            </div>

            <div className="flex items-start gap-3.5 p-3 rounded-xl bg-white border border-earth-200/80 shadow-2xs">
              <div className="p-2.5 rounded-lg bg-farm-green-100 text-farm-green-800 shrink-0">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <p className="text-2xl font-bold text-earth-900 font-serif tabular-nums">0% Chemicals</p>
                <p className="text-xs text-earth-600 mt-0.5">Zero synthetic pesticides, herbicides, or GMOs</p>
              </div>
            </div>

            <div className="flex items-start gap-3.5 p-3 rounded-xl bg-white border border-earth-200/80 shadow-2xs">
              <div className="p-2.5 rounded-lg bg-terracotta-100 text-terracotta-700 shrink-0">
                <Clock3 className="w-5 h-5" />
              </div>
              <div>
                <p className="text-2xl font-bold text-earth-900 font-serif tabular-nums">&lt; 24 Hours</p>
                <p className="text-xs text-earth-600 mt-0.5">Morning harvest straight to your table</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
