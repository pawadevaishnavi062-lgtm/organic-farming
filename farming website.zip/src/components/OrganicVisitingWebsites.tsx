import React, { useState } from 'react';
import { 
  ExternalLink, 
  Globe, 
  ShieldCheck, 
  BookOpen, 
  Sprout, 
  Award, 
  CheckCircle2, 
  Building2, 
  Users, 
  Search,
  ArrowRight
} from 'lucide-react';

export interface VisitingWebsite {
  id: string;
  name: string;
  acronym: string;
  category: 'national' | 'farmer-network' | 'global-research' | 'certification';
  headquarters: string;
  authority: string;
  url: string;
  portalUrl?: string;
  portalLabel?: string;
  badge: string;
  description: string;
  keyContributions: string[];
  recommendedReading: string;
}

export const VISITING_ORGANIC_WEBSITES: VisitingWebsite[] = [
  {
    id: 'nconf',
    name: 'National Centre for Organic and Natural Farming',
    acronym: 'NCONF',
    category: 'national',
    headquarters: 'Ghaziabad, Uttar Pradesh, India',
    authority: 'Ministry of Agriculture & Farmers Welfare, Government of India',
    url: 'https://ncof.dacnet.nic.in/',
    portalUrl: 'https://www.jaivikkheti.in/',
    portalLabel: 'Jaivik Kheti Portal',
    badge: 'Government Apex Institution',
    description: 'The premier national nodal organization of the Government of India for the promotion, capacity building, and technical standard setting of organic and natural farming, bio-fertilizers, and organic manure testing.',
    keyContributions: [
      'PGS-India (Participatory Guarantee System) grassroots certification implementation',
      'National quality control parameters for bio-fertilizers and organic compost',
      'Technical manuals for Jeevamrit, Beejamrit, and indigenous microbial inoculants',
      'Jaivik Kheti e-marketplace connecting organic growers with direct consumers'
    ],
    recommendedReading: 'Standard Operating Procedures for Natural Farming & Biofertilizer Quality Control'
  },
  {
    id: 'ofai',
    name: 'Organic Farming Association of India',
    acronym: 'OFAI',
    category: 'farmer-network',
    headquarters: 'Goa / Across All Indian States',
    authority: 'Farmer-Led National Network of Ecological & Organic Producers',
    url: 'https://ofai.org/',
    badge: 'India’s Largest Farmer Network',
    description: 'India’s largest and oldest membership-based association of organic farmers, seed savers, activists, and indigenous agronomists dedicated to advancing chemical-free agriculture and farmer self-reliance.',
    keyContributions: [
      'National Desi Heirloom Seed Bank Network conserving thousands of native crop varieties',
      'Farmer-to-farmer peer training workshops on zero-budget pest and soil ecology',
      'Biennial National Organic Farmer Congress showcasing grassroots innovations',
      'Advocacy against genetically modified crops (GMOs) and hazardous chemical pesticides'
    ],
    recommendedReading: 'Traditional Agro-Ecological Farming Manuals & Indigenous Seed Directory'
  },
  {
    id: 'ifoam',
    name: 'IFOAM – Organics International',
    acronym: 'IFOAM',
    category: 'global-research',
    headquarters: 'Bonn, Germany',
    authority: 'Global Umbrella Organization for the Organic Agriculture Movement',
    url: 'https://www.ifoam.bio/',
    badge: 'Global Organic Standard',
    description: 'Since 1972, IFOAM has unified the organic movement across 100+ countries, defining the four core principles of organic agriculture: Health, Ecology, Fairness, and Care.',
    keyContributions: [
      'The IFOAM Standard — foundational benchmark for worldwide organic certification',
      'Global Organic World Congress and scientific symposiums with the UN FAO',
      'Training leaders in participatory guarantee systems and fair ecological trade',
      'Annual "The World of Organic Agriculture" global acreage and market statistical report'
    ],
    recommendedReading: 'Principles of Organic Agriculture: Health, Ecology, Fairness & Care'
  },
  {
    id: 'fibl',
    name: 'FiBL – Research Institute of Organic Agriculture',
    acronym: 'FiBL',
    category: 'global-research',
    headquarters: 'Frick, Switzerland / Frankfurt, Germany',
    authority: 'World’s Leading Independent Scientific Institute for Organic Farming',
    url: 'https://www.fibl.org/',
    badge: 'Scientific Research Authority',
    description: 'One of the world’s foremost research centers in organic agriculture, employing hundreds of scientists investigating living soil microbiology, organic plant breeding, and climate mitigation.',
    keyContributions: [
      'The DOK Trial: 45-year continuous comparative field study of organic vs conventional soils',
      'Peer-reviewed evidence on soil carbon sequestration in organic no-till systems',
      'Organic disease forecast models and biological pest control formulations',
      'Global database of allowable natural inputs and biological substances'
    ],
    recommendedReading: 'The DOK Long-Term Experiment: Soil Biodiversity & Carbon Dynamics in Organic Systems'
  },
  {
    id: 'rodale',
    name: 'Rodale Institute',
    acronym: 'Rodale',
    category: 'global-research',
    headquarters: 'Kutztown, Pennsylvania, USA',
    authority: 'Pioneers of the Regenerative Organic Agriculture Movement (Est. 1947)',
    url: 'https://rodaleinstitute.org/',
    badge: 'Regenerative Organic Pioneer',
    description: 'Founded by J.I. Rodale with the creed "Healthy Soil = Healthy Food = Healthy People." Home to the longest-running side-by-side trial of organic versus chemical agriculture in North America.',
    keyContributions: [
      'The Farming Systems Trial (FST) running for 40+ continuous harvest seasons',
      'Development of the Roller-Crimper tool for high-residue organic no-till cover cropping',
      'Co-founding the Regenerative Organic Certified (ROC) gold standard',
      'Research proving organic crops match conventional yields while using 45% less energy'
    ],
    recommendedReading: 'The 40-Year Farming Systems Trial Report on Soil Carbon & Water Retention'
  },
  {
    id: 'apeda',
    name: 'APEDA – National Programme for Organic Production',
    acronym: 'NPOP',
    category: 'certification',
    headquarters: 'New Delhi, India',
    authority: 'Ministry of Commerce and Industry, Government of India',
    url: 'https://apeda.gov.in/apedawebsite/organic/index.htm',
    portalUrl: 'https://tracenet.apeda.gov.in/',
    portalLabel: 'Tracenet Verification Portal',
    badge: 'Statutory Certification Body',
    description: 'The statutory body managing the National Programme for Organic Production (NPOP), governing the accreditation of certification bodies, India Organic logo standards, and export inspection.',
    keyContributions: [
      'National accreditation of third-party organic certification agencies',
      'Administration and protection of the official "India Organic" trademark logo',
      'Tracenet online traceability software tracking authentic organic supply chains',
      'Bilateral equivalency agreements with the European Union, Switzerland, and global markets'
    ],
    recommendedReading: 'NPOP Organic Production Standards & Certification Procedure Manual'
  },
];

interface OrganicVisitingWebsitesProps {
  className?: string;
  title?: string;
  subtitle?: string;
  compact?: boolean;
}

export const OrganicVisitingWebsites: React.FC<OrganicVisitingWebsitesProps> = ({
  className = '',
  title = 'Trusted Organic Farming Authorities & Visiting Resources',
  subtitle = 'We ground our regenerative farming practices in technical standards, open seed preservation, and research developed by these world-renowned national and international institutions.',
  compact = false,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filtered = VISITING_ORGANIC_WEBSITES.filter((org) => {
    const matchesCat = selectedCategory === 'all' || org.category === selectedCategory;
    const matchesQuery = 
      org.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      org.acronym.toLowerCase().includes(searchQuery.toLowerCase()) ||
      org.authority.toLowerCase().includes(searchQuery.toLowerCase()) ||
      org.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesQuery;
  });

  return (
    <section className={`py-14 sm:py-20 bg-earth-50 border-y border-earth-200 ${className}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        
        {/* Header Block */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="max-w-2xl space-y-2">
            <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-farm-green-800">
              <Globe className="w-4 h-4 text-farm-green-600" />
              <span>National & Global Organic Knowledge Base</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl font-bold text-earth-900 leading-tight">
              {title}
            </h2>
            <p className="text-xs sm:text-sm text-earth-600 leading-relaxed font-normal">
              {subtitle}
            </p>
          </div>

          {/* Quick Search */}
          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-earth-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search institutions, NCONF, OFAI..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-earth-300 focus:outline-none focus:border-farm-green-700 bg-white text-earth-900 placeholder-earth-400"
            />
          </div>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap gap-2 border-b border-earth-200 pb-3">
          <button
            type="button"
            onClick={() => setSelectedCategory('all')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              selectedCategory === 'all'
                ? 'bg-earth-900 text-white shadow-2xs'
                : 'bg-white border border-earth-200 text-earth-700 hover:bg-earth-100'
            }`}
          >
            All Organizations ({VISITING_ORGANIC_WEBSITES.length})
          </button>
          <button
            type="button"
            onClick={() => setSelectedCategory('national')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              selectedCategory === 'national'
                ? 'bg-earth-900 text-white shadow-2xs'
                : 'bg-white border border-earth-200 text-earth-700 hover:bg-earth-100'
            }`}
          >
            National Government Apex (NCONF)
          </button>
          <button
            type="button"
            onClick={() => setSelectedCategory('farmer-network')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              selectedCategory === 'farmer-network'
                ? 'bg-earth-900 text-white shadow-2xs'
                : 'bg-white border border-earth-200 text-earth-700 hover:bg-earth-100'
            }`}
          >
            Farmer Networks & Seed Banks (OFAI)
          </button>
          <button
            type="button"
            onClick={() => setSelectedCategory('global-research')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              selectedCategory === 'global-research'
                ? 'bg-earth-900 text-white shadow-2xs'
                : 'bg-white border border-earth-200 text-earth-700 hover:bg-earth-100'
            }`}
          >
            Global Research (IFOAM, FiBL, Rodale)
          </button>
          <button
            type="button"
            onClick={() => setSelectedCategory('certification')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              selectedCategory === 'certification'
                ? 'bg-earth-900 text-white shadow-2xs'
                : 'bg-white border border-earth-200 text-earth-700 hover:bg-earth-100'
            }`}
          >
            Certification & Traceability (APEDA NPOP)
          </button>
        </div>

        {/* Directory Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((org) => (
            <div
              key={org.id}
              className="bg-white rounded-3xl border border-earth-200 p-6 flex flex-col justify-between space-y-5 hover:border-farm-green-600 hover:shadow-md transition-all duration-300"
            >
              <div className="space-y-3.5">
                {/* Header Tag & Badge */}
                <div className="flex items-start justify-between gap-2">
                  <span className="px-2.5 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider bg-farm-green-100 text-farm-green-800">
                    {org.badge}
                  </span>
                  <span className="text-[11px] font-mono text-earth-500 font-bold">
                    {org.acronym}
                  </span>
                </div>

                <div>
                  <h3 className="font-serif text-xl font-bold text-earth-900 leading-snug">
                    {org.name}
                  </h3>
                  <p className="text-[11px] text-terracotta-700 font-semibold mt-1">
                    {org.authority}
                  </p>
                  <p className="text-[10px] text-earth-500 mt-0.5">
                    HQ: {org.headquarters}
                  </p>
                </div>

                <p className="text-xs text-earth-700 leading-relaxed font-normal">
                  {org.description}
                </p>

                {/* Key Contributions */}
                <div className="pt-2 space-y-1.5 border-t border-earth-100">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-earth-500 block">
                    Core Mandate & Standards:
                  </span>
                  <ul className="space-y-1 text-[11px] text-earth-700">
                    {org.keyContributions.slice(0, 3).map((item, i) => (
                      <li key={i} className="flex items-start gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-farm-green-700 shrink-0 mt-0.5" />
                        <span className="leading-tight">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Action Buttons: Direct Visiting Links */}
              <div className="pt-4 border-t border-earth-100 space-y-2">
                <a
                  href={org.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-bold text-white bg-farm-green-800 hover:bg-farm-green-900 rounded-xl transition-all shadow-xs cursor-pointer group"
                >
                  <span>Visit {org.acronym} Website</span>
                  <ExternalLink className="w-3.5 h-3.5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                </a>

                {org.portalUrl && (
                  <a
                    href={org.portalUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-1.5 text-[11px] font-semibold text-earth-700 hover:text-earth-900 hover:bg-earth-100 rounded-lg transition-colors cursor-pointer"
                  >
                    <span>{org.portalLabel || 'Direct Portal Access'}</span>
                    <ArrowRight className="w-3 h-3" />
                  </a>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Informative Note */}
        <div className="p-4 rounded-2xl bg-white border border-earth-200 text-xs text-earth-600 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-2xs">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded-lg bg-farm-green-100 text-farm-green-800 shrink-0">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <span>
              <strong>Open Agricultural Knowledge:</strong> External links take you directly to official government portals and registered non-profit organic farmer federations.
            </span>
          </div>

          <span className="text-[11px] font-semibold text-farm-green-800 shrink-0">
            Certified Organic & Biodynamic Standards
          </span>
        </div>

      </div>
    </section>
  );
};
