import React, { useState } from 'react';
import { SEASONAL_CALENDAR_DATA } from '../data/farmData';
import { Calendar, Sun, CloudRain, Snowflake, Leaf, ArrowRight } from 'lucide-react';
import { PageId } from './Header';

interface SeasonalCalendarProps {
  onNavigate?: (page: PageId) => void;
}

export const SeasonalCalendar: React.FC<SeasonalCalendarProps> = ({ onNavigate }) => {
  const [activeSeason, setActiveSeason] = useState<'Spring' | 'Summer' | 'Autumn' | 'Winter'>('Spring');

  const currentSeasonData =
    SEASONAL_CALENDAR_DATA.find((s) => s.season === activeSeason) || SEASONAL_CALENDAR_DATA[0];

  const seasonIcons = {
    Spring: <Leaf className="w-4 h-4 text-farm-green-700" />,
    Summer: <Sun className="w-4 h-4 text-terracotta-600" />,
    Autumn: <CloudRain className="w-4 h-4 text-earth-700" />,
    Winter: <Snowflake className="w-4 h-4 text-farm-green-600" />,
  };

  const handleOpenSeasonPage = (seasonName: string) => {
    if (onNavigate) {
      onNavigate(seasonName.toLowerCase() as PageId);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <section id="seasonal-calendar" className="py-20 lg:py-28 bg-earth-50 border-b border-earth-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Header */}
        <div className="max-w-3xl space-y-3">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-farm-green-800">
            <span>Biological Crop Cycle</span>
            <span aria-hidden="true" className="text-earth-400">·</span>
            <span className="text-terracotta-700">Earth & Solar Phenology</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-earth-900 tracking-tight">
            The Living Harvest Calendar.
          </h2>
          <p className="text-base text-earth-700 leading-relaxed font-normal">
            Organic farming listens to the celestial seasons and the living earth. Each season has its own
            dedicated harvest rhythms, soil practices, and culinary treats.
          </p>
        </div>

        {/* Season Selector Tabs */}
        <div className="flex items-center gap-2 p-1.5 bg-earth-200/70 rounded-xl max-w-xl border border-earth-300/60">
          {(['Spring', 'Summer', 'Autumn', 'Winter'] as const).map((season) => {
            const isCurrent = activeSeason === season;
            return (
              <button
                key={season}
                type="button"
                onClick={() => setActiveSeason(season)}
                className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg text-xs font-semibold transition-all whitespace-nowrap cursor-pointer ${
                  isCurrent
                    ? 'bg-white text-earth-950 shadow-xs border border-earth-200'
                    : 'text-earth-700 hover:text-earth-950'
                }`}
              >
                {seasonIcons[season]}
                <span>{season}</span>
              </button>
            );
          })}
        </div>

        {/* Active Season Overview Card in Crisp White */}
        <div className="bg-white rounded-2xl border border-earth-200 p-6 sm:p-8 space-y-6 shadow-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-earth-100">
            <div>
              <div className="flex items-center gap-2 text-xs font-semibold text-farm-green-800 uppercase tracking-wider">
                <Calendar className="w-4 h-4 text-terracotta-700" />
                <span>{currentSeasonData.months}</span>
              </div>
              <h3 className="font-serif text-2xl font-bold text-earth-900 mt-1">
                {activeSeason} Field Phenology
              </h3>
            </div>

            {onNavigate && (
              <button
                type="button"
                onClick={() => handleOpenSeasonPage(activeSeason)}
                className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-farm-green-800 hover:bg-farm-green-900 rounded-lg transition-colors cursor-pointer shrink-0"
              >
                <span>Open Dedicated {activeSeason} Page</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Crops List in Current Season */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {currentSeasonData.crops.map((crop, idx) => {
              const statusStyles: Record<string, string> = {
                'Peak Harvest': 'text-farm-green-900 bg-farm-green-100 border-farm-green-200',
                'Greenhouse Nursery': 'text-terracotta-800 bg-terracotta-100 border-terracotta-200',
                'Root Cellared': 'text-earth-900 bg-earth-100 border-earth-300',
                'Emerging': 'text-farm-green-800 bg-farm-green-50 border-farm-green-200',
              };

              return (
                <div
                  key={idx}
                  className="p-5 rounded-xl border border-earth-200 bg-earth-50/50 hover:bg-white hover:border-earth-300 transition-all space-y-2.5 shadow-2xs"
                >
                  <div className="flex items-center justify-between gap-2">
                    <h4 className="font-serif text-base font-bold text-earth-900">
                      {crop.name}
                    </h4>
                    <span
                      className={`text-[11px] font-semibold px-2 py-0.5 rounded-md border ${
                        statusStyles[crop.status] || 'text-earth-800 bg-earth-100'
                      }`}
                    >
                      {crop.status}
                    </span>
                  </div>

                  <p className="text-xs font-medium text-terracotta-700">
                    Heritage Cultivar: {crop.variety}
                  </p>

                  <p className="text-xs text-earth-600 font-normal leading-relaxed">
                    {crop.notes}
                  </p>
                </div>
              );
            })}
          </div>

          <div className="pt-4 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-earth-600 border-t border-earth-100">
            <span>CSA share members receive weekly field dispatch updates detailing exactly what is being picked.</span>
            {onNavigate && (
              <button
                type="button"
                onClick={() => handleOpenSeasonPage(activeSeason)}
                className="text-farm-green-800 hover:text-farm-green-900 font-semibold underline underline-offset-4 shrink-0 cursor-pointer"
              >
                Explore Full {activeSeason} Harvest Guide &rarr;
              </button>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
