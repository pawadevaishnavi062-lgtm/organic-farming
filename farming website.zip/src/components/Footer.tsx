import React, { useState } from 'react';
import { Sprout, Check, ArrowRight, ShieldCheck, ExternalLink, Globe } from 'lucide-react';
import { PageId } from './Header';

interface FooterProps {
  onNavigate?: (page: PageId) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterSubscribed, setNewsletterSubscribed] = useState(false);
  const [emailError, setEmailError] = useState('');

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail.trim() || !newsletterEmail.includes('@')) {
      setEmailError('Please enter a valid email address.');
      return;
    }
    setEmailError('');
    setNewsletterSubscribed(true);
  };

  const handleNav = (page: PageId) => {
    if (onNavigate) {
      onNavigate(page);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-earth-950 text-earth-200 border-t border-earth-800">
      {/* Upper Newsletter & Mission Strip in Rich Loam Earth */}
      <div className="border-b border-earth-800/80 py-12 lg:py-16 bg-earth-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center justify-between">
            <div className="lg:col-span-6 space-y-2">
              <h3 className="font-serif text-2xl font-bold text-white">
                Receive the Dawn Harvest Dispatch
              </h3>
              <p className="text-xs sm:text-sm text-earth-200 font-normal leading-relaxed">
                Every Tuesday morning we announce limited heirloom crop drops, seasonal fruit gluts,
                and weekend farm tour spaces. No spam, ever.
              </p>
            </div>

            <div className="lg:col-span-6">
              {newsletterSubscribed ? (
                <div className="p-4 rounded-xl bg-farm-green-950 border border-farm-green-700 text-farm-green-200 text-xs flex items-center gap-3">
                  <Check className="w-4 h-4 text-farm-green-400 shrink-0" />
                  <span>Thank you for joining. The next Tuesday dawn field note will arrive in your inbox.</span>
                </div>
              ) : (
                <form onSubmit={handleNewsletterSubmit} className="space-y-2">
                  <div className="flex flex-col sm:flex-row gap-2">
                    <input
                      type="email"
                      value={newsletterEmail}
                      onChange={(e) => setNewsletterEmail(e.target.value)}
                      placeholder="Enter your email address..."
                      className="flex-1 px-4 py-2.5 rounded-lg border border-earth-700 bg-earth-800 text-white placeholder-earth-400 text-xs focus:outline-hidden focus:border-farm-green-400 transition-colors"
                    />
                    <button
                      type="submit"
                      className="px-5 py-2.5 text-xs font-semibold text-white bg-farm-green-700 hover:bg-farm-green-600 rounded-lg transition-colors flex items-center justify-center gap-2 shrink-0 border border-farm-green-600 cursor-pointer"
                    >
                      <span>Join Dispatch</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  {emailError && <p className="text-[11px] text-terracotta-400">{emailError}</p>}
                </form>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Main Navigation Matrix across the 4 Website Pages */}
      <div className="py-14 lg:py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-8">
            {/* Col 1: Wordmark & Bio (2 cols wide on desktop) */}
            <div className="lg:col-span-2 space-y-4">
              <button
                type="button"
                onClick={() => handleNav('home')}
                className="flex items-center gap-2.5 text-white font-serif text-xl font-bold tracking-tight cursor-pointer"
              >
                <div className="w-8 h-8 rounded-lg bg-farm-green-800 flex items-center justify-center text-white">
                  <Sprout className="w-5 h-5 text-farm-green-200" />
                </div>
                <span>Verdant Roots Organic</span>
              </button>
              <p className="text-xs text-earth-300 leading-relaxed font-normal max-w-sm">
                A 180-acre certified regenerative organic and biodynamic farmstead in the Pacific Northwest.
                Committed to no-till biological soil building, heirloom biodiversity, and direct community
                harvest delivery since 2012.
              </p>
              <div className="pt-2 text-xs text-earth-300 space-y-1">
                <p className="font-semibold text-white">Cedar Barn Farm Stand Hours:</p>
                <p>Wednesday — Sunday · 8:00 AM – 4:00 PM</p>
                <p>4820 Clover Valley Road, Riverdale Basin, OR</p>
              </div>
            </div>

            {/* Col 2: Living Soil Page */}
            <div className="space-y-3">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-white">
                About & Living Soil
              </h4>
              <ul className="space-y-2 text-xs text-earth-300 font-normal">
                <li>
                  <button
                    type="button"
                    onClick={() => handleNav('about')}
                    className="hover:text-farm-green-300 transition-colors cursor-pointer text-left"
                  >
                    No-Till Agronomy
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => handleNav('about')}
                    className="hover:text-farm-green-300 transition-colors cursor-pointer text-left"
                  >
                    Thermal Composting
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => handleNav('about')}
                    className="hover:text-farm-green-300 transition-colors cursor-pointer text-left"
                  >
                    Soil Lab Analysis
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => handleNav('about')}
                    className="hover:text-farm-green-300 transition-colors cursor-pointer text-left"
                  >
                    Environmental Impact Simulator
                  </button>
                </li>
              </ul>
            </div>

            {/* Col 3: Harvest Market Page */}
            <div className="space-y-3">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-white">
                Harvest Market
              </h4>
              <ul className="space-y-2 text-xs text-earth-300 font-normal">
                <li>
                  <button
                    type="button"
                    onClick={() => handleNav('market')}
                    className="hover:text-farm-green-300 transition-colors cursor-pointer text-left"
                  >
                    The Hearth Share Box
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => handleNav('market')}
                    className="hover:text-farm-green-300 transition-colors cursor-pointer text-left"
                  >
                    The Sprout Share Box
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => handleNav('market')}
                    className="hover:text-farm-green-300 transition-colors cursor-pointer text-left"
                  >
                    Rainbow Heirloom Roots
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => handleNav('vegetables')}
                    className="hover:text-farm-green-300 transition-colors cursor-pointer text-left text-farm-green-300 font-semibold"
                  >
                    Heirloom Vegetables Guide
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => handleNav('fruits')}
                    className="hover:text-farm-green-300 transition-colors cursor-pointer text-left text-terracotta-300 font-semibold"
                  >
                    Orchard Fruits & Brix Guide
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => handleNav('login')}
                    className="hover:text-farm-green-300 transition-colors cursor-pointer text-left font-semibold"
                  >
                    Member Portal / Sign In
                  </button>
                </li>
              </ul>
            </div>

            {/* Col 4: Visit & Stewardship Page */}
            <div className="space-y-3">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-white">
                Visit Us
              </h4>
              <ul className="space-y-2 text-xs text-earth-300 font-normal">
                <li>
                  <button
                    type="button"
                    onClick={() => handleNav('tours')}
                    className="hover:text-farm-green-300 transition-colors cursor-pointer text-left"
                  >
                    Morning Farm Walks
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => handleNav('tours')}
                    className="hover:text-farm-green-300 transition-colors cursor-pointer text-left"
                  >
                    Orchard & Bee Tours
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => handleNav('tours')}
                    className="hover:text-farm-green-300 transition-colors cursor-pointer text-left"
                  >
                    Sourdough Workshops
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => handleNav('tours')}
                    className="hover:text-farm-green-300 transition-colors cursor-pointer text-left"
                  >
                    Cedar Barn Farmstand
                  </button>
                </li>
              </ul>
            </div>

            {/* Col 5: The 4 Farm Standards */}
            <div className="space-y-3">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-white">
                Our Standards
              </h4>
              <ul className="space-y-2 text-xs text-earth-300 font-normal">
                <li>
                  <button
                    type="button"
                    onClick={() => handleNav('acres')}
                    className="hover:text-farm-green-300 transition-colors cursor-pointer text-left"
                  >
                    180+ Acres Land
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => handleNav('varieties')}
                    className="hover:text-farm-green-300 transition-colors cursor-pointer text-left"
                  >
                    42 Heirloom Varieties
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => handleNav('synthetics')}
                    className="hover:text-farm-green-300 transition-colors cursor-pointer text-left"
                  >
                    0% Synthetics Purity
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => handleNav('freshness')}
                    className="hover:text-farm-green-300 transition-colors cursor-pointer text-left"
                  >
                    &lt; 24 Hours Freshness
                  </button>
                </li>
              </ul>
            </div>

            {/* Col 6: Four Seasons Pages */}
            <div className="space-y-3">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-white">
                The 4 Seasons
              </h4>
              <ul className="space-y-2 text-xs text-earth-300 font-normal">
                <li>
                  <button
                    type="button"
                    onClick={() => handleNav('spring')}
                    className="hover:text-farm-green-300 transition-colors cursor-pointer text-left"
                  >
                    Spring Harvest (Mar–May)
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => handleNav('summer')}
                    className="hover:text-farm-green-300 transition-colors cursor-pointer text-left"
                  >
                    Summer Harvest (Jun–Aug)
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => handleNav('autumn')}
                    className="hover:text-farm-green-300 transition-colors cursor-pointer text-left"
                  >
                    Autumn Harvest (Sep–Nov)
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => handleNav('winter')}
                    className="hover:text-farm-green-300 transition-colors cursor-pointer text-left"
                  >
                    Winter Harvest (Dec–Feb)
                  </button>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* DEDICATED VISITING WEBSITES & ORGANIC AUTHORITIES BAR */}
      <div className="border-t border-earth-800/80 py-8 bg-earth-900/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Globe className="w-4 h-4 text-farm-green-400 shrink-0" />
              <h4 className="text-xs font-bold uppercase tracking-wider text-earth-100">
                Official Organic Authorities & Visiting Portals
              </h4>
            </div>
            <span className="text-[11px] text-earth-400">
              National bodies & certified research institutions advancing ecological agriculture
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {/* 1. NCONF */}
            <a
              href="https://ncof.dacnet.nic.in/"
              target="_blank"
              rel="noopener noreferrer"
              className="p-3.5 rounded-xl bg-earth-950/70 border border-earth-800 hover:border-farm-green-600 transition-all flex flex-col justify-between group"
            >
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-farm-green-400 uppercase tracking-wide">
                    Govt. of India
                  </span>
                  <ExternalLink className="w-3.5 h-3.5 text-earth-500 group-hover:text-farm-green-400 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all" />
                </div>
                <p className="font-serif text-xs font-bold text-white group-hover:text-farm-green-300 transition-colors">
                  National Centre for Organic and Natural Farming
                </p>
                <p className="text-[10px] text-earth-400 line-clamp-1">
                  NCONF (Ministry of Agriculture & Farmers Welfare)
                </p>
              </div>
              <span className="text-[10px] text-farm-green-400/90 font-medium mt-2">
                Visit Official Website &rarr;
              </span>
            </a>

            {/* 2. OFAI */}
            <a
              href="https://ofai.org/"
              target="_blank"
              rel="noopener noreferrer"
              className="p-3.5 rounded-xl bg-earth-950/70 border border-earth-800 hover:border-terracotta-500 transition-all flex flex-col justify-between group"
            >
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-terracotta-400 uppercase tracking-wide">
                    Farmer Network
                  </span>
                  <ExternalLink className="w-3.5 h-3.5 text-earth-500 group-hover:text-terracotta-400 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all" />
                </div>
                <p className="font-serif text-xs font-bold text-white group-hover:text-terracotta-300 transition-colors">
                  Organic Farming Association of India
                </p>
                <p className="text-[10px] text-earth-400 line-clamp-1">
                  OFAI Desi Seed Banks & Organic Congress
                </p>
              </div>
              <span className="text-[10px] text-terracotta-400/90 font-medium mt-2">
                Visit OFAI Network &rarr;
              </span>
            </a>

            {/* 3. IFOAM */}
            <a
              href="https://www.ifoam.bio/"
              target="_blank"
              rel="noopener noreferrer"
              className="p-3.5 rounded-xl bg-earth-950/70 border border-earth-800 hover:border-farm-green-600 transition-all flex flex-col justify-between group"
            >
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-farm-green-400 uppercase tracking-wide">
                    Global Apex
                  </span>
                  <ExternalLink className="w-3.5 h-3.5 text-earth-500 group-hover:text-farm-green-400 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all" />
                </div>
                <p className="font-serif text-xs font-bold text-white group-hover:text-farm-green-300 transition-colors">
                  IFOAM – Organics International
                </p>
                <p className="text-[10px] text-earth-400 line-clamp-1">
                  Global Organic Standards & UN FAO Partner
                </p>
              </div>
              <span className="text-[10px] text-farm-green-400/90 font-medium mt-2">
                Visit IFOAM Global &rarr;
              </span>
            </a>

            {/* 4. FiBL & Rodale */}
            <a
              href="https://www.fibl.org/"
              target="_blank"
              rel="noopener noreferrer"
              className="p-3.5 rounded-xl bg-earth-950/70 border border-earth-800 hover:border-farm-green-600 transition-all flex flex-col justify-between group"
            >
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-farm-green-400 uppercase tracking-wide">
                    Scientific Research
                  </span>
                  <ExternalLink className="w-3.5 h-3.5 text-earth-500 group-hover:text-farm-green-400 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all" />
                </div>
                <p className="font-serif text-xs font-bold text-white group-hover:text-farm-green-300 transition-colors">
                  FiBL Research Institute of Organic Agriculture
                </p>
                <p className="text-[10px] text-earth-400 line-clamp-1">
                  Living Soil Microbiology & Carbon Trials
                </p>
              </div>
              <span className="text-[10px] text-farm-green-400/90 font-medium mt-2">
                Visit FiBL Institute &rarr;
              </span>
            </a>
          </div>
        </div>
      </div>

      {/* Certifications & Quiet Copyright Bar */}
      <div className="border-t border-earth-850 py-8 bg-earth-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-6 text-xs text-earth-400">
          <div className="flex flex-wrap items-center gap-x-6 gap-y-2">
            <span className="flex items-center gap-1.5 text-earth-200">
              <ShieldCheck className="w-4 h-4 text-farm-green-400" />
              USDA Organic Certified
            </span>
            <span aria-hidden="true" className="text-earth-700">·</span>
            <span className="text-earth-200">Demeter Biodynamic Certified</span>
            <span aria-hidden="true" className="text-earth-700">·</span>
            <span className="text-earth-200">Non-GMO Project Verified</span>
            <span aria-hidden="true" className="text-earth-700">·</span>
            <span className="text-earth-200">CCOF Organic Partner</span>
          </div>

          <div className="flex items-center gap-4 text-earth-400">
            <span>© {new Date().getFullYear()} Verdant Roots Organic Farmstead.</span>
            <span>All rights reserved.</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
