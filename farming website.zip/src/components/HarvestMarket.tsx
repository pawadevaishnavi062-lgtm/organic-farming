import React, { useState, useMemo } from 'react';
import { ProduceItem } from '../types/farm';
import { PRODUCE_ITEMS, FARM_IMAGES } from '../data/farmData';
import { Plus, Check, Search, Sparkles, X, Shield } from 'lucide-react';

interface HarvestMarketProps {
  onAddToCart: (item: ProduceItem) => void;
}

export const HarvestMarket: React.FC<HarvestMarketProps> = ({ onAddToCart }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [addedItemId, setAddedItemId] = useState<string | null>(null);
  const [inspectedProduct, setInspectedProduct] = useState<ProduceItem | null>(null);

  const categories = [
    { id: 'all', label: 'All Farm Goods' },
    { id: 'boxes', label: 'Weekly Farm Boxes' },
    { id: 'vegetables', label: 'Heirloom Greens & Roots' },
    { id: 'fruits', label: 'Orchard Fruits' },
    { id: 'pantry', label: 'Farm Pantry & Apiary' },
  ];

  const filteredItems = useMemo(() => {
    return PRODUCE_ITEMS.filter((item) => {
      const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
      const matchesSearch =
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.heirloomVariety.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.description.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [selectedCategory, searchQuery]);

  const handleAdd = (item: ProduceItem, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    onAddToCart(item);
    setAddedItemId(item.id);
    setTimeout(() => {
      setAddedItemId(null);
    }, 1200);
  };

  return (
    <section id="harvest-market" className="py-20 lg:py-28 bg-white border-b border-earth-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="max-w-2xl space-y-3">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-farm-green-800">
              <span>Direct Farmstead Marketplace</span>
              <span aria-hidden="true" className="text-earth-300">·</span>
              <span className="text-terracotta-700">Dawn Harvested Produce</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-earth-900 tracking-tight">
              Fresh from the Living Earth.
            </h2>
            <p className="text-base text-earth-700 leading-relaxed font-normal">
              Every harvest box and pantry item is gathered by hand at dawn, packed in compostable
              wax-free cartons, and delivered straight to your door or farmstand collection point.
            </p>
          </div>

          {/* Search Input in Warm Earth Tint */}
          <div className="w-full md:w-72 relative">
            <Search className="w-4 h-4 text-earth-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search heirloom crops..."
              className="w-full pl-10 pr-4 py-2.5 text-sm rounded-lg border border-earth-200 bg-earth-50 focus:bg-white focus:outline-hidden focus:border-farm-green-700 text-earth-900 placeholder-earth-400 transition-all shadow-2xs"
            />
          </div>
        </div>

        {/* Spotlight Marquee: Harvest Box Showcase in Warm Earth & White */}
        <div className="rounded-2xl border border-earth-200 overflow-hidden bg-earth-50 grid grid-cols-1 lg:grid-cols-12 items-center shadow-xs">
          <div className="lg:col-span-7 p-6 sm:p-10 space-y-5">
            <div className="flex items-center gap-2 text-xs font-semibold text-terracotta-700 uppercase tracking-wider">
              <Sparkles className="w-4 h-4 text-farm-green-700" />
              <span>Community Supported Agriculture (CSA)</span>
            </div>
            <h3 className="font-serif text-2xl sm:text-3xl font-bold text-earth-900">
              The Hearth Harvest Share Box
            </h3>
            <p className="text-sm sm:text-base text-earth-700 leading-relaxed font-normal">
              Our flagship weekly box provides 12 to 14 freshly picked varieties of seasonal roots,
              tender heirloom greens, culinary herbs, and crisp brassicas. Tailored to nourish a family
              for a full week with zero synthetic chemical residues.
            </p>
            <div className="flex flex-wrap items-center gap-y-2 gap-x-4 text-xs text-earth-600">
              <span>Includes printed farm recipe card</span>
              <span aria-hidden="true" className="text-earth-300">·</span>
              <span>Free compostable packaging</span>
              <span aria-hidden="true" className="text-earth-300">·</span>
              <span>Pause or cancel anytime</span>
            </div>
            <div className="pt-2 flex items-center gap-4">
              <span className="text-2xl font-bold font-serif text-earth-900 tabular-nums">
                $42.00 <span className="text-xs text-earth-500 font-sans font-normal">/ week</span>
              </span>
              <button
                type="button"
                onClick={() => handleAdd(PRODUCE_ITEMS[0])}
                className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold text-white bg-farm-green-800 hover:bg-farm-green-900 border border-farm-green-700 rounded-lg shadow-xs hover:shadow-sm transition-all whitespace-nowrap"
              >
                {addedItemId === PRODUCE_ITEMS[0].id ? (
                  <>
                    <Check className="w-4 h-4 text-farm-green-200" />
                    <span>Added to Basket</span>
                  </>
                ) : (
                  <>
                    <Plus className="w-4 h-4" />
                    <span>Subscribe to Share</span>
                  </>
                )}
              </button>
            </div>
          </div>
          <div className="lg:col-span-5 h-64 lg:h-full relative overflow-hidden bg-earth-200">
            <img
              src={FARM_IMAGES.harvestBasket}
              alt="Rustic wooden harvest crate brimming with fresh rainbow carrots, beets, and kale"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        {/* Functional Category Filter Tabs in Earth & Green styling */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none border-b border-earth-200">
          {categories.map((cat) => (
            <button
              key={cat.id}
              type="button"
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                selectedCategory === cat.id
                  ? 'bg-farm-green-800 text-white shadow-xs'
                  : 'text-earth-700 hover:text-earth-950 hover:bg-earth-100'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Product Cards Grid: Clean White Cards with Earth & Green Highlights */}
        {filteredItems.length === 0 ? (
          <div className="text-center py-16 bg-earth-50 rounded-2xl border border-earth-200 space-y-3">
            <p className="text-base font-semibold text-earth-800">No matching harvest items found</p>
            <p className="text-xs text-earth-500">Try adjusting your search query or switching categories.</p>
            <button
              type="button"
              onClick={() => {
                setSelectedCategory('all');
                setSearchQuery('');
              }}
              className="px-4 py-2 text-xs font-semibold text-farm-green-800 border border-farm-green-800/30 rounded-lg hover:bg-farm-green-50 transition-colors"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredItems.map((item) => {
              const isAdded = addedItemId === item.id;
              return (
                <div
                  key={item.id}
                  onClick={() => setInspectedProduct(item)}
                  className="group cursor-pointer bg-white rounded-xl border border-earth-200 hover:border-farm-green-700/60 p-4 flex flex-col justify-between transition-all hover:shadow-xs shadow-2xs"
                >
                  <div className="space-y-3">
                    {/* Real Product Photography */}
                    {item.image ? (
                      <div className="h-44 w-full rounded-lg overflow-hidden bg-earth-100 relative">
                        <img
                          src={item.image}
                          alt={item.name}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                      </div>
                    ) : (
                      <div className="h-44 w-full rounded-lg bg-earth-100/60 flex items-center justify-center text-earth-400">
                        <Sparkles className="w-6 h-6 text-earth-300" />
                      </div>
                    )}

                    {/* Clean unboxed metadata with dot separator */}
                    <div className="flex items-center justify-between text-xs text-earth-500">
                      <span className="capitalize">{item.category}</span>
                      <span aria-hidden="true" className="text-earth-300">·</span>
                      <span className="truncate max-w-[130px] font-medium text-farm-green-800">{item.organicCert}</span>
                    </div>

                    {/* Product Name */}
                    <h3 className="font-serif text-base font-bold text-earth-900 group-hover:text-farm-green-800 transition-colors">
                      {item.name}
                    </h3>

                    {/* Variety and Description */}
                    <p className="text-xs font-medium text-terracotta-700">
                      Variety: {item.heirloomVariety}
                    </p>
                    <p className="text-xs text-earth-600 leading-relaxed line-clamp-2 font-normal">
                      {item.description}
                    </p>
                  </div>

                  {/* Price & Action Module */}
                  <div className="pt-5 mt-4 border-t border-earth-100 flex items-center justify-between gap-3">
                    <div>
                      <div className="font-serif text-base font-bold text-earth-900 tabular-nums">
                        ${item.price.toFixed(2)}
                      </div>
                      <div className="text-[11px] text-earth-500 truncate max-w-[120px]">
                        {item.unit}
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={(e) => handleAdd(item, e)}
                      aria-label={`Add ${item.name} to harvest basket`}
                      className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 shrink-0 ${
                        isAdded
                          ? 'bg-farm-green-800 text-white'
                          : 'bg-earth-100 text-earth-900 hover:bg-farm-green-800 hover:text-white'
                      }`}
                    >
                      {isAdded ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>Added</span>
                        </>
                      ) : (
                        <>
                          <Plus className="w-3.5 h-3.5" />
                          <span>Add</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Product Inspection Modal in Crisp White with Earth Frame */}
        {inspectedProduct && (
          <div
            className="fixed inset-0 z-50 bg-earth-950/65 backdrop-blur-xs flex items-center justify-center p-4"
            onClick={() => setInspectedProduct(null)}
          >
            <div
              className="bg-white rounded-2xl max-w-lg w-full p-6 sm:p-8 space-y-6 shadow-2xl border border-earth-200 animate-in fade-in zoom-in-95 duration-150"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="text-xs font-medium text-farm-green-800 uppercase tracking-wider">
                    {inspectedProduct.category} · {inspectedProduct.organicCert}
                  </div>
                  <h3 className="font-serif text-2xl font-bold text-earth-900 mt-1">
                    {inspectedProduct.name}
                  </h3>
                  <p className="text-sm text-terracotta-700 mt-0.5 font-medium">
                    Heritage Variety: {inspectedProduct.heirloomVariety}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setInspectedProduct(null)}
                  className="p-1.5 text-earth-400 hover:text-earth-700 rounded-lg hover:bg-earth-100 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {inspectedProduct.image && (
                <div className="h-52 w-full rounded-xl overflow-hidden bg-earth-100 border border-earth-200">
                  <img
                    src={inspectedProduct.image}
                    alt={inspectedProduct.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>
              )}

              <div className="space-y-3 text-sm text-earth-700 font-normal leading-relaxed">
                <p>{inspectedProduct.description}</p>
                <div className="p-3.5 bg-earth-50 rounded-xl border border-earth-200 space-y-1 text-xs">
                  <div className="font-semibold text-earth-900 flex items-center gap-1.5">
                    <Shield className="w-3.5 h-3.5 text-farm-green-700" />
                    Harvest & Living Soil Guarantee
                  </div>
                  <p className="text-earth-600">
                    Timing: {inspectedProduct.harvestWindow}. Never irradiated, treated with chemical ripeners, or synthetic waxes.
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-earth-100">
                <div>
                  <div className="font-serif text-2xl font-bold text-earth-900 tabular-nums">
                    ${inspectedProduct.price.toFixed(2)}
                  </div>
                  <div className="text-xs text-earth-500">{inspectedProduct.unit}</div>
                </div>

                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      handleAdd(inspectedProduct);
                      setInspectedProduct(null);
                    }}
                    className="px-5 py-2.5 text-xs font-semibold text-white bg-farm-green-800 hover:bg-farm-green-900 rounded-lg transition-colors flex items-center gap-2"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add to Harvest Basket</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
