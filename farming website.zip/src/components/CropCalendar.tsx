import React, { useState, useMemo } from 'react';
import { ProduceItem } from '../types/farm';
import { Search, Filter, Calendar, Sparkles, Check, Info, Sprout, Plus, X } from 'lucide-react';

export interface CropAvailability {
  id: string;
  name: string;
  variety: string;
  category: 'leafy' | 'roots' | 'fruiting' | 'alliums_legumes' | 'brassicas';
  // 12 months: Jan (0) to Dec (11)
  schedule: Array<'harvest' | 'sow' | 'storage' | 'none'>;
  daysToMaturity: number;
  optimalSoilTemp: string;
  soilNeeds: string;
  flavorNotes: string;
  companionPlants: string[];
  matchedMarketItemId?: string;
  price?: number;
  unit?: string;
}

const MONTH_NAMES = [
  'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
];

const FULL_MONTH_NAMES = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];

export const CROP_CALENDAR_DATA: CropAvailability[] = [
  {
    id: 'crop-carrots',
    name: 'Rainbow Heirloom Carrots',
    variety: 'Cosmic Purple, Solar Yellow & Scarlet Nantes',
    category: 'roots',
    schedule: ['storage', 'storage', 'sow', 'sow', 'harvest', 'harvest', 'harvest', 'harvest', 'harvest', 'harvest', 'storage', 'storage'],
    daysToMaturity: 68,
    optimalSoilTemp: '55°F – 70°F',
    soilNeeds: 'Deep broadforked sandy loam, rich in living compost and rock minerals',
    flavorNotes: 'Crisp, naturally sweet with earthy pine hints; exceptional raw or maple-roasted',
    companionPlants: ['Rosemary', 'Lettuce', 'Chives'],
    matchedMarketItemId: 'veg-carrots',
    price: 4.5,
    unit: 'Bunch (~1.5 lbs)',
  },
  {
    id: 'crop-kale',
    name: 'Tuscan Dinosaur Kale (Cavolo Nero)',
    variety: 'Italian Lacinato Heirloom',
    category: 'brassicas',
    schedule: ['harvest', 'harvest', 'sow', 'sow', 'harvest', 'harvest', 'harvest', 'harvest', 'harvest', 'harvest', 'harvest', 'harvest'],
    daysToMaturity: 55,
    optimalSoilTemp: '60°F – 68°F',
    soilNeeds: 'High organic matter, nitrogen-fixing clover cover mulch',
    flavorNotes: 'Deep mineral richness; frost-kissed autumn leaves develop intense honeyed sweetness',
    companionPlants: ['Beets', 'Onions', 'Aromatic Herbs'],
    matchedMarketItemId: 'veg-kale',
    price: 3.75,
    unit: 'Large bunch (~1 lb)',
  },
  {
    id: 'crop-tomatoes',
    name: 'Cherokee Purple & Sungold Tomatoes',
    variety: 'Indeterminate Heritage Heirlooms',
    category: 'fruiting',
    schedule: ['none', 'none', 'sow', 'sow', 'sow', 'harvest', 'harvest', 'harvest', 'harvest', 'none', 'none', 'none'],
    daysToMaturity: 78,
    optimalSoilTemp: '70°F – 85°F',
    soilNeeds: 'High biological potassium and compost tea foliar drenches',
    flavorNotes: 'Complex balance of deep fruit sugars and bright acid; smoky wine-like undertones',
    companionPlants: ['Basil', 'Marigolds', 'Borage'],
    matchedMarketItemId: 'veg-tomatoes',
    price: 5.5,
    unit: 'Pint basket (~12 oz)',
  },
  {
    id: 'crop-spinach',
    name: 'Bloomsdale Long-Standing Spinach',
    variety: '1925 Heirloom Savoyed Spinach',
    category: 'leafy',
    schedule: ['harvest', 'harvest', 'harvest', 'harvest', 'sow', 'none', 'none', 'none', 'sow', 'harvest', 'harvest', 'harvest'],
    daysToMaturity: 45,
    optimalSoilTemp: '45°F – 65°F',
    soilNeeds: 'Moist cold loam with high earthworm cast concentrations',
    flavorNotes: 'Thick, crinkly dark emerald leaves with buttery, succulent texture',
    companionPlants: ['Strawberries', 'Peas', 'Radishes'],
  },
  {
    id: 'crop-beets',
    name: 'Chioggia Candy Cane & Golden Beets',
    variety: '1840 Northern Italian Heirloom',
    category: 'roots',
    schedule: ['storage', 'storage', 'sow', 'sow', 'harvest', 'harvest', 'harvest', 'harvest', 'harvest', 'harvest', 'storage', 'storage'],
    daysToMaturity: 58,
    optimalSoilTemp: '60°F – 75°F',
    soilNeeds: 'Loose crumbly soil with balanced phosphorus and wood ash minerals',
    flavorNotes: 'Mild, sweet earthy flavor without the harsh metallic aftertaste of industrial beets',
    companionPlants: ['Bush Beans', 'Lettuce', 'Cabbage'],
    matchedMarketItemId: 'veg-beets',
    price: 4.25,
    unit: 'Bunch of 4-5 roots',
  },
  {
    id: 'crop-peppers',
    name: 'Jimmy Nardello Sweet Italian Frying Peppers',
    variety: '1887 Basilicata Landrace',
    category: 'fruiting',
    schedule: ['none', 'none', 'sow', 'sow', 'sow', 'harvest', 'harvest', 'harvest', 'harvest', 'none', 'none', 'none'],
    daysToMaturity: 80,
    optimalSoilTemp: '75°F – 85°F',
    soilNeeds: 'Passive solar heated beds, well-draining organic compost',
    flavorNotes: 'Intensely sweet, thin-skinned and aromatic when pan-charred in extra virgin olive oil',
    companionPlants: ['Tomatoes', 'Oregano', 'Parsley'],
  },
  {
    id: 'crop-peas',
    name: 'Super Sugar Snap & Shelling Peas',
    variety: 'Trellised Cool Season Legume',
    category: 'alliums_legumes',
    schedule: ['none', 'none', 'sow', 'harvest', 'harvest', 'harvest', 'none', 'none', 'sow', 'harvest', 'none', 'none'],
    daysToMaturity: 62,
    optimalSoilTemp: '50°F – 65°F',
    soilNeeds: 'Rhizobium-inoculated living soil; fixes its own nitrogen',
    flavorNotes: 'Crisp, juicy edible pods packed with natural botanical sugars',
    companionPlants: ['Carrots', 'Radishes', 'Corn'],
  },
  {
    id: 'crop-leeks',
    name: 'Bleu de Solaise Winter King Leeks',
    variety: '19th Century French Heirloom',
    category: 'alliums_legumes',
    schedule: ['harvest', 'harvest', 'sow', 'sow', 'none', 'none', 'none', 'harvest', 'harvest', 'harvest', 'harvest', 'harvest'],
    daysToMaturity: 110,
    optimalSoilTemp: '55°F – 70°F',
    soilNeeds: 'Deep blanched trenches mulched with straw and aged oak leaf compost',
    flavorNotes: 'Delicate, sweet allium flavor with velvety melted texture when slow-braised',
    companionPlants: ['Carrots', 'Strawberries', 'Celery'],
  },
  {
    id: 'crop-squash',
    name: 'Waltham Butternut & Kabocha Squash',
    variety: 'Heritage Vining Winter Squash',
    category: 'fruiting',
    schedule: ['storage', 'storage', 'none', 'none', 'sow', 'sow', 'none', 'none', 'harvest', 'harvest', 'storage', 'storage'],
    daysToMaturity: 100,
    optimalSoilTemp: '70°F – 85°F',
    soilNeeds: 'Sprawling clover cover-cropped mounds enriched with thermal compost',
    flavorNotes: 'Dense, nutty, caramel-like flesh with velvety smooth soup consistency',
    companionPlants: ['Corn', 'Pole Beans', 'Sunflowers'],
  },
  {
    id: 'crop-radishes',
    name: 'Watermelon & French Breakfast Radishes',
    variety: 'Fast-Maturing Brassica Roots',
    category: 'roots',
    schedule: ['none', 'sow', 'harvest', 'harvest', 'harvest', 'sow', 'none', 'sow', 'harvest', 'harvest', 'harvest', 'none'],
    daysToMaturity: 28,
    optimalSoilTemp: '50°F – 65°F',
    soilNeeds: 'Evenly moist compost beds; rapid growth produces tender roots',
    flavorNotes: 'Bright peppery zest with refreshing aquatic crispness and stunning magenta interior',
    companionPlants: ['Chervil', 'Spinach', 'Lettuce'],
  },
  {
    id: 'crop-garlic',
    name: 'Music Hardneck Heirloom Garlic',
    variety: 'Porcelain Landrace Cultivar',
    category: 'alliums_legumes',
    schedule: ['storage', 'storage', 'none', 'none', 'none', 'harvest', 'harvest', 'storage', 'storage', 'sow', 'storage', 'storage'],
    daysToMaturity: 240,
    optimalSoilTemp: '40°F – 55°F (Winter Vernalization)',
    soilNeeds: 'Over-wintered under 4 inches of straw mulch in mycorrhizal loam',
    flavorNotes: 'Robust, spicy culinary heat that mellows into rich nutty garlic butter when roasted',
    companionPlants: ['Tomatoes', 'Peppers', 'Roses'],
  },
  {
    id: 'crop-salad',
    name: 'Salad Bowl & Butterhead Heritage Lettuces',
    variety: 'Continuous Cut-and-Come-Again',
    category: 'leafy',
    schedule: ['harvest', 'harvest', 'harvest', 'harvest', 'harvest', 'harvest', 'none', 'none', 'harvest', 'harvest', 'harvest', 'harvest'],
    daysToMaturity: 40,
    optimalSoilTemp: '55°F – 68°F',
    soilNeeds: 'Surface compost top-dressing, drip tape irrigation to prevent splash',
    flavorNotes: 'Tender, sweet, silky leaves free of any bitterness or chemical herbicide trace',
    companionPlants: ['Chives', 'Cilantro', 'Carrots'],
  },
];

interface CropCalendarProps {
  onAddToCart?: (item: ProduceItem) => void;
}

export const CropCalendar: React.FC<CropCalendarProps> = ({ onAddToCart }) => {
  const currentMonthIndex = new Date().getMonth();
  const [selectedMonth, setSelectedMonth] = useState<number | 'all'>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [onlyHarvesting, setOnlyHarvesting] = useState(false);
  const [inspectedCrop, setInspectedCrop] = useState<CropAvailability | null>(null);

  const categories = [
    { id: 'all', label: 'All Vegetables' },
    { id: 'roots', label: 'Roots & Tubers' },
    { id: 'leafy', label: 'Leafy Greens' },
    { id: 'fruiting', label: 'Fruiting & Nightshades' },
    { id: 'alliums_legumes', label: 'Alliums & Legumes' },
    { id: 'brassicas', label: 'Brassicas' },
  ];

  // Filtering crops based on controls
  const filteredCrops = useMemo(() => {
    return CROP_CALENDAR_DATA.filter((crop) => {
      const matchesCategory = selectedCategory === 'all' || crop.category === selectedCategory;
      const matchesSearch =
        crop.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        crop.variety.toLowerCase().includes(searchQuery.toLowerCase()) ||
        crop.flavorNotes.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesMonth =
        selectedMonth === 'all' ||
        crop.schedule[selectedMonth] === 'harvest' ||
        (!onlyHarvesting && crop.schedule[selectedMonth] !== 'none');

      const matchesHarvestOnly =
        !onlyHarvesting ||
        (selectedMonth === 'all'
          ? crop.schedule[currentMonthIndex] === 'harvest'
          : crop.schedule[selectedMonth] === 'harvest');

      return matchesCategory && matchesSearch && matchesMonth && matchesHarvestOnly;
    });
  }, [selectedCategory, searchQuery, selectedMonth, onlyHarvesting, currentMonthIndex]);

  // Statistics for current or selected month
  const activeMonthIdx = selectedMonth === 'all' ? currentMonthIndex : selectedMonth;
  const harvestingCount = CROP_CALENDAR_DATA.filter(
    (c) => c.schedule[activeMonthIdx] === 'harvest'
  ).length;
  const sowingCount = CROP_CALENDAR_DATA.filter(
    (c) => c.schedule[activeMonthIdx] === 'sow'
  ).length;
  const storageCount = CROP_CALENDAR_DATA.filter(
    (c) => c.schedule[activeMonthIdx] === 'storage'
  ).length;

  const handleOrderMatched = (crop: CropAvailability) => {
    if (onAddToCart) {
      onAddToCart({
        id: crop.matchedMarketItemId || crop.id,
        name: crop.name,
        category: 'vegetables',
        price: crop.price || 4.5,
        unit: crop.unit || 'Farm Harvest Portion',
        heirloomVariety: crop.variety,
        description: crop.flavorNotes,
        harvestWindow: 'Morning field harvest',
        organicCert: '100% Certified Organic',
        inStock: true,
      });
      setInspectedCrop(null);
    }
  };

  return (
    <section id="crop-calendar" className="py-20 lg:py-28 bg-white border-b border-earth-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="max-w-3xl space-y-3">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-farm-green-800">
              <Calendar className="w-4 h-4 text-terracotta-700" />
              <span>Interactive Seasonality Matrix</span>
              <span aria-hidden="true" className="text-earth-300">·</span>
              <span className="text-terracotta-700">12-Month Phenology</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-earth-900 tracking-tight">
              Seasonal Vegetable Harvest Calendar
            </h2>
            <p className="text-base text-earth-700 leading-relaxed font-normal">
              Explore when our certified organic heirloom crops are sown in nursery hoop houses,
              harvested at peak brix sweetness, or cured in natural cellars throughout the year.
            </p>
          </div>

          {/* Quick Search */}
          <div className="w-full md:w-72 relative">
            <Search className="w-4 h-4 text-earth-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search vegetable or variety..."
              className="w-full pl-10 pr-4 py-2.5 text-xs rounded-lg border border-earth-200 bg-earth-50 focus:bg-white focus:outline-hidden focus:border-farm-green-700 text-earth-900 placeholder-earth-400 transition-all shadow-2xs"
            />
          </div>
        </div>

        {/* 3 Metric Badges for Selected Month */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="p-4 rounded-xl bg-farm-green-50 border border-farm-green-200 flex items-center justify-between">
            <div className="space-y-0.5">
              <p className="text-xs font-semibold text-farm-green-900">
                Peak Field Harvest ({FULL_MONTH_NAMES[activeMonthIdx]})
              </p>
              <p className="text-[11px] text-farm-green-700">Picked fresh daily for CSA shares</p>
            </div>
            <span className="font-serif text-2xl font-bold text-farm-green-800 tabular-nums">
              {harvestingCount}
            </span>
          </div>

          <div className="p-4 rounded-xl bg-terracotta-50 border border-terracotta-200 flex items-center justify-between">
            <div className="space-y-0.5">
              <p className="text-xs font-semibold text-terracotta-800">
                Greenhouse & Sowing ({FULL_MONTH_NAMES[activeMonthIdx]})
              </p>
              <p className="text-[11px] text-terracotta-700">Emerging seedlings in compost beds</p>
            </div>
            <span className="font-serif text-2xl font-bold text-terracotta-700 tabular-nums">
              {sowingCount}
            </span>
          </div>

          <div className="p-4 rounded-xl bg-earth-100 border border-earth-300 flex items-center justify-between">
            <div className="space-y-0.5">
              <p className="text-xs font-semibold text-earth-900">
                Root Cellared Storage ({FULL_MONTH_NAMES[activeMonthIdx]})
              </p>
              <p className="text-[11px] text-earth-600">Preserved in damp sand cellars</p>
            </div>
            <span className="font-serif text-2xl font-bold text-earth-800 tabular-nums">
              {storageCount}
            </span>
          </div>
        </div>

        {/* Month Selector Bar */}
        <div className="space-y-3">
          <div className="flex items-center justify-between text-xs text-earth-700">
            <span className="font-semibold">Select Month Filter:</span>
            <button
              type="button"
              onClick={() => setSelectedMonth('all')}
              className={`font-semibold cursor-pointer transition-colors ${
                selectedMonth === 'all'
                  ? 'text-farm-green-800 underline'
                  : 'text-earth-500 hover:text-earth-900'
              }`}
            >
              Show Full Year (12 Months)
            </button>
          </div>

          <div className="grid grid-cols-6 sm:grid-cols-12 gap-1.5 p-1.5 bg-earth-100/70 rounded-xl border border-earth-200">
            {MONTH_NAMES.map((month, idx) => {
              const isSelected = selectedMonth === idx;
              const isCurrent = currentMonthIndex === idx;

              return (
                <button
                  key={month}
                  type="button"
                  onClick={() => setSelectedMonth(isSelected ? 'all' : idx)}
                  className={`py-2 px-1 text-xs font-semibold rounded-lg transition-all text-center cursor-pointer relative ${
                    isSelected
                      ? 'bg-farm-green-800 text-white shadow-xs'
                      : 'text-earth-700 hover:bg-white hover:text-earth-900'
                  }`}
                >
                  <span>{month}</span>
                  {isCurrent && (
                    <span
                      aria-hidden="true"
                      className={`block w-1.5 h-1.5 rounded-full mx-auto mt-0.5 ${
                        isSelected ? 'bg-terracotta-300' : 'bg-farm-green-700'
                      }`}
                    />
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Category Filters & Only Harvesting Toggle */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-earth-200">
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {categories.map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                  selectedCategory === cat.id
                    ? 'bg-farm-green-800 text-white shadow-xs'
                    : 'text-earth-700 hover:text-earth-950 hover:bg-earth-100'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          <label className="flex items-center gap-2 text-xs font-medium text-earth-800 cursor-pointer shrink-0">
            <input
              type="checkbox"
              checked={onlyHarvesting}
              onChange={(e) => setOnlyHarvesting(e.target.checked)}
              className="rounded-sm text-farm-green-800 accent-farm-green-800 cursor-pointer"
            />
            <span>Only show currently harvesting</span>
          </label>
        </div>

        {/* Legend */}
        <div className="flex flex-wrap items-center gap-6 text-xs text-earth-700">
          <span className="font-semibold text-earth-900">Timeline Legend:</span>
          <span className="flex items-center gap-2">
            <span className="w-3.5 h-3.5 rounded-sm bg-farm-green-700" />
            <span>Peak Harvest (Field Picked)</span>
          </span>
          <span className="flex items-center gap-2">
            <span className="w-3.5 h-3.5 rounded-sm bg-terracotta-500" />
            <span>Sowing & Greenhouse Nursery</span>
          </span>
          <span className="flex items-center gap-2">
            <span className="w-3.5 h-3.5 rounded-sm bg-earth-500" />
            <span>Cellared / Cured Storage</span>
          </span>
          <span className="flex items-center gap-2 text-earth-400">
            <span className="w-3.5 h-3.5 rounded-sm bg-earth-200" />
            <span>Dormant / Off-Season</span>
          </span>
        </div>

        {/* Interactive Availability Gantt Grid */}
        <div className="bg-white rounded-2xl border border-earth-200 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse min-w-[760px]">
              <thead>
                <tr className="bg-earth-50 border-b border-earth-200 text-xs font-semibold text-earth-800">
                  <th className="py-3.5 px-4 sm:px-6 w-64">Heirloom Vegetable</th>
                  {MONTH_NAMES.map((m, idx) => (
                    <th
                      key={m}
                      className={`py-3.5 px-1.5 text-center w-12 font-mono ${
                        (selectedMonth === idx || (selectedMonth === 'all' && currentMonthIndex === idx))
                          ? 'bg-farm-green-100/70 text-farm-green-950 font-bold'
                          : 'text-earth-600'
                      }`}
                    >
                      {m}
                    </th>
                  ))}
                  <th className="py-3.5 px-4 text-right">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-earth-100 text-xs text-earth-800">
                {filteredCrops.length === 0 ? (
                  <tr>
                    <td colSpan={14} className="py-12 text-center text-earth-500">
                      No crops match the selected filter combination. Try selecting "Show Full Year" or reset filters.
                    </td>
                  </tr>
                ) : (
                  filteredCrops.map((crop) => {
                    return (
                      <tr
                        key={crop.id}
                        onClick={() => setInspectedCrop(crop)}
                        className="hover:bg-earth-50/80 transition-colors cursor-pointer group"
                      >
                        {/* Crop Title & Variety */}
                        <td className="py-3.5 px-4 sm:px-6">
                          <p className="font-serif font-bold text-earth-900 group-hover:text-farm-green-800 transition-colors">
                            {crop.name}
                          </p>
                          <p className="text-[11px] text-terracotta-700 truncate max-w-[200px]">
                            {crop.variety}
                          </p>
                        </td>

                        {/* 12 Months Timeline Grid */}
                        {crop.schedule.map((status, monthIdx) => {
                          const isHighlightedMonth =
                            selectedMonth === monthIdx ||
                            (selectedMonth === 'all' && currentMonthIndex === monthIdx);

                          let statusCell;
                          if (status === 'harvest') {
                            statusCell = (
                              <div
                                title={`${crop.name} - Peak Harvest in ${FULL_MONTH_NAMES[monthIdx]}`}
                                className="h-6 w-full rounded-sm bg-farm-green-700 hover:bg-farm-green-800 transition-colors shadow-2xs"
                              />
                            );
                          } else if (status === 'sow') {
                            statusCell = (
                              <div
                                title={`${crop.name} - Sowing / Greenhouse Nursery in ${FULL_MONTH_NAMES[monthIdx]}`}
                                className="h-6 w-full rounded-sm bg-terracotta-500/80 hover:bg-terracotta-600 transition-colors"
                              />
                            );
                          } else if (status === 'storage') {
                            statusCell = (
                              <div
                                title={`${crop.name} - Root Cellared Storage in ${FULL_MONTH_NAMES[monthIdx]}`}
                                className="h-6 w-full rounded-sm bg-earth-500 hover:bg-earth-600 transition-colors"
                              />
                            );
                          } else {
                            statusCell = (
                              <div className="h-1.5 w-1.5 rounded-full bg-earth-200 mx-auto" />
                            );
                          }

                          return (
                            <td
                              key={monthIdx}
                              className={`py-3.5 px-1 text-center align-middle ${
                                isHighlightedMonth ? 'bg-farm-green-50/50' : ''
                              }`}
                            >
                              {statusCell}
                            </td>
                          );
                        })}

                        {/* Action link */}
                        <td className="py-3.5 px-4 text-right">
                          <span className="text-[11px] font-semibold text-farm-green-800 group-hover:text-farm-green-900 underline underline-offset-2">
                            View Crop
                          </span>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Detailed Vegetable Inspector Modal */}
        {inspectedCrop && (
          <div
            className="fixed inset-0 z-50 bg-earth-950/65 backdrop-blur-xs flex items-center justify-center p-4"
            onClick={() => setInspectedCrop(null)}
          >
            <div
              className="bg-white rounded-2xl max-w-lg w-full p-6 sm:p-8 space-y-6 shadow-2xl border border-earth-200 animate-in fade-in zoom-in-95 duration-150"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-start justify-between gap-4 border-b border-earth-100 pb-4">
                <div>
                  <div className="text-xs font-semibold text-farm-green-800 uppercase tracking-wider">
                    Crop Phenology Profile · {inspectedCrop.category}
                  </div>
                  <h3 className="font-serif text-2xl font-bold text-earth-900 mt-1">
                    {inspectedCrop.name}
                  </h3>
                  <p className="text-xs text-terracotta-700 font-medium">
                    Heritage Cultivar: {inspectedCrop.variety}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setInspectedCrop(null)}
                  className="p-1.5 text-earth-400 hover:text-earth-700 rounded-lg hover:bg-earth-100 transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Agronomic Data Grid */}
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-3 rounded-xl bg-earth-50 border border-earth-200">
                  <span className="text-earth-500 font-medium">Days to Maturity</span>
                  <p className="font-serif text-lg font-bold text-earth-900 tabular-nums">
                    {inspectedCrop.daysToMaturity} Days
                  </p>
                </div>
                <div className="p-3 rounded-xl bg-earth-50 border border-earth-200">
                  <span className="text-earth-500 font-medium">Optimal Soil Temp</span>
                  <p className="font-serif text-lg font-bold text-earth-900 tabular-nums">
                    {inspectedCrop.optimalSoilTemp}
                  </p>
                </div>
              </div>

              {/* Flavor & Soil Characteristics */}
              <div className="space-y-3 text-xs text-earth-700 leading-relaxed">
                <div>
                  <strong className="text-earth-900 block mb-0.5">Culinary Flavor Profile:</strong>
                  <p>{inspectedCrop.flavorNotes}</p>
                </div>

                <div>
                  <strong className="text-earth-900 block mb-0.5">Living Soil Requirements:</strong>
                  <p>{inspectedCrop.soilNeeds}</p>
                </div>

                <div>
                  <strong className="text-earth-900 block mb-1">Companion Plants in Field:</strong>
                  <div className="flex flex-wrap gap-1.5">
                    {inspectedCrop.companionPlants.map((plant) => (
                      <span
                        key={plant}
                        className="px-2.5 py-1 rounded-md bg-farm-green-100 text-farm-green-900 text-[11px] font-medium"
                      >
                        {plant}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-4 border-t border-earth-100 flex items-center justify-between gap-4">
                <div>
                  <span className="text-[11px] text-earth-500 block">Season Status</span>
                  <span
                    className={`font-semibold text-xs ${
                      inspectedCrop.schedule[currentMonthIndex] === 'harvest'
                        ? 'text-farm-green-800'
                        : inspectedCrop.schedule[currentMonthIndex] === 'storage'
                        ? 'text-earth-800'
                        : 'text-terracotta-700'
                    }`}
                  >
                    {inspectedCrop.schedule[currentMonthIndex] === 'harvest'
                      ? 'In Peak Harvest Now'
                      : inspectedCrop.schedule[currentMonthIndex] === 'storage'
                      ? 'Available from Root Cellar'
                      : 'Currently in Nursery'}
                  </span>
                </div>

                {onAddToCart && inspectedCrop.matchedMarketItemId ? (
                  <button
                    type="button"
                    onClick={() => handleOrderMatched(inspectedCrop)}
                    className="px-5 py-2.5 text-xs font-semibold text-white bg-farm-green-800 hover:bg-farm-green-900 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add to Basket (${(inspectedCrop.price || 4.5).toFixed(2)})</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => setInspectedCrop(null)}
                    className="px-4 py-2 text-xs font-semibold text-earth-700 border border-earth-200 rounded-lg hover:bg-earth-50 transition-colors cursor-pointer"
                  >
                    Close Inspector
                  </button>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
