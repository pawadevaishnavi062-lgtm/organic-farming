import React, { useState } from 'react';
import { ShoppingBag, Menu, X, Sprout, ChevronDown, Leaf, Sun, CloudRain, Snowflake, User, Apple, BookOpen } from 'lucide-react';

export type PageId =
  | 'home'
  | 'about'
  | 'market'
  | 'tours'
  | 'spring'
  | 'summer'
  | 'autumn'
  | 'winter'
  | 'acres'
  | 'varieties'
  | 'synthetics'
  | 'freshness'
  | 'vegetables'
  | 'fruits'
  | 'login';

interface HeaderProps {
  activePage: PageId;
  onNavigate: (page: PageId) => void;
  cartCount: number;
  onOpenCart: () => void;
  userName?: string | null;
}

export const Header: React.FC<HeaderProps> = ({
  activePage,
  onNavigate,
  cartCount,
  onOpenCart,
  userName,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [seasonsDropdownOpen, setSeasonsDropdownOpen] = useState(false);
  const [standardsDropdownOpen, setStandardsDropdownOpen] = useState(false);
  const [produceDropdownOpen, setProduceDropdownOpen] = useState(false);
  const [bannerDismissed, setBannerDismissed] = useState(false);

  const handleLinkClick = (page: PageId) => {
    onNavigate(page);
    setMobileMenuOpen(false);
    setSeasonsDropdownOpen(false);
    setStandardsDropdownOpen(false);
    setProduceDropdownOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const isSeasonActive = ['spring', 'summer', 'autumn', 'winter'].includes(activePage);
  const isStandardActive = ['acres', 'varieties', 'synthetics', 'freshness'].includes(activePage);
  const isProduceActive = ['vegetables', 'fruits'].includes(activePage);

  return (
    <>
      {/* Top Seasonal Harvest Alert Banner: Rich Earth & Green */}
      {!bannerDismissed && (
        <aside
          aria-label="Seasonal announcement"
          className="bg-earth-900 text-earth-100 text-xs px-4 py-2 border-b border-earth-800"
        >
          <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
            <div className="flex items-center gap-2 truncate">
              <span className="font-semibold text-farm-green-200">Four Seasons of Harvest:</span>
              <span className="truncate text-earth-200">
                Explore dedicated season guides for Spring, Summer, Autumn, and Winter living soil crops.
              </span>
            </div>
            <div className="flex items-center gap-3 shrink-0">
              <button
                type="button"
                onClick={() => handleLinkClick('spring')}
                className="text-farm-green-300 hover:text-white underline underline-offset-2 hidden sm:inline-block cursor-pointer font-medium"
              >
                Open Spring Page &rarr;
              </button>
              <button
                onClick={() => setBannerDismissed(true)}
                aria-label="Dismiss seasonal banner"
                className="text-earth-300 hover:text-white transition-colors p-1 shrink-0 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </aside>
      )}

      {/* Main Top Navigation: Crisp White & Earth Borders conforming to 3-Zone Contract */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-earth-200 transition-colors shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-8">
          {/* Zone 1: Wordmark element */}
          <button
            type="button"
            onClick={() => handleLinkClick('home')}
            className="flex items-center gap-2.5 text-xl font-serif font-bold text-farm-green-950 tracking-tight whitespace-nowrap shrink-0 group hover:opacity-90 transition-opacity cursor-pointer"
          >
            <div className="w-8 h-8 rounded-lg bg-farm-green-800 flex items-center justify-center text-white shadow-xs">
              <Sprout className="w-5 h-5 text-farm-green-100" />
            </div>
            <span className="font-serif">Verdant Roots Organic</span>
          </button>

          {/* Zone 2: Navigation links with Seasons dropdown */}
          <nav
            aria-label="Primary"
            className="hidden lg:flex items-center gap-7 text-sm font-medium text-earth-800"
          >
            <button
              type="button"
              onClick={() => handleLinkClick('home')}
              className={`transition-colors whitespace-nowrap shrink-0 py-1 cursor-pointer ${
                activePage === 'home'
                  ? 'text-farm-green-800 font-bold border-b-2 border-farm-green-800'
                  : 'hover:text-farm-green-700'
              }`}
            >
              Home
            </button>
            <button
              type="button"
              onClick={() => handleLinkClick('about')}
              className={`transition-colors whitespace-nowrap shrink-0 py-1 cursor-pointer ${
                activePage === 'about'
                  ? 'text-farm-green-800 font-bold border-b-2 border-farm-green-800'
                  : 'hover:text-farm-green-700'
              }`}
            >
              About & Soil
            </button>
            <button
              type="button"
              onClick={() => handleLinkClick('market')}
              className={`transition-colors whitespace-nowrap shrink-0 py-1 cursor-pointer ${
                activePage === 'market'
                  ? 'text-farm-green-800 font-bold border-b-2 border-farm-green-800'
                  : 'hover:text-farm-green-700'
              }`}
            >
              Harvest Market
            </button>

            {/* Dedicated Seasons Dropdown Button */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setSeasonsDropdownOpen(!seasonsDropdownOpen)}
                className={`flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 py-1 cursor-pointer ${
                  isSeasonActive
                    ? 'text-farm-green-800 font-bold border-b-2 border-farm-green-800'
                    : 'hover:text-farm-green-700'
                }`}
              >
                <span>The 4 Seasons</span>
                <ChevronDown className="w-3.5 h-3.5" />
              </button>

              {seasonsDropdownOpen && (
                <div
                  className="absolute top-full left-0 mt-2 w-56 rounded-2xl bg-white border border-earth-200 shadow-xl p-2 space-y-1 animate-in fade-in duration-150 z-50"
                  onMouseLeave={() => setSeasonsDropdownOpen(false)}
                >
                  <button
                    type="button"
                    onClick={() => handleLinkClick('spring')}
                    className={`w-full flex items-center gap-2.5 p-2 rounded-xl text-left text-xs font-semibold transition-colors cursor-pointer ${
                      activePage === 'spring'
                        ? 'bg-farm-green-100 text-farm-green-900'
                        : 'text-earth-800 hover:bg-earth-100'
                    }`}
                  >
                    <Leaf className="w-4 h-4 text-farm-green-700" />
                    <div>
                      <p>Spring Harvest</p>
                      <span className="text-[10px] text-earth-500 font-normal">March — May</span>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleLinkClick('summer')}
                    className={`w-full flex items-center gap-2.5 p-2 rounded-xl text-left text-xs font-semibold transition-colors cursor-pointer ${
                      activePage === 'summer'
                        ? 'bg-farm-green-100 text-farm-green-900'
                        : 'text-earth-800 hover:bg-earth-100'
                    }`}
                  >
                    <Sun className="w-4 h-4 text-terracotta-600" />
                    <div>
                      <p>Summer Harvest</p>
                      <span className="text-[10px] text-earth-500 font-normal">June — August</span>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleLinkClick('autumn')}
                    className={`w-full flex items-center gap-2.5 p-2 rounded-xl text-left text-xs font-semibold transition-colors cursor-pointer ${
                      activePage === 'autumn'
                        ? 'bg-farm-green-100 text-farm-green-900'
                        : 'text-earth-800 hover:bg-earth-100'
                    }`}
                  >
                    <CloudRain className="w-4 h-4 text-earth-700" />
                    <div>
                      <p>Autumn Harvest</p>
                      <span className="text-[10px] text-earth-500 font-normal">Sept — Nov</span>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleLinkClick('winter')}
                    className={`w-full flex items-center gap-2.5 p-2 rounded-xl text-left text-xs font-semibold transition-colors cursor-pointer ${
                      activePage === 'winter'
                        ? 'bg-farm-green-100 text-farm-green-900'
                        : 'text-earth-800 hover:bg-earth-100'
                    }`}
                  >
                    <Snowflake className="w-4 h-4 text-farm-green-600" />
                    <div>
                      <p>Winter Harvest</p>
                      <span className="text-[10px] text-earth-500 font-normal">Dec — Feb</span>
                    </div>
                  </button>
                </div>
              )}
            </div>

            {/* Farm Standards / 4 Pillars Dropdown */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setStandardsDropdownOpen(!standardsDropdownOpen)}
                className={`flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 py-1 cursor-pointer ${
                  isStandardActive
                    ? 'text-farm-green-800 font-bold border-b-2 border-farm-green-800'
                    : 'hover:text-farm-green-700'
                }`}
              >
                <span>Farm Standards</span>
                <ChevronDown className="w-3.5 h-3.5" />
              </button>

              {standardsDropdownOpen && (
                <div
                  className="absolute top-full left-0 mt-2 w-64 rounded-2xl bg-white border border-earth-200 shadow-xl p-2 space-y-1 animate-in fade-in duration-150 z-50"
                  onMouseLeave={() => setStandardsDropdownOpen(false)}
                >
                  <button
                    type="button"
                    onClick={() => handleLinkClick('acres')}
                    className={`w-full flex items-center gap-2.5 p-2 rounded-xl text-left text-xs font-semibold transition-colors cursor-pointer ${
                      activePage === 'acres'
                        ? 'bg-farm-green-100 text-farm-green-900'
                        : 'text-earth-800 hover:bg-earth-100'
                    }`}
                  >
                    <div className="p-1 rounded bg-farm-green-100 text-farm-green-800">
                      <Sprout className="w-3.5 h-3.5" />
                    </div>
                    <div>
                      <p>180+ Acres Land</p>
                      <span className="text-[10px] text-earth-500 font-normal">Living soil & ecosystem</span>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleLinkClick('varieties')}
                    className={`w-full flex items-center gap-2.5 p-2 rounded-xl text-left text-xs font-semibold transition-colors cursor-pointer ${
                      activePage === 'varieties'
                        ? 'bg-farm-green-100 text-farm-green-900'
                        : 'text-earth-800 hover:bg-earth-100'
                    }`}
                  >
                    <div className="p-1 rounded bg-terracotta-100 text-terracotta-700">
                      <Leaf className="w-3.5 h-3.5" />
                    </div>
                    <div>
                      <p>42 Heirloom Varieties</p>
                      <span className="text-[10px] text-earth-500 font-normal">Ancestral open-pollinated</span>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleLinkClick('synthetics')}
                    className={`w-full flex items-center gap-2.5 p-2 rounded-xl text-left text-xs font-semibold transition-colors cursor-pointer ${
                      activePage === 'synthetics'
                        ? 'bg-farm-green-100 text-farm-green-900'
                        : 'text-earth-800 hover:bg-earth-100'
                    }`}
                  >
                    <div className="p-1 rounded bg-farm-green-100 text-farm-green-800">
                      <Sprout className="w-3.5 h-3.5" />
                    </div>
                    <div>
                      <p>0% Synthetics</p>
                      <span className="text-[10px] text-earth-500 font-normal">Pure biological farming</span>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleLinkClick('freshness')}
                    className={`w-full flex items-center gap-2.5 p-2 rounded-xl text-left text-xs font-semibold transition-colors cursor-pointer ${
                      activePage === 'freshness'
                        ? 'bg-farm-green-100 text-farm-green-900'
                        : 'text-earth-800 hover:bg-earth-100'
                    }`}
                  >
                    <div className="p-1 rounded bg-terracotta-100 text-terracotta-700">
                      <Sun className="w-3.5 h-3.5" />
                    </div>
                    <div>
                      <p>&lt; 24 Hours Freshness</p>
                      <span className="text-[10px] text-earth-500 font-normal">Dawn-to-door protocol</span>
                    </div>
                  </button>
                </div>
              )}
            </div>

            {/* Produce Guide Dropdown */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setProduceDropdownOpen(!produceDropdownOpen)}
                className={`flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 py-1 cursor-pointer ${
                  isProduceActive
                    ? 'text-farm-green-800 font-bold border-b-2 border-farm-green-800'
                    : 'hover:text-farm-green-700'
                }`}
              >
                <span>Produce Guide</span>
                <ChevronDown className="w-3.5 h-3.5" />
              </button>

              {produceDropdownOpen && (
                <div
                  className="absolute top-full left-0 mt-2 w-64 rounded-2xl bg-white border border-earth-200 shadow-xl p-2 space-y-1 animate-in fade-in duration-150 z-50"
                  onMouseLeave={() => setProduceDropdownOpen(false)}
                >
                  <button
                    type="button"
                    onClick={() => handleLinkClick('vegetables')}
                    className={`w-full flex items-center gap-2.5 p-2 rounded-xl text-left text-xs font-semibold transition-colors cursor-pointer ${
                      activePage === 'vegetables'
                        ? 'bg-farm-green-100 text-farm-green-900'
                        : 'text-earth-800 hover:bg-earth-100'
                    }`}
                  >
                    <div className="p-1 rounded bg-farm-green-100 text-farm-green-800">
                      <Sprout className="w-3.5 h-3.5" />
                    </div>
                    <div>
                      <p>Heirloom Vegetables</p>
                      <span className="text-[10px] text-earth-500 font-normal">Living soil, 7 families, nutrition</span>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleLinkClick('fruits')}
                    className={`w-full flex items-center gap-2.5 p-2 rounded-xl text-left text-xs font-semibold transition-colors cursor-pointer ${
                      activePage === 'fruits'
                        ? 'bg-farm-green-100 text-farm-green-900'
                        : 'text-earth-800 hover:bg-earth-100'
                    }`}
                  >
                    <div className="p-1 rounded bg-terracotta-100 text-terracotta-700">
                      <Apple className="w-3.5 h-3.5" />
                    </div>
                    <div>
                      <p>Orchard Fruits</p>
                      <span className="text-[10px] text-earth-500 font-normal">Centennial trees, brix sweetness</span>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleLinkClick('varieties')}
                    className={`w-full flex items-center gap-2.5 p-2 rounded-xl text-left text-xs font-semibold transition-colors cursor-pointer ${
                      activePage === 'varieties'
                        ? 'bg-farm-green-100 text-farm-green-900'
                        : 'text-earth-800 hover:bg-earth-100'
                    }`}
                  >
                    <div className="p-1 rounded bg-earth-100 text-earth-800">
                      <BookOpen className="w-3.5 h-3.5" />
                    </div>
                    <div>
                      <p>All 42 Cultivars Directory</p>
                      <span className="text-[10px] text-earth-500 font-normal">Photos & community likes</span>
                    </div>
                  </button>
                </div>
              )}
            </div>

            <button
              type="button"
              onClick={() => handleLinkClick('tours')}
              className={`transition-colors whitespace-nowrap shrink-0 py-1 cursor-pointer ${
                activePage === 'tours'
                  ? 'text-farm-green-800 font-bold border-b-2 border-farm-green-800'
                  : 'hover:text-farm-green-700'
              }`}
            >
              Visit & Tours
            </button>
          </nav>

          {/* Zone 3: Member Portal + 1 Primary CTA + Cart Bag trigger */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {/* Member Portal / Sign In Trigger */}
            <button
              type="button"
              onClick={() => handleLinkClick('login')}
              aria-label="Member portal sign in"
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                activePage === 'login'
                  ? 'bg-farm-green-100 text-farm-green-900 border border-farm-green-300'
                  : 'text-earth-800 hover:text-farm-green-800 hover:bg-earth-100'
              }`}
            >
              <User className="w-4 h-4 text-farm-green-800" />
              <span className="hidden sm:inline font-medium">
                {userName ? userName.split(' ')[0] : 'Sign In'}
              </span>
            </button>

            <button
              onClick={onOpenCart}
              aria-label={`Open harvest basket with ${cartCount} items`}
              className="relative p-2.5 rounded-lg text-earth-800 hover:text-farm-green-800 hover:bg-earth-100 transition-all flex items-center justify-center cursor-pointer"
            >
              <ShoppingBag className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-terracotta-600 text-white text-[11px] font-semibold w-5 h-5 rounded-full flex items-center justify-center tabular-nums shadow-xs">
                  {cartCount}
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={() => handleLinkClick('market')}
              className="hidden sm:inline-flex items-center px-4 py-2 text-xs font-semibold text-white bg-farm-green-800 hover:bg-farm-green-900 border border-farm-green-700 rounded-lg shadow-xs hover:shadow-sm transition-all whitespace-nowrap shrink-0 cursor-pointer"
            >
              Join Farm Share
            </button>

            {/* Mobile Hamburger toggle */}
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-expanded={mobileMenuOpen}
              aria-label="Toggle navigation menu"
              className="lg:hidden p-2 text-earth-700 hover:text-earth-900 hover:bg-earth-100 rounded-lg transition-colors cursor-pointer"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Slide-down Navigation with Seasons */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-white border-b border-earth-200 px-6 py-6 space-y-4 animate-in slide-in-from-top duration-200 shadow-md">
            <nav className="flex flex-col space-y-2 text-base font-medium text-earth-800">
              <button
                type="button"
                onClick={() => handleLinkClick('home')}
                className={`py-2 text-left border-b border-earth-100 cursor-pointer ${
                  activePage === 'home' ? 'text-farm-green-800 font-bold' : 'hover:text-farm-green-800'
                }`}
              >
                Home
              </button>
              <button
                type="button"
                onClick={() => handleLinkClick('about')}
                className={`py-2 text-left border-b border-earth-100 cursor-pointer ${
                  activePage === 'about' ? 'text-farm-green-800 font-bold' : 'hover:text-farm-green-800'
                }`}
              >
                About & Living Soil
              </button>
              <button
                type="button"
                onClick={() => handleLinkClick('market')}
                className={`py-2 text-left border-b border-earth-100 cursor-pointer ${
                  activePage === 'market' ? 'text-farm-green-800 font-bold' : 'hover:text-farm-green-800'
                }`}
              >
                Harvest Market & CSA Boxes
              </button>

              {/* Dedicated Seasonal Links in Mobile Nav */}
              <div className="py-2 border-b border-earth-100 space-y-1.5">
                <p className="text-xs font-semibold text-terracotta-700 uppercase tracking-wider">
                  The Four Seasons Pages
                </p>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <button
                    type="button"
                    onClick={() => handleLinkClick('spring')}
                    className={`p-2 rounded-lg text-left flex items-center gap-1.5 cursor-pointer ${
                      activePage === 'spring' ? 'bg-farm-green-800 text-white font-bold' : 'bg-earth-50 text-earth-800'
                    }`}
                  >
                    <Leaf className="w-3.5 h-3.5" />
                    <span>Spring</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleLinkClick('summer')}
                    className={`p-2 rounded-lg text-left flex items-center gap-1.5 cursor-pointer ${
                      activePage === 'summer' ? 'bg-farm-green-800 text-white font-bold' : 'bg-earth-50 text-earth-800'
                    }`}
                  >
                    <Sun className="w-3.5 h-3.5" />
                    <span>Summer</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleLinkClick('autumn')}
                    className={`p-2 rounded-lg text-left flex items-center gap-1.5 cursor-pointer ${
                      activePage === 'autumn' ? 'bg-farm-green-800 text-white font-bold' : 'bg-earth-50 text-earth-800'
                    }`}
                  >
                    <CloudRain className="w-3.5 h-3.5" />
                    <span>Autumn</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleLinkClick('winter')}
                    className={`p-2 rounded-lg text-left flex items-center gap-1.5 cursor-pointer ${
                      activePage === 'winter' ? 'bg-farm-green-800 text-white font-bold' : 'bg-earth-50 text-earth-800'
                    }`}
                  >
                    <Snowflake className="w-3.5 h-3.5" />
                    <span>Winter</span>
                  </button>
                </div>
              </div>

              {/* Dedicated Farm Standards Links in Mobile Nav */}
              <div className="py-2 border-b border-earth-100 space-y-1.5">
                <p className="text-xs font-semibold text-farm-green-800 uppercase tracking-wider">
                  Our 4 Farm Standards
                </p>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <button
                    type="button"
                    onClick={() => handleLinkClick('acres')}
                    className={`p-2 rounded-lg text-left cursor-pointer ${
                      activePage === 'acres' ? 'bg-farm-green-800 text-white font-bold' : 'bg-earth-50 text-earth-800'
                    }`}
                  >
                    180+ Acres
                  </button>
                  <button
                    type="button"
                    onClick={() => handleLinkClick('varieties')}
                    className={`p-2 rounded-lg text-left cursor-pointer ${
                      activePage === 'varieties' ? 'bg-farm-green-800 text-white font-bold' : 'bg-earth-50 text-earth-800'
                    }`}
                  >
                    42 Varieties
                  </button>
                  <button
                    type="button"
                    onClick={() => handleLinkClick('synthetics')}
                    className={`p-2 rounded-lg text-left cursor-pointer ${
                      activePage === 'synthetics' ? 'bg-farm-green-800 text-white font-bold' : 'bg-earth-50 text-earth-800'
                    }`}
                  >
                    0% Synthetics
                  </button>
                  <button
                    type="button"
                    onClick={() => handleLinkClick('freshness')}
                    className={`p-2 rounded-lg text-left cursor-pointer ${
                      activePage === 'freshness' ? 'bg-farm-green-800 text-white font-bold' : 'bg-earth-50 text-earth-800'
                    }`}
                  >
                    &lt; 24 Hours
                  </button>
                </div>
              </div>

              {/* Dedicated Produce Guides in Mobile Nav */}
              <div className="py-2 border-b border-earth-100 space-y-1.5">
                <p className="text-xs font-semibold text-farm-green-800 uppercase tracking-wider">
                  Produce Guides & Science
                </p>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <button
                    type="button"
                    onClick={() => handleLinkClick('vegetables')}
                    className={`p-2 rounded-lg text-left flex items-center gap-1.5 cursor-pointer ${
                      activePage === 'vegetables' ? 'bg-farm-green-800 text-white font-bold' : 'bg-earth-50 text-earth-800'
                    }`}
                  >
                    <Sprout className="w-3.5 h-3.5 text-farm-green-600" />
                    <span>Vegetables</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleLinkClick('fruits')}
                    className={`p-2 rounded-lg text-left flex items-center gap-1.5 cursor-pointer ${
                      activePage === 'fruits' ? 'bg-farm-green-800 text-white font-bold' : 'bg-earth-50 text-earth-800'
                    }`}
                  >
                    <Apple className="w-3.5 h-3.5 text-terracotta-600" />
                    <span>Fruits</span>
                  </button>
                </div>
              </div>

              <button
                type="button"
                onClick={() => handleLinkClick('tours')}
                className={`py-2 text-left cursor-pointer ${
                  activePage === 'tours' ? 'text-farm-green-800 font-bold' : 'hover:text-farm-green-800'
                }`}
              >
                Visit & Farm Tours
              </button>

              <button
                type="button"
                onClick={() => handleLinkClick('login')}
                className={`py-2 text-left flex items-center justify-between border-t border-earth-100 cursor-pointer ${
                  activePage === 'login' ? 'text-farm-green-800 font-bold' : 'text-earth-900'
                }`}
              >
                <span className="flex items-center gap-2">
                  <User className="w-4 h-4 text-farm-green-800" />
                  <span>{userName ? `Member: ${userName}` : 'Member Sign In / CSA Account'}</span>
                </span>
                <span className="text-xs text-farm-green-800 font-bold">&rarr;</span>
              </button>
            </nav>

            <div className="pt-2 flex flex-col gap-2.5">
              <button
                type="button"
                onClick={() => handleLinkClick('market')}
                className="w-full text-center px-4 py-3 text-sm font-semibold text-white bg-farm-green-800 hover:bg-farm-green-900 rounded-lg transition-colors cursor-pointer"
              >
                Order Harvest Box
              </button>
            </div>
          </div>
        )}
      </header>
    </>
  );
};
