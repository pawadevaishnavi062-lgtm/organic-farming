import React, { useState, useEffect, useRef } from 'react';
import { ChevronLeft, ChevronRight, Quote, ShieldCheck, HeartHandshake, Sparkles } from 'lucide-react';

export interface TestimonialItem {
  id: string;
  name: string;
  role: string;
  location: string;
  boxType: string;
  tenure: string;
  quote: string;
  highlight: string;
  impactMetric: string;
}

export const TESTIMONIALS_DATA: TestimonialItem[] = [
  {
    id: 't-1',
    name: 'Elena Vance',
    role: 'Home Cook & Mother of Two',
    location: 'Riverdale Basin, OR',
    boxType: 'The Hearth Harvest Box',
    tenure: 'Member for 4 Years',
    quote:
      'Before joining Verdant Roots, we threw away half our supermarket produce within days. Now, our greens stay crisp in the crisper for two full weeks because they were in living soil 24 hours before arriving on our porch. The rainbow carrots have actual sweet mineral flavor my kids love.',
    highlight: 'Greens stay crisp for 2 full weeks with real mineral depth',
    impactMetric: 'Saved ~180 lbs of produce waste annually',
  },
  {
    id: 't-2',
    name: 'Marcus & Priya Chen',
    role: 'Couples Farm Share Subscribers',
    location: 'South Hills, OR',
    boxType: 'The Field Sprout Box',
    tenure: 'Members since 2021',
    quote:
      'The seasonal rhythm of the Sprout Box completely changed our cooking habits. Roasting Chioggia candy cane beets and making pesto from the fresh carrot tops turned dinner into our favorite weekend ritual. Plus, receiving zero single-use plastic crates is huge for us.',
    highlight: 'Turned seasonal cooking into our favorite weekend ritual',
    impactMetric: '100% zero-plastic compostable packaging',
  },
  {
    id: 't-3',
    name: 'Chef Julian Moreau',
    role: 'Executive Chef, Hearth & Thyme',
    location: 'Portland Metro Area',
    boxType: 'The Heritage Feast Master Crate',
    tenure: 'Culinary Partner 5 Years',
    quote:
      'The brix sugar levels in Verdant Roots heirloom tomatoes and Tuscan kale are unmatched in our region. When diners taste our roast heritage carrots, they invariably ask where we source them. Their dedication to living mycorrhizal biology shines through on every plate.',
    highlight: 'Unmatched brix sugar levels and soil-born terroir',
    impactMetric: '8 seasonal menu features annually',
  },
  {
    id: 't-4',
    name: 'Sarah & David Lindqvist',
    role: 'Family CSA & Farm Tour Attendees',
    location: 'Clover Valley, OR',
    boxType: 'The Hearth Box + Raw Apiary Honey',
    tenure: 'Members for 3 Years',
    quote:
      'Walking the fields on the Saturday morning tour and holding the living earthworm compost in our hands connected our kids to their food like nothing else. Our weekly delivery feels like a personal gift from farmers who genuinely care about our planetary future.',
    highlight: 'Direct connection between our family and the growers',
    impactMetric: 'Zero chemical pesticides in household diet',
  },
];

interface CustomerTestimonialsProps {
  title?: string;
  subtitle?: string;
}

export const CustomerTestimonials: React.FC<CustomerTestimonialsProps> = ({
  title = 'Trusted by Eaters, Families & Chefs',
  subtitle = 'Real stories from community members whose tables are nourished by our weekly living soil harvest.',
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const current = TESTIMONIALS_DATA[currentIndex];

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % TESTIMONIALS_DATA.length);
  };

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + TESTIMONIALS_DATA.length) % TESTIMONIALS_DATA.length);
  };

  // Auto-advance carousel every 6 seconds unless paused by user hover
  useEffect(() => {
    if (!isPaused) {
      timerRef.current = setInterval(() => {
        handleNext();
      }, 6500);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPaused, currentIndex]);

  return (
    <section
      aria-label="Customer Testimonials Carousel"
      className="py-20 lg:py-24 bg-earth-50 border-b border-earth-200 relative overflow-hidden"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-6">
          <div className="max-w-2xl space-y-2">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-farm-green-800">
              <HeartHandshake className="w-4 h-4 text-terracotta-700" />
              <span>Community Proof & Voices</span>
              <span aria-hidden="true" className="text-earth-300">·</span>
              <span className="text-terracotta-700">Verified CSA Subscribers</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl font-bold text-earth-900 tracking-tight">
              {title}
            </h2>
            <p className="text-sm sm:text-base text-earth-700 font-normal">
              {subtitle}
            </p>
          </div>

          {/* Navigation Controls */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={handlePrev}
              aria-label="Previous subscriber testimonial"
              className="p-2.5 rounded-xl border border-earth-300 bg-white hover:bg-earth-100 text-earth-800 hover:text-farm-green-800 transition-all shadow-2xs cursor-pointer"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <div className="text-xs font-serif font-bold text-earth-700 tabular-nums px-1">
              0{currentIndex + 1} / 0{TESTIMONIALS_DATA.length}
            </div>
            <button
              type="button"
              onClick={handleNext}
              aria-label="Next subscriber testimonial"
              className="p-2.5 rounded-xl border border-earth-300 bg-white hover:bg-earth-100 text-earth-800 hover:text-farm-green-800 transition-all shadow-2xs cursor-pointer"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Carousel Slide Card in Crisp White & Earth Styling */}
        <div className="bg-white rounded-3xl border border-earth-200 p-8 sm:p-12 lg:p-14 shadow-xs relative transition-all duration-300">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
            {/* Quote Icon & Body (8 cols) */}
            <div className="lg:col-span-8 space-y-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-farm-green-100 text-farm-green-800 flex items-center justify-center">
                  <Quote className="w-5 h-5" />
                </div>
                <div className="text-xs font-semibold text-terracotta-700 uppercase tracking-wider">
                  {current.highlight}
                </div>
              </div>

              {/* Main Testimonial Statement */}
              <blockquote className="font-serif text-xl sm:text-2xl lg:text-3xl font-medium text-earth-900 leading-snug">
                "{current.quote}"
              </blockquote>

              {/* Attributable Author Lockup */}
              <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-t border-earth-100">
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <p className="font-serif text-lg font-bold text-earth-900">
                      {current.name}
                    </p>
                    <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-farm-green-800 bg-farm-green-50 px-2 py-0.5 rounded-md border border-farm-green-200">
                      <ShieldCheck className="w-3 h-3 text-farm-green-700" />
                      Verified CSA Shareholder
                    </span>
                  </div>
                  <p className="text-xs text-earth-600">
                    {current.role} · {current.location}
                  </p>
                </div>

                <div className="text-xs text-earth-500 sm:text-right">
                  <p className="font-semibold text-earth-800">{current.boxType}</p>
                  <p className="text-[11px]">{current.tenure}</p>
                </div>
              </div>
            </div>

            {/* Impact & Trust Card Sidecar (4 cols) */}
            <div className="lg:col-span-4 p-6 rounded-2xl bg-earth-50 border border-earth-200/90 space-y-5 flex flex-col justify-between">
              <div className="space-y-3">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-farm-green-800 uppercase tracking-wider">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Household Return</span>
                </div>
                <p className="font-serif text-lg font-bold text-earth-900">
                  {current.impactMetric}
                </p>
                <p className="text-xs text-earth-600 leading-relaxed font-normal">
                  Each week our subscribers receive direct soil-to-table harvests with zero wholesale storage lag.
                </p>
              </div>

              <div className="pt-4 border-t border-earth-200 text-xs text-earth-500 flex items-center justify-between">
                <span>Active CSA Membership</span>
                <span className="font-semibold text-farm-green-800">100% Certified Organic</span>
              </div>
            </div>
          </div>
        </div>

        {/* Carousel Stepper Dots / Selectors */}
        <div className="flex items-center justify-center gap-2 pt-2">
          {TESTIMONIALS_DATA.map((t, idx) => {
            const isActive = currentIndex === idx;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => setCurrentIndex(idx)}
                aria-label={`Go to testimonial ${idx + 1} from ${t.name}`}
                className={`transition-all rounded-full cursor-pointer ${
                  isActive
                    ? 'w-8 h-2.5 bg-farm-green-800'
                    : 'w-2.5 h-2.5 bg-earth-300 hover:bg-earth-400'
                }`}
              />
            );
          })}
        </div>
      </div>
    </section>
  );
};
