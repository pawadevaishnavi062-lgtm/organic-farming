import React, { useState } from 'react';
import { CartItem } from '../types/farm';
import { X, Trash2, Plus, Minus, ShoppingBag, Truck, Store, CheckCircle } from 'lucide-react';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
}) => {
  const [deliveryMethod, setDeliveryMethod] = useState<'delivery' | 'pickup'>('delivery');
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [checkoutComplete, setCheckoutComplete] = useState<{
    orderId: string;
    deliveryDate: string;
    total: number;
    name: string;
    address: string;
  } | null>(null);

  // Form states for checkout
  const [customerName, setCustomerName] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [deliveryNotes, setDeliveryNotes] = useState('');
  const [formErrors, setFormErrors] = useState<{ [key: string]: string }>({});

  const subtotal = items.reduce((acc, curr) => acc + curr.product.price * curr.quantity, 0);
  const deliveryFee = deliveryMethod === 'delivery' ? (subtotal >= 50 || subtotal === 0 ? 0 : 4.5) : 0;
  const orderTotal = subtotal + deliveryFee;

  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const errors: { [key: string]: string } = {};
    if (!customerName.trim()) errors.name = 'Full name is required.';
    if (deliveryMethod === 'delivery' && !customerAddress.trim()) {
      errors.address = 'Street address is required for doorstep delivery.';
    }
    if (!customerPhone.trim()) errors.phone = 'Phone number is needed for delivery dispatch.';

    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      return;
    }

    const orderId = `VRO-${Math.floor(10000 + Math.random() * 90000)}`;
    setCheckoutComplete({
      orderId,
      deliveryDate: 'This Friday (Between 8:00 AM – 1:00 PM)',
      total: orderTotal,
      name: customerName,
      address: deliveryMethod === 'delivery' ? customerAddress : 'Verdant Roots Farmstand (Self Pickup)',
    });
    onClearCart();
    setIsCheckingOut(false);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop in Deep Loam Earth */}
      <div
        className="absolute inset-0 bg-earth-950/55 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col justify-between border-l border-earth-200">
          {/* Cart Header in Crisp White */}
          <div className="px-6 py-5 border-b border-earth-200 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <ShoppingBag className="w-5 h-5 text-farm-green-800" />
              <h2 className="font-serif text-xl font-bold text-earth-900">
                Your Harvest Basket
              </h2>
            </div>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-earth-400 hover:text-earth-700 rounded-lg hover:bg-earth-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Cart Body */}
          <div className="flex-1 overflow-y-auto px-6 py-6 space-y-6">
            {items.length === 0 ? (
              <div className="text-center py-16 space-y-4">
                <div className="w-16 h-16 rounded-full bg-earth-100 flex items-center justify-center text-earth-400 mx-auto">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <h3 className="font-serif text-lg font-bold text-earth-900">Your basket is empty</h3>
                <p className="text-xs text-earth-600 max-w-xs mx-auto">
                  Add seasonal organic produce, heirloom greens, or our weekly harvest share box.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    const el = document.getElementById('harvest-market');
                    if (el) el.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="px-5 py-2.5 text-xs font-semibold text-white bg-farm-green-800 hover:bg-farm-green-900 rounded-lg transition-colors inline-block"
                >
                  Explore Harvest Catalog
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {items.map(({ product, quantity }) => (
                  <div
                    key={product.id}
                    className="p-4 rounded-xl border border-earth-200 bg-earth-50/70 flex items-start justify-between gap-3 shadow-2xs"
                  >
                    <div className="space-y-1 flex-1">
                      <h4 className="font-serif text-sm font-bold text-earth-900">
                        {product.name}
                      </h4>
                      <p className="text-[11px] text-earth-500">
                        {product.unit} · ${product.price.toFixed(2)}
                      </p>
                      <p className="text-xs font-medium text-farm-green-800 tabular-nums">
                        ${(product.price * quantity).toFixed(2)}
                      </p>
                    </div>

                    <div className="flex flex-col items-end gap-2">
                      <div className="flex items-center gap-1.5 bg-white border border-earth-200 rounded-lg p-0.5 shadow-2xs">
                        <button
                          type="button"
                          onClick={() => onUpdateQuantity(product.id, quantity - 1)}
                          className="p-1 text-earth-600 hover:text-earth-900 transition-colors"
                          aria-label="Decrease quantity"
                        >
                          <Minus className="w-3.5 h-3.5" />
                        </button>
                        <span className="text-xs font-semibold w-6 text-center tabular-nums text-earth-900">
                          {quantity}
                        </span>
                        <button
                          type="button"
                          onClick={() => onUpdateQuantity(product.id, quantity + 1)}
                          className="p-1 text-earth-600 hover:text-earth-900 transition-colors"
                          aria-label="Increase quantity"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <button
                        type="button"
                        onClick={() => onRemoveItem(product.id)}
                        className="text-earth-400 hover:text-terracotta-700 transition-colors p-1"
                        aria-label="Remove item"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}

                {/* Delivery Preference */}
                <div className="pt-4 border-t border-earth-200 space-y-3">
                  <span className="text-xs font-semibold text-earth-800">Fulfillment Method</span>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setDeliveryMethod('delivery')}
                      className={`p-2.5 rounded-lg border text-left flex items-start gap-2 transition-all ${
                        deliveryMethod === 'delivery'
                          ? 'border-farm-green-800 bg-farm-green-50 text-farm-green-950 shadow-xs'
                          : 'border-earth-200 bg-white text-earth-700 hover:bg-earth-50'
                      }`}
                    >
                      <Truck className="w-4 h-4 text-farm-green-800 shrink-0 mt-0.5" />
                      <div>
                        <p className="text-xs font-semibold">Electric Van</p>
                        <p className="text-[10px] text-earth-600">
                          {subtotal >= 50 ? 'Free (over $50)' : '$4.50 fee'}
                        </p>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setDeliveryMethod('pickup')}
                      className={`p-2.5 rounded-lg border text-left flex items-start gap-2 transition-all ${
                        deliveryMethod === 'pickup'
                          ? 'border-farm-green-800 bg-farm-green-50 text-farm-green-950 shadow-xs'
                          : 'border-earth-200 bg-white text-earth-700 hover:bg-earth-50'
                      }`}
                    >
                      <Store className="w-4 h-4 text-farm-green-800 shrink-0 mt-0.5" />
                      <div>
                        <p className="text-xs font-semibold">Farm Stand</p>
                        <p className="text-[10px] text-earth-600">Free pickup</p>
                      </div>
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Cart Footer */}
          {items.length > 0 && (
            <div className="px-6 py-5 border-t border-earth-200 bg-earth-50 space-y-3">
              <div className="space-y-1.5 text-xs text-earth-700">
                <div className="flex justify-between">
                  <span>Harvest Subtotal</span>
                  <span className="font-serif font-bold text-earth-900 tabular-nums">
                    ${subtotal.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Fulfillment ({deliveryMethod === 'delivery' ? 'Local Delivery' : 'Pickup'})</span>
                  <span className="font-serif font-bold text-earth-900 tabular-nums">
                    {deliveryFee === 0 ? 'Free' : `$${deliveryFee.toFixed(2)}`}
                  </span>
                </div>
                <div className="flex justify-between text-earth-900 text-sm font-bold pt-2 border-t border-earth-200">
                  <span>Total Due</span>
                  <span className="font-serif text-lg text-farm-green-800 tabular-nums">
                    ${orderTotal.toFixed(2)}
                  </span>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsCheckingOut(true)}
                className="w-full py-3 text-xs font-semibold text-white bg-farm-green-800 hover:bg-farm-green-900 rounded-lg shadow-xs hover:shadow-sm transition-all text-center"
              >
                Proceed to Farm Checkout
              </button>
              <p className="text-[11px] text-earth-600 text-center">
                100% Compostable Boxes · Zero Plastic Waste
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Checkout Modal in Crisp White with Earth Frame */}
      {isCheckingOut && (
        <div
          className="fixed inset-0 z-60 bg-earth-950/65 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={() => setIsCheckingOut(false)}
        >
          <div
            className="bg-white rounded-2xl max-w-lg w-full p-6 sm:p-8 space-y-6 shadow-2xl border border-earth-200 animate-in fade-in zoom-in-95 duration-150 max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between border-b border-earth-200 pb-4">
              <div>
                <h3 className="font-serif text-2xl font-bold text-earth-900">
                  Complete Farm Order
                </h3>
                <p className="text-xs text-earth-600 mt-0.5">
                  Harvested fresh on the morning of dispatch.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsCheckingOut(false)}
                className="p-1.5 text-earth-400 hover:text-earth-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCheckoutSubmit} className="space-y-4 text-xs">
              <div className="space-y-1.5">
                <label htmlFor="checkout-name" className="font-semibold text-earth-800">Full Name</label>
                <input
                  id="checkout-name"
                  type="text"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="e.g. Clara Thorne"
                  className="w-full px-3 py-2 rounded-lg border border-earth-200 bg-earth-50 focus:bg-white focus:outline-hidden focus:border-farm-green-700 text-earth-900 placeholder-earth-400 shadow-2xs"
                />
                {formErrors.name && <p className="text-terracotta-700">{formErrors.name}</p>}
              </div>

              {deliveryMethod === 'delivery' && (
                <div className="space-y-1.5">
                  <label htmlFor="checkout-address" className="font-semibold text-earth-800">Doorstep Delivery Address</label>
                  <input
                    id="checkout-address"
                    type="text"
                    value={customerAddress}
                    onChange={(e) => setCustomerAddress(e.target.value)}
                    placeholder="124 Orchard Lane, Apt 2B"
                    className="w-full px-3 py-2 rounded-lg border border-earth-200 bg-earth-50 focus:bg-white focus:outline-hidden focus:border-farm-green-700 text-earth-900 placeholder-earth-400 shadow-2xs"
                  />
                  {formErrors.address && <p className="text-terracotta-700">{formErrors.address}</p>}
                </div>
              )}

              <div className="space-y-1.5">
                <label htmlFor="checkout-phone" className="font-semibold text-earth-800">Phone for SMS Delivery Alert</label>
                <input
                  id="checkout-phone"
                  type="tel"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  placeholder="(555) 349-8120"
                  className="w-full px-3 py-2 rounded-lg border border-earth-200 bg-earth-50 focus:bg-white focus:outline-hidden focus:border-farm-green-700 text-earth-900 placeholder-earth-400 shadow-2xs"
                />
                {formErrors.phone && <p className="text-terracotta-700">{formErrors.phone}</p>}
              </div>

              <div className="space-y-1.5">
                <label htmlFor="checkout-notes" className="font-semibold text-earth-800">Delivery Instructions (Optional)</label>
                <textarea
                  id="checkout-notes"
                  rows={2}
                  value={deliveryNotes}
                  onChange={(e) => setDeliveryNotes(e.target.value)}
                  placeholder="Leave crate in cooler on north porch..."
                  className="w-full px-3 py-2 rounded-lg border border-earth-200 bg-earth-50 focus:bg-white focus:outline-hidden focus:border-farm-green-700 text-earth-900 placeholder-earth-400 resize-none shadow-2xs"
                />
              </div>

              <div className="p-3.5 bg-earth-50 rounded-xl border border-earth-200 flex items-center justify-between font-medium">
                <span className="text-earth-800">Final Order Total (Payment upon arrival):</span>
                <span className="font-serif text-base font-bold text-farm-green-800 tabular-nums">
                  ${orderTotal.toFixed(2)}
                </span>
              </div>

              <button
                type="submit"
                className="w-full py-3 text-xs font-semibold text-white bg-farm-green-800 hover:bg-farm-green-900 rounded-lg shadow-xs hover:shadow-sm transition-all"
              >
                Confirm Farm Harvest Order
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Checkout Receipt Confirmation Modal */}
      {checkoutComplete && (
        <div
          className="fixed inset-0 z-70 bg-earth-950/65 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={() => {
            setCheckoutComplete(null);
            onClose();
          }}
        >
          <div
            className="bg-white rounded-2xl max-w-md w-full p-6 sm:p-8 space-y-6 shadow-2xl border border-earth-200 text-center animate-in fade-in zoom-in-95 duration-150"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-14 h-14 rounded-full bg-farm-green-100 text-farm-green-800 mx-auto flex items-center justify-center">
              <CheckCircle className="w-8 h-8" />
            </div>

            <div className="space-y-2">
              <h3 className="font-serif text-2xl font-bold text-earth-900">
                Harvest Order Scheduled!
              </h3>
              <p className="text-xs text-earth-600">
                Thank you, <span className="font-semibold text-earth-900">{checkoutComplete.name}</span>.
                Your produce will be hand-harvested at dawn and packed in certified compostable crates.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-earth-50 border border-earth-200 text-left text-xs space-y-2">
              <div className="flex justify-between pb-1.5 border-b border-earth-200">
                <span className="text-earth-500">Order Reference</span>
                <span className="font-mono font-bold text-terracotta-700">
                  {checkoutComplete.orderId}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-earth-500">Delivery Window</span>
                <span className="font-medium text-earth-900">{checkoutComplete.deliveryDate}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-earth-500">Destination</span>
                <span className="font-medium text-earth-900 truncate max-w-[200px]">
                  {checkoutComplete.address}
                </span>
              </div>
              <div className="flex justify-between pt-1.5 border-t border-earth-200 font-bold">
                <span className="text-earth-700">Total</span>
                <span className="font-serif text-farm-green-800 tabular-nums">
                  ${checkoutComplete.total.toFixed(2)}
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                setCheckoutComplete(null);
                onClose();
              }}
              className="w-full py-2.5 text-xs font-semibold text-white bg-farm-green-800 hover:bg-farm-green-900 rounded-lg transition-colors"
            >
              Continue Browsing Farmstead
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
