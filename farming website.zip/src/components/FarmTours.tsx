import React, { useState } from 'react';
import { FARM_TOURS, FARM_IMAGES } from '../data/farmData';
import { FarmTour } from '../types/farm';
import { Calendar, Clock, CheckCircle2 } from 'lucide-react';

export const FarmTours: React.FC = () => {
  const [selectedTour, setSelectedTour] = useState<FarmTour>(FARM_TOURS[0]);
  const [guestCount, setGuestCount] = useState<number>(2);
  const [visitDate, setVisitDate] = useState<string>('2026-11-14');
  const [visitorName, setVisitorName] = useState<string>('');
  const [visitorEmail, setVisitorEmail] = useState<string>('');
  const [visitorPhone, setVisitorPhone] = useState<string>('');
  const [accessibilityNotes, setAccessibilityNotes] = useState<string>('');
  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  const [confirmationData, setConfirmationData] = useState<{
    bookingRef: string;
    tourTitle: string;
    guests: number;
    date: string;
    total: number;
    name: string;
  } | null>(null);

  const validateForm = () => {
    const errs: { [key: string]: string } = {};
    if (!visitorName.trim()) errs.name = 'Please provide your full name.';
    if (!visitorEmail.trim() || !visitorEmail.includes('@')) errs.email = 'Valid email is required.';
    if (!visitorPhone.trim()) errs.phone = 'Phone number is required for field weather alerts.';
    if (!visitDate) errs.date = 'Please pick a date for your tour.';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmitBooking = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    const total = selectedTour.pricePerPerson * guestCount;
    const ref = `VR-${Math.floor(1000 + Math.random() * 9000)}`;
    setConfirmationData({
      bookingRef: ref,
      tourTitle: selectedTour.title,
      guests: guestCount,
      date: visitDate,
      total,
      name: visitorName,
    });
  };

  return (
    <section id="farm-tours" className="py-20 lg:py-28 bg-earth-50 border-b border-earth-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Header */}
        <div className="max-w-3xl space-y-3">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-farm-green-800">
            <span>Community Immersion</span>
            <span aria-hidden="true" className="text-earth-400">·</span>
            <span className="text-terracotta-700">Farmgate Hospitality</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-earth-900 tracking-tight">
            Walk the Fields with the Growers.
          </h2>
          <p className="text-base text-earth-700 leading-relaxed font-normal">
            We believe agricultural transparency means open gates. Come touch living earth compost,
            taste sun-warmed heirloom fruit straight off the branch, and meet the farmers stewarding your food.
          </p>
        </div>

        {/* 2-Column Layout: Tours Showcase & Booking Module */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          {/* Left Column: Visual & Tour Cards */}
          <div className="lg:col-span-7 space-y-6">
            <div className="relative rounded-2xl overflow-hidden border border-earth-200 shadow-xs h-72 sm:h-80 bg-white">
              <img
                src={FARM_IMAGES.orchardTour}
                alt="Sunlit organic orchard with wildflower pollinator meadows between trees and rustic wooden gate"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-earth-950/85 via-earth-950/30 to-transparent flex items-end p-6">
                <div className="text-white">
                  <p className="text-xs font-semibold text-farm-green-200 uppercase tracking-wider">
                    Orchard Sanctuary & Honeybee Apiary
                  </p>
                  <p className="font-serif text-lg font-bold text-white mt-1">
                    15 acres of heritage plums, apples, and continuous bee forage.
                  </p>
                </div>
              </div>
            </div>

            {/* Tour Selection Cards */}
            <div className="space-y-4">
              {FARM_TOURS.map((tour) => {
                const isSelected = selectedTour.id === tour.id;
                return (
                  <div
                    key={tour.id}
                    onClick={() => setSelectedTour(tour)}
                    className={`cursor-pointer p-5 rounded-xl border transition-all text-left ${
                      isSelected
                        ? 'bg-white border-farm-green-700/80 shadow-xs ring-1 ring-farm-green-700/20'
                        : 'bg-white/80 border-earth-200 hover:bg-white hover:border-earth-300'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <h3 className="font-serif text-lg font-bold text-earth-900">
                        {tour.title}
                      </h3>
                      <div className="font-serif text-lg font-bold text-terracotta-700 tabular-nums shrink-0">
                        ${tour.pricePerPerson}{' '}
                        <span className="text-xs text-earth-500 font-sans font-normal">/ guest</span>
                      </div>
                    </div>

                    <p className="text-xs text-earth-700 mt-2 font-normal leading-relaxed">
                      {tour.description}
                    </p>

                    <div className="mt-4 pt-3 border-t border-earth-100 flex flex-wrap items-center gap-y-2 gap-x-4 text-xs text-earth-600">
                      <span className="flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-farm-green-800" />
                        {tour.duration}
                      </span>
                      <span aria-hidden="true" className="text-earth-300">·</span>
                      <span className="flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5 text-farm-green-800" />
                        {tour.schedule}
                      </span>
                      <span aria-hidden="true" className="text-earth-300">·</span>
                      <span className="text-farm-green-800 font-medium">{tour.spotsLeft} spots open</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right Column: Interactive Reservation Form in Crisp White */}
          <div className="lg:col-span-5 bg-white rounded-2xl border border-earth-200 p-6 sm:p-8 shadow-xs space-y-6">
            <div className="border-b border-earth-200 pb-4">
              <h3 className="font-serif text-2xl font-bold text-earth-900">
                Reserve Your Field Pass
              </h3>
              <p className="text-xs text-earth-600 mt-1">
                Selected: <span className="font-semibold text-earth-900">{selectedTour.title}</span>
              </p>
            </div>

            <form onSubmit={handleSubmitBooking} className="space-y-4">
              {/* Tour Date & Guests */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label htmlFor="tour-date" className="text-xs font-semibold text-earth-800">Date</label>
                  <input
                    id="tour-date"
                    type="date"
                    value={visitDate}
                    onChange={(e) => setVisitDate(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-earth-200 bg-earth-50 focus:bg-white focus:outline-hidden focus:border-farm-green-700 text-earth-900 shadow-2xs"
                  />
                  {errors.date && <p className="text-[11px] text-terracotta-700">{errors.date}</p>}
                </div>

                <div className="space-y-1.5">
                  <label htmlFor="guest-count" className="text-xs font-semibold text-earth-800">Guests</label>
                  <select
                    id="guest-count"
                    value={guestCount}
                    onChange={(e) => setGuestCount(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-earth-200 bg-earth-50 focus:bg-white focus:outline-hidden focus:border-farm-green-700 text-earth-900 shadow-2xs"
                  >
                    {[1, 2, 3, 4, 5, 6, 8, 10].map((num) => (
                      <option key={num} value={num}>
                        {num} {num === 1 ? 'Guest' : 'Guests'}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Contact Information */}
              <div className="space-y-1.5">
                <label htmlFor="visitor-name" className="text-xs font-semibold text-earth-800">Full Name</label>
                <input
                  id="visitor-name"
                  type="text"
                  value={visitorName}
                  onChange={(e) => setVisitorName(e.target.value)}
                  placeholder="e.g. Eleanor Vance"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-earth-200 bg-earth-50 focus:bg-white focus:outline-hidden focus:border-farm-green-700 text-earth-900 placeholder-earth-400 shadow-2xs"
                />
                {errors.name && <p className="text-[11px] text-terracotta-700">{errors.name}</p>}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label htmlFor="visitor-email" className="text-xs font-semibold text-earth-800">Email Address</label>
                  <input
                    id="visitor-email"
                    type="email"
                    value={visitorEmail}
                    onChange={(e) => setVisitorEmail(e.target.value)}
                    placeholder="name@example.com"
                    className="w-full px-3 py-2 text-xs rounded-lg border border-earth-200 bg-earth-50 focus:bg-white focus:outline-hidden focus:border-farm-green-700 text-earth-900 placeholder-earth-400 shadow-2xs"
                  />
                  {errors.email && <p className="text-[11px] text-terracotta-700">{errors.email}</p>}
                </div>

                <div className="space-y-1.5">
                  <label htmlFor="visitor-phone" className="text-xs font-semibold text-earth-800">Phone</label>
                  <input
                    id="visitor-phone"
                    type="tel"
                    value={visitorPhone}
                    onChange={(e) => setVisitorPhone(e.target.value)}
                    placeholder="(555) 019-2834"
                    className="w-full px-3 py-2 text-xs rounded-lg border border-earth-200 bg-earth-50 focus:bg-white focus:outline-hidden focus:border-farm-green-700 text-earth-900 placeholder-earth-400 shadow-2xs"
                  />
                  {errors.phone && <p className="text-[11px] text-terracotta-700">{errors.phone}</p>}
                </div>
              </div>

              <div className="space-y-1.5">
                <label htmlFor="accessibility-notes" className="text-xs font-semibold text-earth-800">
                  Dietary / Accessibility Notes (Optional)
                </label>
                <textarea
                  id="accessibility-notes"
                  rows={2}
                  value={accessibilityNotes}
                  onChange={(e) => setAccessibilityNotes(e.target.value)}
                  placeholder="Gluten sensitivity, walking support, children in stroller..."
                  className="w-full px-3 py-2 text-xs rounded-lg border border-earth-200 bg-earth-50 focus:bg-white focus:outline-hidden focus:border-farm-green-700 text-earth-900 placeholder-earth-400 resize-none shadow-2xs"
                />
              </div>

              {/* Price Calculation Summary */}
              <div className="pt-3 border-t border-earth-100 flex items-center justify-between text-xs">
                <span className="text-earth-600">
                  {guestCount} x ${selectedTour.pricePerPerson}.00
                </span>
                <span className="font-serif text-lg font-bold text-earth-900 tabular-nums">
                  ${selectedTour.pricePerPerson * guestCount}.00
                </span>
              </div>

              <button
                type="submit"
                className="w-full py-3 px-4 text-xs font-semibold text-white bg-farm-green-800 hover:bg-farm-green-900 rounded-lg shadow-xs hover:shadow-sm transition-all whitespace-nowrap"
              >
                Confirm Tour Reservation
              </button>

              <p className="text-[11px] text-earth-500 text-center">
                Free cancellation up to 24 hours prior. Boots or walking shoes recommended.
              </p>
            </form>
          </div>
        </div>

        {/* Confirmation Modal in Crisp White & Earth Detailing */}
        {confirmationData && (
          <div
            className="fixed inset-0 z-50 bg-earth-950/65 backdrop-blur-xs flex items-center justify-center p-4"
            onClick={() => setConfirmationData(null)}
          >
            <div
              className="bg-white rounded-2xl max-w-md w-full p-6 sm:p-8 space-y-6 shadow-2xl border border-earth-200 animate-in fade-in zoom-in-95 duration-150"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="text-center space-y-3">
                <div className="w-12 h-12 rounded-full bg-farm-green-100 text-farm-green-800 mx-auto flex items-center justify-center">
                  <CheckCircle2 className="w-7 h-7" />
                </div>
                <h3 className="font-serif text-2xl font-bold text-earth-900">
                  Field Pass Confirmed!
                </h3>
                <p className="text-xs text-earth-600">
                  Thank you, <span className="font-semibold text-earth-900">{confirmationData.name}</span>.
                  Your reservation is recorded in the farm visitor registry.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-earth-50 border border-earth-200 space-y-2.5 text-xs">
                <div className="flex justify-between pb-2 border-b border-earth-200">
                  <span className="text-earth-500">Booking Reference</span>
                  <span className="font-mono font-bold text-terracotta-700">
                    {confirmationData.bookingRef}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-earth-500">Tour</span>
                  <span className="font-semibold text-earth-900 text-right max-w-[200px]">
                    {confirmationData.tourTitle}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-earth-500">Scheduled Date</span>
                  <span className="font-semibold text-earth-900">{confirmationData.date}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-earth-500">Party Size</span>
                  <span className="font-semibold text-earth-900">
                    {confirmationData.guests} {confirmationData.guests === 1 ? 'Guest' : 'Guests'}
                  </span>
                </div>
                <div className="flex justify-between pt-2 border-t border-earth-200 font-bold">
                  <span className="text-earth-700">Total (Paid at Gate)</span>
                  <span className="font-serif text-farm-green-800 tabular-nums">
                    ${confirmationData.total}.00
                  </span>
                </div>
              </div>

              <div className="text-xs text-earth-600 space-y-1">
                <p className="font-medium text-earth-900">Arrival Instructions:</p>
                <p>
                  Check in at the Cedar Barn Farmstand 15 minutes before tour start. Parking is free on the south gravel apron.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setConfirmationData(null)}
                className="w-full py-2.5 text-xs font-semibold text-white bg-farm-green-800 hover:bg-farm-green-900 rounded-lg transition-colors"
              >
                Close & Return to Farm Site
              </button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
