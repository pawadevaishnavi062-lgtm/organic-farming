import React, { useState } from 'react';
import { Leaf, Droplets, Wind, Flower2 } from 'lucide-react';

export const ImpactCalculator: React.FC = () => {
  const [householdMembers, setHouseholdMembers] = useState<number>(3);
  const [organicPercentage, setOrganicPercentage] = useState<number>(75);

  // Ecological coefficients based on regenerative organic vs chemical farming studies
  const annualPoundsProduce = householdMembers * 260 * (organicPercentage / 100);
  const syntheticPesticidesAvoidedOz = (annualPoundsProduce * 0.082).toFixed(1);
  const cleanWaterConservedGal = Math.round(annualPoundsProduce * 18.5);
  const carbonSequesteredLbs = Math.round(annualPoundsProduce * 1.4);
  const pollinatorHabitatSqFt = Math.round(householdMembers * 140 * (organicPercentage / 100));

  return (
    <section id="impact-calculator" className="py-20 lg:py-28 bg-white border-b border-earth-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Header */}
        <div className="max-w-3xl space-y-3">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-farm-green-800">
            <span>Environmental Footprint Simulator</span>
            <span aria-hidden="true" className="text-earth-300">·</span>
            <span className="text-terracotta-700">Regenerative Earth Impact</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-earth-900 tracking-tight">
            Calculate Your Family’s Ecological Return.
          </h2>
          <p className="text-base text-earth-700 leading-relaxed font-normal">
            Choosing organic farming is an active ecological intervention in the living earth. See the tangible
            gallons of aquifer water protected and atmospheric carbon drawn down into soil through your weekly table choices.
          </p>
        </div>

        {/* Interactive Controls & Output Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          {/* Controls Column in Earth Sand */}
          <div className="lg:col-span-5 bg-earth-50 rounded-2xl border border-earth-200 p-6 sm:p-8 space-y-6 shadow-xs">
            <h3 className="font-serif text-xl font-bold text-earth-900">
              Household Parameters
            </h3>

            {/* Slider 1: Household Size */}
            <div className="space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="font-medium text-earth-800">Household Size</span>
                <span className="font-serif font-bold text-farm-green-800 tabular-nums text-base">
                  {householdMembers} {householdMembers === 1 ? 'Person' : 'People'}
                </span>
              </div>
              <input
                type="range"
                min="1"
                max="8"
                step="1"
                value={householdMembers}
                onChange={(e) => setHouseholdMembers(Number(e.target.value))}
                className="w-full accent-farm-green-800 cursor-pointer"
              />
              <div className="flex justify-between text-[11px] text-earth-500">
                <span>1 solo</span>
                <span>4 family</span>
                <span>8+ community</span>
              </div>
            </div>

            {/* Slider 2: Organic Share Percentage */}
            <div className="space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="font-medium text-earth-800">Organic Produce Share</span>
                <span className="font-serif font-bold text-terracotta-700 tabular-nums text-base">
                  {organicPercentage}% of diet
                </span>
              </div>
              <div className="grid grid-cols-4 gap-2">
                {[25, 50, 75, 100].map((pct) => (
                  <button
                    key={pct}
                    type="button"
                    onClick={() => setOrganicPercentage(pct)}
                    className={`py-2 text-xs font-semibold rounded-lg border transition-all ${
                      organicPercentage === pct
                        ? 'bg-farm-green-800 text-white border-farm-green-800 shadow-xs'
                        : 'bg-white text-earth-700 border-earth-200 hover:border-earth-300'
                    }`}
                  >
                    {pct}%
                  </button>
                ))}
              </div>
            </div>

            <div className="pt-2 border-t border-earth-200 text-xs text-earth-600 leading-relaxed">
              Calculations based on verified USDA National Organic Program and Rodale Institute 40-year Farming Systems Trial metrics.
            </div>
          </div>

          {/* Outputs Column in Clean White Cards with Earth & Green Highlights */}
          <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-5">
            {/* Impact 1: Synthetic Chemicals Prevented */}
            <div className="p-6 rounded-2xl border border-earth-200 bg-white hover:border-farm-green-700/60 transition-all space-y-3 shadow-2xs">
              <div className="w-10 h-10 rounded-xl bg-farm-green-100 flex items-center justify-center text-farm-green-800">
                <Leaf className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs font-medium text-earth-500 uppercase tracking-wider">
                  Chemical Runoff Prevented
                </p>
                <p className="text-3xl font-serif font-bold text-earth-900 tabular-nums mt-1">
                  {syntheticPesticidesAvoidedOz} <span className="text-sm font-sans font-normal text-earth-600">oz/year</span>
                </p>
              </div>
              <p className="text-xs text-earth-600 font-normal leading-relaxed">
                Toxic synthetic pesticides, fungicides, and synthetic nitrates diverted from polluting groundwater aquifers.
              </p>
            </div>

            {/* Impact 2: Clean Water Conserved */}
            <div className="p-6 rounded-2xl border border-earth-200 bg-white hover:border-farm-green-700/60 transition-all space-y-3 shadow-2xs">
              <div className="w-10 h-10 rounded-xl bg-earth-100 flex items-center justify-center text-earth-800">
                <Droplets className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs font-medium text-earth-500 uppercase tracking-wider">
                  Aquifer Water Conserved
                </p>
                <p className="text-3xl font-serif font-bold text-earth-900 tabular-nums mt-1">
                  {cleanWaterConservedGal.toLocaleString()} <span className="text-sm font-sans font-normal text-earth-600">gallons</span>
                </p>
              </div>
              <p className="text-xs text-earth-600 font-normal leading-relaxed">
                Organic humus retains rainwater naturally like a sponge, reducing supplemental agricultural pumping.
              </p>
            </div>

            {/* Impact 3: Carbon Sequestered */}
            <div className="p-6 rounded-2xl border border-earth-200 bg-white hover:border-farm-green-700/60 transition-all space-y-3 shadow-2xs">
              <div className="w-10 h-10 rounded-xl bg-terracotta-100 flex items-center justify-center text-terracotta-700">
                <Wind className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs font-medium text-earth-500 uppercase tracking-wider">
                  Soil Carbon Sequestered
                </p>
                <p className="text-3xl font-serif font-bold text-earth-900 tabular-nums mt-1">
                  {carbonSequesteredLbs.toLocaleString()} <span className="text-sm font-sans font-normal text-earth-600">lbs CO2e</span>
                </p>
              </div>
              <p className="text-xs text-earth-600 font-normal leading-relaxed">
                Captured by photosynthesis and pumped deep into fungal root networks rather than escaping into the atmosphere.
              </p>
            </div>

            {/* Impact 4: Pollinator Sanctuary */}
            <div className="p-6 rounded-2xl border border-earth-200 bg-white hover:border-farm-green-700/60 transition-all space-y-3 shadow-2xs">
              <div className="w-10 h-10 rounded-xl bg-farm-green-100 flex items-center justify-center text-farm-green-800">
                <Flower2 className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs font-medium text-earth-500 uppercase tracking-wider">
                  Pollinator Habitat Supported
                </p>
                <p className="text-3xl font-serif font-bold text-earth-900 tabular-nums mt-1">
                  {pollinatorHabitatSqFt.toLocaleString()} <span className="text-sm font-sans font-normal text-earth-600">sq ft</span>
                </p>
              </div>
              <p className="text-xs text-earth-600 font-normal leading-relaxed">
                Directly finances unsprayed native perennial hedgerows where wild bees and monarch butterflies thrive.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
