import React, { useState } from 'react';
import { FARM_IMAGES, REGENERATIVE_PRACTICES } from '../data/farmData';
import { Check, AlertCircle } from 'lucide-react';

export const LivingSoil: React.FC = () => {
  const [selectedPracticeIndex, setSelectedPracticeIndex] = useState(0);
  const [soilMode, setSoilMode] = useState<'organic' | 'conventional'>('organic');

  const comparisonData = {
    organic: {
      title: 'Regenerative Living Soil (Verdant Roots)',
      som: '6.8% Organic Matter',
      somDetail: 'Thick, spongy humus layer teeming with mycorrhizal fungi and earthworms.',
      microbes: '4,200 µg/g Microbial Carbon',
      microbesDetail: 'Dense biological web constantly unlocking locked-up minerals for plant roots.',
      water: '8.4 inches / hour Infiltration',
      waterDetail: 'Absorbs torrential downpours with zero surface runoff; holds 27,000 gal/acre.',
      carbon: '+2.6 Tons CO2e / Acre / Year',
      carbonDetail: 'Active biological carbon sink continuously sequestering atmospheric carbon.',
      flavorBrix: '13.5° Brix (High Natural Sugar & Polyphenols)',
      flavorDetail: 'Vibrant, complex flavor with up to 40% higher antioxidant concentration.',
    },
    conventional: {
      title: 'Depleted Chemical-Tilled Soil',
      som: '1.1% Organic Matter',
      somDetail: 'Compacted dead dirt requiring synthetic petro-fertilizers to sustain plants.',
      microbes: '380 µg/g Microbial Carbon',
      microbesDetail: 'Sterilized by chemical fungicides, herbicides, and excessive synthetic nitrogen.',
      water: '0.6 inches / hour Infiltration',
      waterDetail: 'Severe surface crusting leading to muddy erosion into local waterways.',
      carbon: '-1.4 Tons CO2e / Acre / Year',
      carbonDetail: 'Net carbon emitter due to intensive mechanical tilling and nitrogen volatilization.',
      flavorBrix: '6.2° Brix (Watery, Low Mineral Density)',
      flavorDetail: 'Bland, watery produce selected for shipping durability over human nutrition.',
    },
  };

  const current = comparisonData[soilMode];

  return (
    <section id="soil-practices" className="py-20 lg:py-28 bg-earth-50 border-b border-earth-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        {/* Section Header */}
        <div className="max-w-3xl space-y-4">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-farm-green-800">
            <span>Soil Ecology & Agronomy</span>
            <span aria-hidden="true" className="text-earth-400">·</span>
            <span className="text-terracotta-700">Biological Earth Stewardship</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-earth-900 tracking-tight">
            Feed the Soil, Not Just the Plant.
          </h2>
          <p className="text-base sm:text-lg text-earth-700 leading-relaxed font-normal">
            Real organic farming begins underground. When you nourish the soil microbiome with diverse
            cover crops, thermal compost, and zero-tillage principles, the earth naturally defends
            crops from pests, holds groundwater like a sponge, and yields vegetables with unmatched flavor.
          </p>
        </div>

        {/* 2-Column Split: Image & Practice Deep Dive */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-stretch">
          {/* Left Column: Visual Asset with Fallback & Caption */}
          <div className="lg:col-span-5 flex flex-col justify-between space-y-4">
            <div className="relative rounded-2xl overflow-hidden border border-earth-200 shadow-xs flex-1 min-h-[380px] bg-white">
              <img
                src={FARM_IMAGES.soilHands}
                alt="Documentary close-up of farmer hands holding rich dark living compost with green sprouts"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-0 inset-x-0 p-5 bg-gradient-to-t from-earth-950/90 via-earth-950/40 to-transparent text-white">
                <p className="text-xs font-medium text-farm-green-200 uppercase tracking-wider">
                  Farmstead Field Station #4
                </p>
                <p className="text-sm font-serif mt-1 text-white">
                  Living fungal mycorrhizae and aerobic compost microbiology in living earth.
                </p>
              </div>
            </div>

            {/* Trust callout in Earth Sand & Green */}
            <div className="p-4 rounded-xl bg-white border border-earth-200 text-xs text-earth-900 flex items-center gap-3 shadow-2xs">
              <div className="w-5 h-5 rounded-full bg-farm-green-100 text-farm-green-800 flex items-center justify-center shrink-0">
                <Check className="w-3.5 h-3.5" />
              </div>
              <span>Independent laboratory test verifies 6.8% active organic earth matter (2026 Season).</span>
            </div>
          </div>

          {/* Right Column: 4 Core Biological Practices */}
          <div className="lg:col-span-7 flex flex-col justify-between space-y-4">
            <div className="space-y-3">
              {REGENERATIVE_PRACTICES.map((practice, index) => {
                const isActive = selectedPracticeIndex === index;
                return (
                  <div
                    key={practice.number}
                    onClick={() => setSelectedPracticeIndex(index)}
                    className={`cursor-pointer p-5 rounded-xl border transition-all text-left ${
                      isActive
                        ? 'bg-white border-farm-green-700/80 shadow-xs ring-1 ring-farm-green-700/20'
                        : 'bg-white/80 border-earth-200 hover:bg-white hover:border-earth-300'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-4">
                      <div className="flex items-center gap-3">
                        <span className="font-serif text-lg font-bold text-terracotta-700 tabular-nums">
                          {practice.number}.
                        </span>
                        <h3 className="text-base font-semibold text-earth-900">
                          {practice.title}
                        </h3>
                      </div>
                      <span className="text-xs text-earth-500 font-medium">
                        {isActive ? 'Expanded' : 'Details'}
                      </span>
                    </div>

                    <p className="text-sm text-earth-700 mt-2 font-normal">
                      {practice.summary}
                    </p>

                    {isActive && (
                      <div className="mt-4 pt-4 border-t border-earth-100 space-y-2.5 animate-in fade-in duration-200">
                        <p className="text-sm text-earth-800 leading-relaxed font-normal">
                          {practice.details}
                        </p>
                        <div className="text-xs font-medium text-farm-green-900 bg-farm-green-100 px-3 py-1.5 rounded-md inline-block border border-farm-green-200/60">
                          Measured Result: {practice.metric}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Interactive Soil Science Comparison Module in Crisp White with Earth Accents */}
        <div className="bg-white rounded-2xl border border-earth-200 p-6 sm:p-8 lg:p-10 shadow-xs space-y-8">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-earth-100">
            <div>
              <h3 className="font-serif text-2xl font-bold text-earth-900">
                Comparative Soil Lab Analysis
              </h3>
              <p className="text-sm text-earth-600 mt-1">
                Toggle between our living regenerative soil metrics and typical industrial chemical agriculture.
              </p>
            </div>

            {/* Interactive Segmented Control */}
            <div className="flex items-center gap-1 p-1 bg-earth-100 rounded-lg shrink-0 border border-earth-200">
              <button
                type="button"
                onClick={() => setSoilMode('organic')}
                className={`px-4 py-2 text-xs font-semibold rounded-md transition-all whitespace-nowrap ${
                  soilMode === 'organic'
                    ? 'bg-farm-green-800 text-white shadow-xs'
                    : 'text-earth-700 hover:text-earth-900'
                }`}
              >
                Living Organic Soil
              </button>
              <button
                type="button"
                onClick={() => setSoilMode('conventional')}
                className={`px-4 py-2 text-xs font-semibold rounded-md transition-all whitespace-nowrap ${
                  soilMode === 'conventional'
                    ? 'bg-earth-800 text-white shadow-xs'
                    : 'text-earth-700 hover:text-earth-900'
                }`}
              >
                Conventional Chemical
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="p-5 rounded-xl bg-earth-50 border border-earth-200/90 space-y-2">
              <div className="text-xs font-semibold text-earth-600 uppercase tracking-wider">
                Soil Organic Matter (SOM)
              </div>
              <div className={`text-xl font-bold font-serif tabular-nums ${soilMode === 'organic' ? 'text-farm-green-800' : 'text-earth-700'}`}>
                {current.som}
              </div>
              <p className="text-xs text-earth-700 leading-relaxed font-normal">
                {current.somDetail}
              </p>
            </div>

            <div className="p-5 rounded-xl bg-earth-50 border border-earth-200/90 space-y-2">
              <div className="text-xs font-semibold text-earth-600 uppercase tracking-wider">
                Active Microbial Biomass
              </div>
              <div className={`text-xl font-bold font-serif tabular-nums ${soilMode === 'organic' ? 'text-farm-green-800' : 'text-earth-700'}`}>
                {current.microbes}
              </div>
              <p className="text-xs text-earth-700 leading-relaxed font-normal">
                {current.microbesDetail}
              </p>
            </div>

            <div className="p-5 rounded-xl bg-earth-50 border border-earth-200/90 space-y-2">
              <div className="text-xs font-semibold text-earth-600 uppercase tracking-wider">
                Water Infiltration Rate
              </div>
              <div className={`text-xl font-bold font-serif tabular-nums ${soilMode === 'organic' ? 'text-farm-green-800' : 'text-earth-700'}`}>
                {current.water}
              </div>
              <p className="text-xs text-earth-700 leading-relaxed font-normal">
                {current.waterDetail}
              </p>
            </div>

            <div className="p-5 rounded-xl bg-earth-50 border border-earth-200/90 space-y-2">
              <div className="text-xs font-semibold text-earth-600 uppercase tracking-wider">
                Carbon Balance / Sequestration
              </div>
              <div className={`text-xl font-bold font-serif tabular-nums ${soilMode === 'organic' ? 'text-farm-green-800' : 'text-terracotta-700'}`}>
                {current.carbon}
              </div>
              <p className="text-xs text-earth-700 leading-relaxed font-normal">
                {current.carbonDetail}
              </p>
            </div>

            <div className="p-5 rounded-xl bg-earth-50 border border-earth-200/90 space-y-2 md:col-span-2">
              <div className="text-xs font-semibold text-earth-600 uppercase tracking-wider">
                Crop Flavor, Brix Sugar & Micronutrients
              </div>
              <div className={`text-xl font-bold font-serif tabular-nums ${soilMode === 'organic' ? 'text-farm-green-800' : 'text-earth-700'}`}>
                {current.flavorBrix}
              </div>
              <p className="text-xs text-earth-700 leading-relaxed font-normal">
                {current.flavorDetail}
              </p>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-earth-100/70 border border-earth-200 text-xs text-earth-800 flex items-start gap-2.5">
            <AlertCircle className="w-4 h-4 text-terracotta-700 shrink-0 mt-0.5" />
            <span>
              By partnering directly with Verdant Roots, your family diverts organic produce demand from industrial pesticide-dependent supply chains, preserving living aquifers and regional topsoil.
            </span>
          </div>
        </div>
      </div>
    </section>
  );
};
